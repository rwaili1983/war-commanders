(function(){'use strict';const T=window.MakkenTheme;
const grid=document.getElementById('themeGrid'),preview=document.getElementById('livePreview');
function tile(key,p){const b=document.createElement('button');b.type='button';b.className='theme-tile';b.dataset.skin=key;b.setAttribute('aria-label','اختر قالب '+p.name);
 b.innerHTML='<div class="theme-illustration"><div class="t-header"><i></i><i></i><i></i></div><div class="t-hero"><b></b><span></span><em></em></div><div class="t-cards"><i></i><i></i><i></i></div></div><div class="theme-meta"><strong></strong><small></small><div class="selected-label"></div></div>';
 b.style.setProperty('--tile-primary',p.primary);b.style.setProperty('--tile-dark',p.dark);b.style.setProperty('--tile-accent',p.accent);b.style.setProperty('--tile-bg',p.soft);
 b.querySelector('strong').textContent=p.name;b.querySelector('small').textContent=p.desc;
 b.addEventListener('click',()=>{T.apply({skin:key});refresh();});return b;}
Object.entries(T.presets).forEach(([k,p])=>grid.appendChild(tile(k,p)));
function refresh(){const state=T.get();grid.querySelectorAll('button').forEach(b=>{const active=b.dataset.skin===state.skin;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));b.querySelector('.selected-label').textContent=active?'✓ القالب المفعّل':''});document.getElementById('currentTheme').textContent='القالب الحالي: '+T.presets[state.skin].name;
 document.querySelectorAll('[data-layout]').forEach(b=>{const active=b.dataset.layout===state.layout;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))});
 document.querySelectorAll('[data-density]').forEach(b=>{const active=b.dataset.density===state.density;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))});
 try{preview.contentWindow.postMessage({type:'makken-theme-changed'},'*')}catch{}
}
document.querySelectorAll('[data-layout]').forEach(b=>b.addEventListener('click',()=>{T.apply({layout:b.dataset.layout});refresh()}));
document.querySelectorAll('[data-density]').forEach(b=>b.addEventListener('click',()=>{T.apply({density:b.dataset.density});refresh()}));
document.getElementById('desktopBtn').addEventListener('click',()=>{document.getElementById('previewDevice').classList.remove('mobile');document.getElementById('desktopBtn').classList.add('active');document.getElementById('mobileBtn').classList.remove('active')});
document.getElementById('mobileBtn').addEventListener('click',()=>{document.getElementById('previewDevice').classList.add('mobile');document.getElementById('mobileBtn').classList.add('active');document.getElementById('desktopBtn').classList.remove('active')});
document.getElementById('resetTheme').addEventListener('click',()=>{T.reset();refresh()});
window.addEventListener('makken:theme-change',refresh);
// Preview reloads because the iframe may be same-origin but localStorage theme events do not
// fire in the browsing context where they were changed.
window.addEventListener('makken:theme-change',()=>{if(!preview)return;try{if(preview.contentWindow)preview.contentWindow.location.reload()}catch{preview.src='index.html?refresh='+Date.now()}});
const frame=document.getElementById('livePreview');frame.addEventListener('load',()=>{try{if(frame.contentDocument?.querySelector('.hero')){document.getElementById('previewDevice').classList.add('is-loaded');document.getElementById('previewFallback').hidden=true}}catch{ /* Keep fallback if file access is blocked. */ }});
refresh();
})();
