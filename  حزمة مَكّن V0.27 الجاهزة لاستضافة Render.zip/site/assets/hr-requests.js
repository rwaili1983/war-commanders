"use strict";
// Pure in-memory demo: reviewers and rights on this page are not server permissions.
(()=>{
 const $=id=>document.getElementById(id);
 const requests=[];
 const dateInRiyadh=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 $('workDay').value=dateInRiyadh();
 const names={late_arrival:'تأخر',early_departure:'خروج مبكر',time_out:'استئذان أثناء العمل'};
 function add(tag,text,cls){const el=document.createElement(tag);el.textContent=String(text);if(cls)el.className=cls;return el;}
 function draw(){
  $('pendingCount').textContent=requests.filter(x=>x.status==='pending').length;
  $('approvedCount').textContent=requests.filter(x=>x.status==='approved').length;
  $('requests').replaceChildren();
  if(!requests.length)$('requests').append(add('p','لا توجد طلبات.','hint'));
  requests.forEach((r,i)=>{
   const card=add('article','','request-card');card.append(add('h4',names[r.type]+' · '+r.day),add('p',r.start+' – '+r.end),add('p',r.reason));
   card.append(add('span',({pending:'بانتظار المراجعة',approved:'معتمد تجريبيًا',rejected:'مرفوض تجريبيًا'})[r.status],'status-pill '+r.status));
   if(r.status==='pending'){
    const bar=add('div','','request-actions');
    [['اعتماد تجريبي','approved'],['رفض تجريبي','rejected']].forEach(([caption,state])=>{
     const button=add('button',caption,state==='rejected'?'reject':'');button.type='button';
     button.addEventListener('click',()=>{r.status=state;$('message').textContent='قرار تجريبي للطلب '+(i+1)+' — لا يغيّر سجلات الدوام أو الرواتب.';draw();});bar.append(button);
    });card.append(bar);
   }
   $('requests').append(card);
  });
 }
 function report(){
  const today=dateInRiyadh();const day=new Date(today+'T12:00:00Z');
  const data=[['-5','حضور مسجل','6:45','12 دقيقة','تأخر ظاهر في السجل'],['-4','إجازة معتمدة','—','—','لا تحسب غيابًا'],['-3','يحتاج مراجعة','—','—','لا بصمة، يتحقق الموظف من السبب'],['-2','حضور مسجل','7:00','0','مكتمل'],['-1','يحتاج مراجعة','—','—','قد يكون عطلة رسمية أو تسجيلًا منسيًا']];
  const tbody=$('monthlyRows');tbody.replaceChildren();data.forEach(([offset,status,hours,late,note])=>{
   const d=new Date(day);d.setUTCDate(d.getUTCDate()+Number(offset));const tr=document.createElement('tr');
   [d.toISOString().slice(0,10),status,hours,late,note].forEach(v=>tr.append(add('td',v)));tbody.append(tr);
  });
 }
 $('permissionForm').addEventListener('submit',e=>{
  e.preventDefault();const type=$('requestType').value,day=$('workDay').value,start=$('startTime').value,end=$('endTime').value,reason=$('reason').value.trim();
  const today=new Date(dateInRiyadh()+'T12:00:00Z');const selected=new Date(day+'T12:00:00Z');const gap=Math.round((selected-today)/86400000);
  const okay=[type in names,Number.isFinite(gap),gap>=-7,gap<=30,start<end,start>='08:00',end<='15:00',reason.length>=10,
    !(type==='late_arrival'&&start!=='08:00'),!(type==='early_departure'&&end!=='15:00'),
    !requests.some(r=>r.day===day&&r.status!=='rejected'&&start<r.end&&r.start<end)].every(Boolean);
  if(!okay){$('message').textContent='راجع التاريخ والوقت (08:00–15:00) والسبب وطريقة الطلب، وتأكد من عدم وجود طلب متداخل.';return;}
  requests.unshift({type,day,start,end,reason,status:'pending'});$('reason').value='';$('message').textContent='تم تسجيل طلب افتراضي للمراجعة. لا يوجد خادم متصل.';draw();
 });
 $('clearDemo').addEventListener('click',()=>{requests.length=0;draw();$('message').textContent='تمت إعادة ضبط بيانات العرض.';});
 const close=()=>{$('drawer').classList.remove('open');$('drawer').inert=true;$('veil').hidden=true;$('menuToggle').setAttribute('aria-expanded','false');$('menuToggle').focus();};
 $('menuToggle').addEventListener('click',()=>{$('drawer').inert=false;$('veil').hidden=false;$('drawer').classList.add('open');$('menuToggle').setAttribute('aria-expanded','true');$('closeDrawer').focus();});
 $('closeDrawer').addEventListener('click',close);$('veil').addEventListener('click',close);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('drawer').classList.contains('open'))close();});
 document.querySelectorAll('#drawer a').forEach(x=>x.addEventListener('click',close));
 report();draw();
})();