/* Makken V0.17 - accessible menu controller. No backend or user data touched. */
(function(){'use strict';
const BREAKPOINT='(max-width: 1024px)';
const mq=window.matchMedia(BREAKPOINT);
const on=(el,event,fn)=>el&&el.addEventListener(event,fn);
let adminDrawer=null;
function setupAdmin(){
 const sidebar=document.getElementById('sidebar');const toggle=document.getElementById('sidebarToggle');
 if(!sidebar||!toggle)return;
 const backdrop=document.createElement('button');backdrop.type='button';backdrop.className='responsive-backdrop';backdrop.setAttribute('aria-label','إغلاق القائمة الجانبية');document.body.append(backdrop);
 const close=document.createElement('button');close.type='button';close.className='sidebar-close';close.setAttribute('aria-label','إغلاق القائمة الجانبية');close.textContent='×';
 const row=document.createElement('div');row.className='responsive-side-top';row.style.cssText='display:flex;align-items:center;justify-content:flex-end;gap:8px';row.append(close);sidebar.prepend(row);
 sidebar.setAttribute('aria-label','قائمة لوحة التحكم');toggle.type='button';toggle.setAttribute('aria-controls','sidebar');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','فتح القائمة الجانبية');
 let lastFocused=null;
 function setOpen(open,returnFocus=true){
   open=!!open&&mq.matches;
   const wasOpen=sidebar.classList.contains('open');
   sidebar.classList.toggle('open',open);backdrop.classList.toggle('is-open',open);document.body.classList.toggle('responsive-menu-open',open);
   toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'إغلاق القائمة الجانبية':'فتح القائمة الجانبية');
   if(mq.matches){sidebar.inert=!open;sidebar.setAttribute('aria-hidden',String(!open));}
   else{sidebar.inert=false;sidebar.removeAttribute('aria-hidden');}
   if(open){lastFocused=document.activeElement;close.focus();}
   else if(wasOpen&&returnFocus&&lastFocused&&lastFocused.isConnected){lastFocused.focus();}
 }
 on(toggle,'click',()=>setOpen(!sidebar.classList.contains('open')));
 on(close,'click',()=>setOpen(false));on(backdrop,'click',()=>setOpen(false));
 on(sidebar,'click',evt=>{if(evt.target.closest('a[href]'))setOpen(false,false)});
 on(document,'keydown',evt=>{
   if(!sidebar.classList.contains('open'))return;
   if(evt.key==='Escape'){evt.preventDefault();setOpen(false);return;}
   if(evt.key!=='Tab')return;
   const nodes=[...sidebar.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(n=>!n.hidden&&n.getClientRects().length);
   if(!nodes.length)return;
   const first=nodes[0],last=nodes[nodes.length-1];
   if(evt.shiftKey&&document.activeElement===first){evt.preventDefault();last.focus();}
   else if(!evt.shiftKey&&document.activeElement===last){evt.preventDefault();first.focus();}
 });
 if(mq.addEventListener)mq.addEventListener('change',()=>setOpen(false,false));else mq.addListener(()=>setOpen(false,false));
 setOpen(false,false);
 adminDrawer={close:()=>setOpen(false,false)};
}
function setupPublic(){
 const nav=document.querySelector('.navbar');if(!nav)return;
 const menu=nav.querySelector('.nav-menu,.shared-menu');const links=nav.querySelector('.links,.shared-links');if(!menu||!links)return;
 // On the main website, services formerly in hidden action buttons remain reachable on mobile.
 if(document.body.dataset.makkenPage==='index.html'){
   [['portal.html','بوابة المستفيدين'],['admin.html','لوحة التحكم'],['design.html','القوالب والتصميم'],['builder.html','محرر الصفحات']].forEach(([href,label])=>{
     if(![...links.querySelectorAll('a')].some(a=>a.getAttribute('href')===href)){
       const a=document.createElement('a');a.href=href;a.textContent=label;a.className='responsive-mobile-link';links.append(a);
     }
   });
 }
 links.id=links.id||'makken-public-links';menu.type='button';menu.setAttribute('aria-controls',links.id);
 menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','فتح قائمة التنقل');
 // Disable legacy non-centralized handler when present by using capture phase.
 function setOpen(open,focus=false){
   open=!!open&&mq.matches;
   links.classList.toggle('open',open);nav.classList.toggle('shared-open',open);
   menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'إغلاق قائمة التنقل':'فتح قائمة التنقل');
   links.setAttribute('aria-hidden',String(mq.matches&&!open));
   if(!open&&focus)menu.focus();
 }
 on(menu,'click',evt=>{evt.stopImmediatePropagation();setOpen(!links.classList.contains('open'));});
 on(links,'click',evt=>{if(evt.target.closest('a[href]'))setOpen(false)});
 on(document,'click',evt=>{if(!nav.contains(evt.target))setOpen(false)});
 on(document,'keydown',evt=>{if(evt.key==='Escape'&&links.classList.contains('open')){evt.preventDefault();setOpen(false,true)}});
 if(mq.addEventListener)mq.addEventListener('change',()=>setOpen(false));else mq.addListener(()=>setOpen(false));
 setOpen(false);
}
function ready(){setupAdmin();setupPublic()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
window.MakkenResponsive={close:function(){if(adminDrawer)adminDrawer.close()}};
})();
