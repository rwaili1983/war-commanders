/* Makken phase-one preview: local-only mock data, NOT a production data service. */
(function (w) {
  'use strict';
  const KEY='makken_demo_v01';
  const defaults = {
    version:'0.10.0',
    settings:{organization:'جمعية الأثر التنموية',tagline:'معًا نصنع أثرًا يدوم',phone:'0500000000',email:'info@example.org',city:'المملكة العربية السعودية',primary:'#17594d',hero:'من العطاء تبدأ الحكايات الجميلة',announcement:'مرحبًا بكم في منصة مكن — يمكن إدارة هذا الشريط من لوحة التحكم',about:'نسعى إلى بناء فرص حياة أفضل للأسر، بالشراكة مع مجتمع يؤمن بأن العطاء يصنع أثرًا مستدامًا.'},
    modules:{cms:true,beneficiaries:true,projects:true,store:true,gallery:true,hr:false,office:false,finance:false,workflow:true,reporting:true},
    news:[
      {id:'n1',title:'إطلاق مبادرة السلة الغذائية للأسر',date:'2026-11-07',category:'أخبار الجمعية',summary:'بدء استقبال طلبات الاستفادة من مبادرة السلة الغذائية عبر البوابة الإلكترونية.',icon:'🧺',status:'منشور'},
      {id:'n2',title:'إعلان فتح باب التسجيل في البرامج',date:'2026-11-03',category:'إعلانات',summary:'تستقبل الجمعية طلبات التسجيل الجديدة عبر بوابة المستفيدين على الموقع الإلكتروني.',icon:'📣',status:'منشور'},
      {id:'n3',title:'لقاء تعريفي بالبرامج التنموية',date:'2026-10-29',category:'فعاليات',summary:'لقاء تعريفي افتراضي يستعرض الخدمات والمبادرات الموجهة للأسر.',icon:'🤝',status:'منشور'}
    ],
    projects:[
      {id:'p1',title:'دفء الشتاء',category:'مشروع موسمي',description:'توفير كسوة الشتاء واحتياجات التدفئة للأسر المستفيدة.',goal:80000,collected:48500,icon:'🧥',status:'نشط'},
      {id:'p2',title:'سلة الخير',category:'دعم أسري',description:'تأمين السلال الغذائية الأساسية للأسر المسجلة.',goal:120000,collected:75600,icon:'🧺',status:'نشط'},
      {id:'p3',title:'تمكين الأسر',category:'تمكين',description:'دعم مشاريع صغيرة للأسر المنتجة لتعزيز الاستقلال المالي.',goal:200000,collected:127000,icon:'🌱',status:'نشط'}
    ],
    gallery:[
      {id:'g1',title:'مبادراتنا المجتمعية',icon:'🤲'},
      {id:'g2',title:'توزيع السلال الغذائية',icon:'🧺'},
      {id:'g3',title:'ورش التمكين',icon:'🪴'},
      {id:'g4',title:'العمل التطوعي',icon:'❤️'}
    ],
    beneficiaries:[{id:'APP-2026-0001',name:'أسرة تجريبية رقم 001',phone:'0500000001',members:4,category:'دعم أسري',status:'قيد المراجعة',date:'2026-11-05',notes:'سجل وهمي للعرض فقط',reviewerId:null,votes:[],history:[]}],
    staff:[{id:'s1',name:'موظف تجريبي 01',department:'خدمات المستفيدين',role:'موظف',employment:'نشط'},{id:'s2',name:'موظف تجريبي 02',department:'المكتب الإداري',role:'مدير إدارة',employment:'نشط'}],
    departments:[{id:'d1',name:'المكتب الإداري',manager:'موظف تجريبي 02',enabled:true},{id:'d2',name:'خدمات المستفيدين',manager:'موظف تجريبي 01',enabled:true},{id:'d3',name:'الموارد البشرية',manager:'غير محدد',enabled:false}],
    sections:[{id:'projects',name:'المشاريع',enabled:true},{id:'news',name:'الأخبار والإعلانات',enabled:true},{id:'gallery',name:'معرض الصور',enabled:true},{id:'about',name:'عن الجمعية',enabled:true}],
    committees:[{id:'c1',name:'لجنة المساعدات',members:'member1,member2',active:true},{id:'c2',name:'لجنة الإسكان',members:'member2,member3',active:true}],
    workflowRules:[{id:'wr1',name:'توجيه مساعدات الإيجار',field:'assistance_type',operator:'eq',value:'rent',department:'خدمات المستفيدين',priority:10,enabled:false}],
    leaveRequests:[{id:'l1',employee:'موظف تجريبي 01',type:'إجازة اعتيادية',startDate:'2026-11-10',endDate:'2026-11-12',status:'قيد الدراسة'}],
    officeLetters:[{id:'OFF-DEMO-001',reference:'IN-DEMO-001',direction:'وارد',subject:'خطاب تجريبي لمراجعة طلب',department:'المكتب الإداري',assignee:'موظف تجريبي 02',status:'مسندة'}],
    familyLinks:[],
    orders:[],
    activity:[{at:'2026-11-07',action:'تهيئة النسخة التجريبية'}]
  };
  const clone=o=>JSON.parse(JSON.stringify(o));
  function get(){let data;try{data=JSON.parse(localStorage.getItem(KEY)||'null')}catch{}if(!data||typeof data!=='object'){data=clone(defaults);save(data)}else if(data.version!=='0.10.0'){
    // Preserve V0.1–V0.4 records while supplying V0.5 committee membership and history.
    data={...clone(defaults),...data,version:'0.10.0',settings:{...clone(defaults.settings),...(data.settings||{})},modules:{...clone(defaults.modules),...(data.modules||{})},familyLinks:Array.isArray(data.familyLinks)?data.familyLinks:[],officeLetters:Array.isArray(data.officeLetters)?data.officeLetters:clone(defaults.officeLetters),committees:Array.isArray(data.committees)?data.committees:clone(defaults.committees),sections:Array.isArray(data.sections)?data.sections:clone(defaults.sections),leaveRequests:Array.isArray(data.leaveRequests)?data.leaveRequests:clone(defaults.leaveRequests),workflowRules:Array.isArray(data.workflowRules)?data.workflowRules:clone(defaults.workflowRules)};
    if(Array.isArray(data.beneficiaries))data.beneficiaries=data.beneficiaries.map(x=>({...x,reviewerId:x.reviewerId||null,votes:Array.isArray(x.votes)?x.votes:[],history:Array.isArray(x.history)?x.history:[]}));
    save(data);
  }return data}
  function save(data){localStorage.setItem(KEY,JSON.stringify(data));return data}
  function update(fn){const data=get();fn(data);save(data);window.dispatchEvent(new CustomEvent('makken:change'));return data}
  function id(prefix='id'){return prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6)}
  function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function sar(num){return Number(num||0).toLocaleString('ar-SA',{maximumFractionDigits:0})+' ر.س'}
  function notice(msg){const old=document.querySelector('.toast');if(old)old.remove();let n=document.createElement('div');n.className='toast';n.textContent=msg;document.body.appendChild(n);setTimeout(()=>n.remove(),3300)}
  function reset(){save(clone(defaults));window.dispatchEvent(new CustomEvent('makken:change'))}
  function log(d,action){d.activity.unshift({at:new Date().toISOString().slice(0,16).replace('T',' '),action});d.activity=d.activity.slice(0,50)}
  w.Makken={get,save,update,id,esc,sar,notice,reset,log,defaults:clone(defaults)};
})(window);
