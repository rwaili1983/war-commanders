/* Shared site chrome. Does not grant roles, modify requests, or call a server. */
(function(){'use strict';
const pages={ 'index.html':['الرئيسية','الموقع الرئيسي'], 'admin.html':['لوحة التحكم','الإدارة'], 'portal.html':['بوابة المستفيدين','خدمات المستفيدين'], 'privacy.html':['الخصوصية','الخصوصية'], 'access.html':['صلاحيات المكتب الإداري','مركز الصلاحيات'], 'beneficiary-access.html':['صلاحيات المستفيدين','مركز الصلاحيات'], 'integration.html':['الربط والتكامل','دليل المطور'], 'operations.html':['جاهزية التشغيل','دليل المطور'], 'staging-v013.html':['اختبارات التشغيل','دليل المطور'], 'design.html':['استوديو القوالب','الهوية والتصميم'], 'builder.html':['محرر الصفحات المرئي','إدارة الموقع']};
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function ready(){let file=document.body.dataset.makkenPage||location.pathname.split('/').pop()||'index.html';const page=pages[file]||['صفحة مَكّن','النظام'];const admin=file==='admin.html';const home=file==='index.html';document.body.dataset.page=file.replace('.html','');
  if(!admin){
    let nav=document.querySelector('.navbar');
    if(!nav){nav=document.createElement('nav');nav.className='navbar shared-navbar';nav.setAttribute('aria-label','القائمة الرئيسية');nav.innerHTML='<div class="container nav-inner"><a class="brand" href="index.html"><span class="brand-icon" aria-hidden="true">✦</span><span><strong>مَكّن</strong><small>منظومة الجمعيات الإلكترونية</small></span></a><div class="shared-links"><a href="index.html">الرئيسية</a><a href="portal.html">بوابة المستفيدين</a><a href="admin.html">لوحة التحكم</a><a href="design.html">القوالب</a><a href="builder.html">محرر الصفحات</a></div><button class="shared-menu" aria-expanded="false" aria-label="القائمة">☰</button></div>';
      const anchor=document.querySelector('.demo-strip'); if(anchor)anchor.after(nav); else document.body.prepend(nav);
    }else{
      const inner=nav.querySelector('.nav-inner');
      if(inner&&!inner.querySelector('.links')&&!inner.querySelector('.shared-links')){
        const links=document.createElement('div');links.className='shared-links';links.innerHTML='<a href="index.html">الرئيسية</a><a href="portal.html">المستفيدون</a><a href="admin.html">الإدارة</a><a href="design.html">القوالب</a>';inner.appendChild(links);
      }
    }
    const navInner=nav.querySelector('.nav-inner');
    if(navInner&&!navInner.querySelector('.shared-menu')&&!navInner.querySelector('.nav-menu')){
      const btn=document.createElement('button');btn.className='shared-menu';btn.type='button';btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','فتح قائمة التنقل');btn.textContent='☰';navInner.appendChild(btn);
    }
    // Responsive controller owns navigation click handling (single handler).
    nav.querySelectorAll('a').forEach(a=>{if(a.getAttribute('href')===file)a.setAttribute('aria-current','page')});
    if(!home){let crumb=document.createElement('div');crumb.className='unified-crumb';crumb.innerHTML='<div class="container"><a href="index.html">الرئيسية</a><span aria-hidden="true">/</span><strong>'+escapeHTML(page[0])+'</strong><a class="crumb-design" href="design.html">تخصيص المظهر ✦</a></div>';nav.after(crumb)}
    if(!document.querySelector('footer.footer')){const footer=document.createElement('footer');footer.className='footer unified-footer';footer.innerHTML='<div class="container"><div class="footer-grid"><div><strong>✦ منصة مَكّن</strong><p>واجهة موحدة، وإدارة أسهل، وتجربة رقمية أفضل للجمعيات.</p><span class="footer-disclaimer">هذه نسخة عرض محلية ببيانات وهمية فقط.</span></div><div><strong>روابط المنصة</strong><a href="index.html">الموقع الرئيسي</a><a href="portal.html">بوابة المستفيد</a><a href="admin.html">لوحة التحكم</a></div><div><strong>التصميم والدعم</strong><a href="design.html">استوديو القوالب</a><a href="builder.html">محرر الصفحات</a><a href="privacy.html">خصوصية المعاينة</a><a href="operations.html">جاهزية التشغيل</a></div></div><div class="footer-bottom">مَكّن · إصدار التصميم V0.17 — جميع البيانات استعراضية</div></div>';document.body.append(footer)}
  }else{
    const aside=document.querySelector('.sidebar');if(aside&&!aside.querySelector('[href="design.html"]')){
      const navs=aside.querySelectorAll('.side-nav');const last=navs[navs.length-1];if(last){const link=document.createElement('a');link.href='design.html';link.innerHTML='<span class="nav-ic" aria-hidden="true">🎨</span>استوديو القوالب والتصميم ↗';last.insertBefore(link,last.firstChild)}}
    const head=document.querySelector('.admin-head');if(head){head.classList.add('unified-admin-head');const badge=document.createElement('a');badge.href='builder.html';badge.className='admin-design-link';badge.textContent='✦ محرر الصفحات';head.appendChild(badge)}
  }
  const skip=document.createElement('a');skip.href=admin?'#adminContent':'#mainContent';skip.className='skip-link';skip.textContent='انتقل إلى المحتوى';document.body.prepend(skip);
  if(!admin&&!document.getElementById('mainContent')){const main=document.querySelector('main')||document.querySelector('.portal-hero')||document.querySelector('.access-wrap')||document.querySelector('.container > .portal-box');if(main)main.id='mainContent'}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
