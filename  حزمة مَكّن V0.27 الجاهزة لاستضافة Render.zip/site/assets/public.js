(function(){'use strict';const M=window.Makken, e=M.esc;function render(){const d=M.get(), s=d.settings;
 const draftPreview=new URLSearchParams(location.search).get('preview')==='draft';
 const bp=window.MakkenBuilder?window.MakkenBuilder.load()[draftPreview?'draft':'published']:null;
 const banner=document.querySelector('#announcementBar');if(banner){banner.textContent=s.announcement||'';banner.classList.toggle('off',!(s.announcement||'').trim())}
 const footer=document.querySelector('footer.footer');if(footer){d.sections.forEach(section=>{const el=document.getElementById(section.id);if(el)footer.before(el)});d.sections.forEach(section=>{const el=document.getElementById(section.id);if(el)el.classList.toggle('off',!section.enabled)})}
 document.title=s.organization+' | منصة مكن';document.querySelector('#brand-name').textContent=s.organization;document.querySelector('#footer-name').textContent=s.organization;document.querySelector('#hero-title').innerHTML=e(s.hero).replace(/(تبدأ|العطاء|الأثر)/,'<span>$1</span>');document.querySelector('#hero-about').textContent=s.about;document.querySelector('#year').textContent=new Date().getFullYear();
 const show=(id,on)=>document.querySelector(id).classList.toggle('off',!on);
 const isVisible=id=>d.sections.find(s=>s.id===id)?.enabled!==false;
 show('#projects',d.modules.projects&&isVisible('projects'));show('#news',d.modules.cms&&isVisible('news'));show('#gallery',d.modules.gallery&&isVisible('gallery'));show('#about',isVisible('about'));document.querySelector('#floating-projects').textContent=d.projects.filter(p=>p.status==='نشط').length;
 document.querySelector('#stats').innerHTML=[{n:d.projects.length,t:'مشروع ومبادرة'},{n:d.news.filter(n=>n.status==='منشور').length,t:'خبر وإعلان'},{n:d.gallery.length,t:'صورة ونشاط'},{n:d.beneficiaries.length,t:'طلب تجريبي'}].map(x=>`<div class="stat"><b>${e(x.n)}</b><small>${e(x.t)}</small></div>`).join('');
 const projects=d.projects.filter(p=>p.status==='نشط');document.querySelector('#projects-list').innerHTML=projects.length?projects.map((p,i)=>`<div class="card"><div class="card-photo ${i%3===1?'goldish':i%3===2?'blueish':''}"><span class="pill">${e(p.category)}</span><span>${e(p.icon||'🤲')}</span></div><div class="card-content"><h3>${e(p.title)}</h3><p class="muted small">${e(p.description)}</p><div class="split-between small"><b>${M.sar(p.collected)}</b><span class="muted">الهدف ${M.sar(p.goal)}</span></div><div class="progress" style="margin:10px 0 17px"><span style="width:${Math.min(100,Math.max(0,p.goal>0?p.collected/p.goal*100:0))}%"></span></div><button class="btn sm" data-project="${e(p.id)}">أضف للسلة التجريبية</button></div></div>`).join(''):'<div class="empty">لا توجد مشاريع منشورة</div>';
 const news=d.news.filter(n=>n.status==='منشور').slice(0,3);document.querySelector('#news-list').innerHTML=news.length?news.map(n=>`<div class="news-card"><div class="news-art">${e(n.icon||'📰')}</div><article><span class="pill">${e(n.category)}</span><h3>${e(n.title)}</h3><p>${e(n.summary)}</p><div class="muted small">${e(n.date)}</div></article></div>`).join(''):'<div class="empty">لا توجد أخبار منشورة</div>';
 document.querySelector('#gallery-list').innerHTML=d.gallery.length?d.gallery.map(g=>`<div class="gallery-item">${e(g.icon||'📷')}<span>${e(g.title)}</span></div>`).join(''):'<div class="empty">الألبوم فارغ</div>';
 document.querySelectorAll('[data-project]').forEach(b=>b.addEventListener('click',()=>{if(!d.modules.store){M.notice('المتجر غير مفعّل في هذه الباقة');return} const p=d.projects.find(x=>x.id===b.dataset.project);if(!p)return;M.update(s=>{s.orders.unshift({id:M.id('order'),projectId:p.id,title:p.title,amount:150,date:new Date().toISOString().slice(0,10),status:'طلب تجريبي'});M.log(s,'إضافة طلب تجريبي لمشروع '+p.title)});M.notice('أضيف طلب بقيمة 150 ر.س للوحة الإدارة — لا توجد عملية دفع فعلية');}));
 if(bp){
   const root=document.documentElement;root.dataset.makkenCardStyle=bp.cards.style;root.dataset.makkenCardRadius=bp.cards.radius;root.dataset.makkenHero=bp.hero.background;root.dataset.makkenHeader=bp.header.style;root.dataset.makkenHeaderSticky=String(bp.header.sticky);
   const text=(selector,value)=>{const node=document.querySelector(selector);if(node)node.textContent=value};
   const title=document.querySelector('#hero-title');if(title)title.textContent=bp.hero.title;
   text('#brand-name',bp.header.title);text('#brand-subtitle',bp.header.subtitle);text('#footer-name',bp.header.title);text('#hero-eyebrow',bp.hero.eyebrow);text('#hero-about',bp.hero.description);text('#footer-description',bp.footer.description);text('#footer-copyright',bp.footer.copyright);
   const cta=document.querySelector('#hero-cta');if(cta){cta.textContent=bp.hero.ctaText+' ←';cta.setAttribute('href',bp.hero.ctaUrl)}
   const ad=document.querySelector('#announcementBar');if(ad){ad.textContent=bp.announcement.text;ad.classList.toggle('off',!ad.textContent.trim())}
   const quick=document.querySelector('#footer-quick-links');if(quick)quick.hidden=!bp.footer.showLinks;
   const footerEl=document.querySelector('footer.footer');
   for(const section of bp.sections){const el=section.key==='stats'?document.querySelector('#stats-section'):document.getElementById(section.key);if(!el)continue;
     if(footerEl)footerEl.before(el);
     const header=el.querySelector('.section-head h2');if(header)header.textContent=section.title;
     const para=el.querySelector('.section-head p');if(para)para.textContent=section.subtitle;
     el.classList.toggle('off',!section.visible||['projects','news','gallery'].includes(section.key)&&!d.modules[section.key==='news'?'cms':section.key]);
     el.dataset.makkenSectionStyle=section.style;
   }
   const overview=document.querySelector('#about h2');if(overview)overview.textContent=bp.sections.find(x=>x.key==='about')?.title||overview.textContent;
   const aboutP=document.querySelector('#about .callout p');if(aboutP)aboutP.textContent=bp.sections.find(x=>x.key==='about')?.subtitle||aboutP.textContent;
 }
}
 
 
 window.addEventListener('makken:change',render);window.addEventListener('makken:builder-change',render);window.addEventListener('storage',render);render();})();
