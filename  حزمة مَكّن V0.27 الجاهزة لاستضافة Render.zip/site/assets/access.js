/* V0.10 demonstration only: client-side roles are NOT security controls. */
(function(){
'use strict';
const e=window.Makken.esc;
const roles={
 global_admin:{label:'مدير النظام',dept:null,view:true,viewAll:true,manage:true,manageAll:true},
 global_auditor:{label:'مدقق عام',dept:null,view:true,viewAll:true,manage:false,manageAll:false},
 office_employee:{label:'موظف المكتب الإداري',dept:'المكتب الإداري',view:true,viewAll:false,manage:true,manageAll:false},
 service_employee:{label:'موظف خدمات المستفيدين',dept:'خدمات المستفيدين',view:true,viewAll:false,manage:true,manageAll:false},
 office_viewer:{label:'قارئ المكتب الإداري',dept:'المكتب الإداري',view:true,viewAll:false,manage:false,manageAll:false},
 guest:{label:'زائر',dept:null,view:false,viewAll:false,manage:false,manageAll:false}
};
function allowed(base,global,actorDept,recordDept){return Boolean(base&&(global||(actorDept&&recordDept&&actorDept===recordDept)))}
function records(){
 const data=window.Makken.get();
 const user=(Array.isArray(data.officeLetters)?data.officeLetters:[]).slice(0,10).map((r,i)=>({id:r.reference||r.id||('REC-'+i),dept:r.department||'',subject:r.subject||'معاملة تجريبية',status:r.status||'مسجلة'}));
 return user.concat([
 {id:'IN-DEMO-SERVICE',dept:'خدمات المستفيدين',subject:'إحالة داخلية للتجربة',status:'مسجلة'},
 {id:'OUT-DEMO-OTHER',dept:'الموارد البشرية',subject:'خطاب تجريبي خارجي',status:'مغلقة'},
 {id:'IN-DEMO-UNASSIGNED',dept:'',subject:'معاملة غير مسندة لإدارة',status:'مسجلة'}
 ]);
}
function render(){
 const r=roles[document.getElementById('role').value]||roles.guest;
 const rows=records();let visible=0,editable=0;
 const html=rows.map(x=>{
  const read=allowed(r.view,r.viewAll,r.dept,x.dept);
  const manage=allowed(r.manage,r.manageAll,r.dept,x.dept)&&x.status!=='مغلقة';
  if(read)visible++;if(manage)editable++;
  return `<article class="access-card"><h3>${e(x.id)}</h3><p>الإدارة: ${e(x.dept||'غير محددة')}</p><p>الموضوع: ${read?e(x.subject):'🔒 محجوب'}</p><p>الحالة: ${e(x.status)}</p><div><span class="access-pill ${read?'':'deny'}">${read?'مسموح بالعرض':'ممنوع العرض'}</span> <span class="access-pill ${manage?'':'deny'}">${manage?'مسموح بالتعديل':'ممنوع التعديل'}</span></div></article>`;
 }).join('');
 document.getElementById('scopeText').textContent=r.viewAll?'عرض شامل بصلاحية مستقلة':r.dept?('نطاق الإدارة: '+r.dept):'لا توجد إدارة مخصصة';
 document.getElementById('totalCount').textContent=rows.length;
 document.getElementById('visibleCount').textContent=visible;
 document.getElementById('editableCount').textContent=editable;
 document.getElementById('records').innerHTML=html;
}
document.getElementById('role').addEventListener('change',render);
render();
})();
