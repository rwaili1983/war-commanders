/* Makken V0.14 unified visual design engine — preview only. No authorization logic. */
(function (w) {
  'use strict';
  const KEY = 'makken_design_v014';
  const palettes = {
    emerald:{name:'زمرد مَكّن',desc:'مؤسسي فاخر · أخضر وذهبي',primary:'#126355',dark:'#073d37',accent:'#d6ae69',soft:'#e6f5ee',ink:'#173833',bg:'#f5f8f6',sidebar:'#092f2c'},
    azure:{name:'أفق أزرق',desc:'هادئ · أزرق سماوي',primary:'#245a91',dark:'#123b68',accent:'#77c7df',soft:'#eaf3fc',ink:'#182e47',bg:'#f5f8fc',sidebar:'#142f52'},
    royal:{name:'ملكي',desc:'رسمي · كحلي وذهبي',primary:'#334b86',dark:'#172b57',accent:'#d8ba76',soft:'#ebeffb',ink:'#243150',bg:'#f6f7fb',sidebar:'#1b2b53'},
    sand:{name:'رمال الشمال',desc:'دافئ · بني ورملي',primary:'#85613d',dark:'#5b3e29',accent:'#d6a96e',soft:'#f9f0e3',ink:'#453627',bg:'#fbf8f3',sidebar:'#493628'},
    plum:{name:'بنفسج',desc:'حديث · بنفسجي ناعم',primary:'#7356a1',dark:'#47376a',accent:'#d6b7f2',soft:'#f2ecfa',ink:'#39304a',bg:'#f9f7fc',sidebar:'#3f315b'},
    burgundy:{name:'ياقوت',desc:'رصين · خمري ووردي',primary:'#94536a',dark:'#65293e',accent:'#e9a6a1',soft:'#faedf1',ink:'#502e3b',bg:'#fcf7f8',sidebar:'#572b3c'},
    olive:{name:'أوراق',desc:'طبيعي · زيتوني وبيج',primary:'#617547',dark:'#394d2f',accent:'#c2aa75',soft:'#eef3e6',ink:'#33402c',bg:'#f8faf5',sidebar:'#374b31'},
    sea:{name:'واحة',desc:'منعش · فيروزي',primary:'#147c84',dark:'#10515b',accent:'#83cfbe',soft:'#e8f8f5',ink:'#20444a',bg:'#f5fbfa',sidebar:'#134b52'},
    graphite:{name:'جرانيت',desc:'عملي · فحمي ونحاسي',primary:'#4b6272',dark:'#2b3945',accent:'#cf9d73',soft:'#eaf0f3',ink:'#27343b',bg:'#f5f7f9',sidebar:'#263641'},
    pearl:{name:'لؤلؤ',desc:'ناعم · أزرق رمادي',primary:'#526d85',dark:'#314c63',accent:'#bfa5c9',soft:'#edf2f8',ink:'#2d3c4c',bg:'#fafbfc',sidebar:'#344657'}
  };
  const defaults={skin:'emerald',layout:'modern',density:'comfortable'};
  function get(){try {const data=JSON.parse(localStorage.getItem(KEY)||'null')||{};return {
    skin:palettes[data.skin]?data.skin:defaults.skin,
    layout:['modern','editorial','classic'].includes(data.layout)?data.layout:defaults.layout,
    density:['comfortable','compact'].includes(data.density)?data.density:defaults.density
  }}catch{return {...defaults}}}
  function setVisual(data){const v={...get(),...data}; if(!palettes[v.skin]||!['modern','editorial','classic'].includes(v.layout)||!['comfortable','compact'].includes(v.density))return;
    const root=document.documentElement,p=palettes[v.skin];
    root.dataset.makkenSkin=v.skin;root.dataset.makkenLayout=v.layout;root.dataset.makkenDensity=v.density;
    Object.entries({'--green':p.primary,'--green-dark':p.dark,'--green-soft':p.soft,'--gold':p.accent,'--gold-soft':p.soft,'--ink':p.ink,'--bg':p.bg,'--sidebar-bg':p.sidebar,'--theme-accent':p.accent}).forEach(([key,value])=>root.style.setProperty(key,value));
    try{localStorage.setItem(KEY,JSON.stringify(v))}catch{};
    w.dispatchEvent(new CustomEvent('makken:theme-change',{detail:v}));return v;
  }
  const current=get(); setVisual(current);
  w.addEventListener('storage',ev=>{if(ev.key===KEY)setVisual(get())});
  w.MakkenTheme={get,apply:setVisual,presets:palettes,reset:()=>setVisual(defaults)};
})(window);
