/* Pure demonstration state machine; DOES NOT enforce real security or roles. */
(function(root){
  'use strict';
  const transitions={
    'قيد المراجعة':{'committee':'بانتظار اللجنة','documents':'مستكمل مستندات','reject':'مرفوض'},
    'مستكمل مستندات':{'resume':'قيد المراجعة','reject':'مرفوض'},
    'بانتظار اللجنة':{}, 'مقبول':{}, 'مرفوض':{}
  };
  const quorum=2;
  function event(record,from,to,by,reason){
    record.history=Array.isArray(record.history)?record.history:[];
    record.history.unshift({from,to,by,reason,at:new Date().toISOString()});
  }
  function review(record,action,reviewerId,committee){
    if(!record || !reviewerId)throw Error('بيانات المراجعة غير صالحة');
    const next=(transitions[record.status]||{})[action];
    if(!next)throw Error('الانتقال غير مسموح');
    if(action==='committee'){
      const members=String(committee?.members||'').split(',').map(x=>x.trim()).filter(Boolean);
      if(!committee?.active||new Set(members).size<quorum)throw Error('اختر لجنة فعّالة تضم عضوين مختلفين على الأقل');
      record.committeeId=committee.id;
      record.allowedVoters=[...new Set(members)];
    }
    const old=record.status;
    record.status=next;
    record.reviewerId=reviewerId;
    event(record,old,next,reviewerId,'review');
    return record;
  }
  function vote(record,voterId,decision){
    if(!record || record.status!=='بانتظار اللجنة')throw Error('الطلب ليس بانتظار اللجنة');
    if(!['approve','reject'].includes(decision))throw Error('اختيار غير صالح');
    if(!['member1','member2','member3'].includes(voterId))throw Error('عضو تجريبي غير معروف');
    if(!record.committeeId||!Array.isArray(record.allowedVoters)||!record.allowedVoters.includes(voterId))throw Error('ليس عضوًا في لجنة الطلب');
    if(record.reviewerId===voterId)throw Error('لا يمكن للمراجع التصويت على طلبه');
    record.votes=Array.isArray(record.votes)?record.votes:[];
    if(record.votes.some(x=>x.voterId===voterId))throw Error('سبق لهذا العضو التصويت');
    record.votes.push({voterId,decision,at:new Date().toISOString()});
    if(record.votes.filter(x=>x.decision===decision).length>=quorum){
      const old=record.status;
      record.status=decision==='approve'?'مقبول':'مرفوض';
      event(record,old,record.status,voterId,'committee-quorum');
    }
    return record;
  }
  const api={review,vote,quorum};
  root.MakkenDemoFlow=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
