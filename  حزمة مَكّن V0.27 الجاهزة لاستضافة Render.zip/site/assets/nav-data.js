/* V0.18: demo-only navigation builder. localStorage does NOT enforce permissions. */
(function (w) {
  'use strict';
  const STORAGE = 'makken_navigation_v018';
  const ROLE_KEY = 'makken_navigation_role_v018';
  const ROLES = {admin:'مدير النظام', manager:'مدير إدارة', staff:'موظف', researcher:'باحث اجتماعي', finance:'محاسب'};
  const ICONS = ['▦','✦','🎨','📰','🛍️','🖼️','👪','🔗','⚖️','🗳️','📨','👤','🗓️','🏢','🔀','🛒','🧩','🛡️','📊','⚙️','📁','📋','📌','🤲','💼','💰','🧰','🏅','📚','💬','🔔','🌐'];
  const SCREENS = {
    overview:'نظرة عامة',sitebuilder:'محرر الصفحة الرئيسية',themes:'القوالب والهوية الموحدة',news:'الأخبار والإعلانات',
    projects:'المشاريع والمتجر',gallery:'ألبوم الصور',beneficiaries:'المستفيدون والطلبات',familyLinks:'ربط الأسر المعتمدة',
    committee:'لجنة الاعتماد وسجل الطلبات',committees:'تشكيل اللجان وأعضائها',officeLetters:'الوارد والصادر',
    staff:'الموارد البشرية',leaveRequests:'طلبات الإجازة',departments:'الإدارات والأقسام',workflowRules:'قواعد توجيه الطلبات',
    orders:'طلبات المتجر',modules:'الوحدات والباقات',permissions:'الأدوار والصلاحيات',reports:'التقارير والتصدير',
    settings:'هوية الموقع وإعداداته',menuStudio:'منشئ القائمة والإدارات'
  };
  const SCREEN_MODULE={sitebuilder:'cms',news:'cms',projects:'projects',gallery:'gallery',beneficiaries:'beneficiaries',
    familyLinks:'beneficiaries',committee:'workflow',committees:'workflow',officeLetters:'office',staff:'hr',
    leaveRequests:'hr',workflowRules:'workflow',orders:'store',reports:'reporting'};
  const GROUPS=[
    {title:'نظرة عامة',icon:'▦',items:[['overview','▦']]},
    {title:'الموقع الرئيسي',icon:'🌐',items:[['sitebuilder','🎨'],['themes','✦'],['news','📰'],['projects','🛍️'],['gallery','🖼️']]},
    {title:'الخدمات والإدارات',icon:'🏢',items:[['beneficiaries','👪'],['familyLinks','🔗'],['committee','⚖️'],['committees','🗳️'],['officeLetters','📨'],['staff','👤'],['leaveRequests','🗓️'],['departments','🏢'],['workflowRules','🔀'],['orders','🛒']]},
    {title:'إعدادات النظام',icon:'⚙️',items:[['modules','🧩'],['permissions','🛡️'],['reports','📊'],['settings','⚙️'],['menuStudio','📁']]}
  ];
  const DEPARTMENTS = [
    'القيادة ولوحة المعلومات','إدارة الموقع الإلكتروني','إدارة المستفيدين','إدارة المساعدات','اللجان والاعتمادات',
    'الموارد البشرية HR','المكتب الإداري','مجلس الإدارة والجمعية العمومية','إدارة البرامج والمشاريع','المتجر الإلكتروني',
    'الإدارة المالية','تنمية الموارد المالية','الأعضاء والمشاركون','إدارة التطوع','المستودعات والمخزون',
    'الأصول والحركة والصيانة','العلاقات العامة والإعلام','خدمة المستفيدين والدعم','التقارير وذكاء الأعمال',
    'الحوكمة والتميز المؤسسي','منشئ الإدارات وقواعد العمل','المستخدمون والأدوار والصلاحيات','إعدادات المنصة والتكاملات'
  ];
  const allRoles=Object.keys(ROLES);
  const clone=o=>JSON.parse(JSON.stringify(o));
  const cleaned=(v,n=75)=>String(v||'').trim().slice(0,n).replace(/[<>\u0000-\u001f]/g,'');
  const reservedName=s=>/الفروع\s*(?:و|&)\s*المواقع|إدارة\s+الفروع|^الفروع$/u.test(s);
  const uid=prefix=>prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
  function defaultMenu(){return GROUPS.map((g,i)=>({id:'group-'+i,title:g.title,icon:g.icon,enabled:true,roles:[...allRoles],items:g.items.map(([screen,icon])=>({id:'item-'+screen,title:SCREENS[screen],icon,enabled:true,roles:[...allRoles],kind:'screen',screen,module:SCREEN_MODULE[screen]||'',content:''}))}));}
  function normalize(groups){
    if(!Array.isArray(groups)) throw new Error('الهيكل يجب أن يكون قائمة إدارات');
    if(groups.length>40)throw new Error('الحد الأعلى 40 مجموعة');
    const seen=new Set(); let count=0;
    return groups.map(g=>{
      if(!g||typeof g!=='object')throw new Error('مجموعة غير صالحة');
      const title=cleaned(g.title,70);
      if(!title||reservedName(title))throw new Error('اسم الإدارة غير صالح أو مستبعد: '+title);
      const id=cleaned(g.id,64);
      if(!/^[a-z0-9_-]{3,64}$/i.test(id)||seen.has(id))throw new Error('معرف إدارة مكرر أو غير صالح');seen.add(id);
      if(!Array.isArray(g.items)||g.items.length>30)throw new Error('لا يمكن أن تضم الإدارة أكثر من 30 صفحة');
      const roles=(Array.isArray(g.roles)?g.roles:[]).filter(x=>allRoles.includes(x));
      if(!roles.length)throw new Error('حدد دورًا واحدًا على الأقل لإدارة '+title);
      const items=g.items.map(it=>{
        if(!it||typeof it!=='object')throw new Error('صفحة غير صالحة');
        const iid=cleaned(it.id,64), label=cleaned(it.title,80);
        if(!/^[a-z0-9_-]{3,64}$/i.test(iid)||seen.has(iid))throw new Error('معرّف صفحة مكرر أو غير صالح');seen.add(iid);
        if(!label||reservedName(label))throw new Error('اسم صفحة غير صالح أو مستبعد');
        const kind=it.kind==='custom'?'custom':'screen';
        const screen=kind==='screen'&&Object.hasOwn(SCREENS,it.screen)?it.screen:'';
        if(kind==='screen'&&!screen)throw new Error('مسار شاشة غير معتمد');
        const childRoles=(Array.isArray(it.roles)?it.roles:[]).filter(x=>allRoles.includes(x));
        if(!childRoles.length)throw new Error('حدد صلاحية عرض للصفحة '+label);
        count++;if(count>300)throw new Error('الحد الأعلى 300 صفحة');
        return {id:iid,title:label,icon:ICONS.includes(it.icon)?it.icon:'📁',enabled:it.enabled!==false,roles:[...new Set(childRoles)],
          kind,screen:kind==='screen'?screen:'',module:kind==='screen'?(SCREEN_MODULE[screen]||''):'',content:kind==='custom'?cleaned(it.content,2000):''};
      });
      return {id,title,icon:ICONS.includes(g.icon)?g.icon:'📁',enabled:g.enabled!==false,roles:[...new Set(roles)],items};
    });
  }
  function initial(){const defaults=defaultMenu();return {schema:1,revision:0,draft:defaults,published:clone(defaults),history:[],publishedAt:null};}
  function get(){try{
    const raw=localStorage.getItem(STORAGE);if(!raw)return initial();
    const v=JSON.parse(raw);if(v.schema!==1)return initial();
    const draft=normalize(v.draft),published=normalize(v.published);
    return {schema:1,revision:Number.isSafeInteger(v.revision)?v.revision:0,draft,published,
      history:Array.isArray(v.history)?v.history.slice(0,10):[],publishedAt:v.publishedAt||null};
  }catch{ return initial();}}
  function save(v){const next={...v,schema:1,draft:normalize(v.draft),published:normalize(v.published)};localStorage.setItem(STORAGE,JSON.stringify(next));window.dispatchEvent(new CustomEvent('makken:navigation-changed'));return next;}
  function draft(groups){const state=get();state.draft=normalize(groups);state.revision++;return save(state);}
  function publish(){const state=get();state.history.unshift({at:new Date().toISOString(),groups:clone(state.published)});state.history=state.history.slice(0,10);state.published=clone(state.draft);state.revision++;state.publishedAt=new Date().toISOString();return save(state);}
  function restore(index){const state=get(),hist=state.history[Number(index)];if(!hist)throw new Error('الإصدار غير موجود');
    state.history.unshift({at:new Date().toISOString(),groups:clone(state.published)});state.history=state.history.slice(0,10);
    state.published=normalize(hist.groups);state.draft=clone(state.published);state.revision++;state.publishedAt=new Date().toISOString();return save(state);
  }
  function reset(){const state=initial();return save(state);}
  function role(){try{const r=localStorage.getItem(ROLE_KEY);return Object.hasOwn(ROLES,r)?r:'admin'}catch{return 'admin'}}
  function setRole(r){if(!Object.hasOwn(ROLES,r))throw new Error('دور غير صالح');localStorage.setItem(ROLE_KEY,r);window.dispatchEvent(new CustomEvent('makken:navigation-changed'));}
  function visible(groups,modules,selectedRole){const r=Object.hasOwn(ROLES,selectedRole)?selectedRole:role();
    return normalize(groups).filter(g=>g.enabled&&g.roles.includes(r)).map(g=>({...g,items:g.items.filter(i=>i.enabled&&i.roles.includes(r)&&(!i.module||modules[i.module]))})).filter(g=>g.items.length);
  }
  w.MakkenNav={STORAGE,ROLES,ICONS,SCREENS,SCREEN_MODULE,DEPARTMENTS,defaultMenu,normalize,get,save,draft,publish,restore,reset,role,setRole,visible,uid,clone};
})(window);
