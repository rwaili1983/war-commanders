'use strict';
// Purely local demonstration. Never an attendance source of truth.
(() => {
 const $ = id => document.getElementById(id);
 let record = null;
 const display=()=>{
   $('status').textContent=record?(record.out?'اكتمل اليوم':'تم تسجيل الحضور'):'لم يتم التسجيل';
   $('status').className='status'+(record?(record.out?' done':' active'):'');
   $('inTime').textContent=record?record.in:'—';
   $('outTime').textContent=record?.out||'—';
   $('worked').textContent=record?.out?'7 ساعات و5 دقائق (افتراضي)':'—';
   $('late').textContent=record?'0 دقائق (افتراضي)':'—';
   $('clockIn').disabled=!!record;
   $('clockOut').disabled=!record||!!record.out;
 };
 $('clockIn').addEventListener('click',()=>{
   if(record)return;
   record={in:'08:07',out:null};
   $('notice').textContent='تم تسجيل حضور افتراضي 08:07. لم تُرسل معلومات إلى أي خادم.';
   display();
 });
 $('clockOut').addEventListener('click',()=>{
   if(!record||record.out)return;
   record.out='15:12';
   $('notice').textContent='تم الانصراف الافتراضي عند 15:12؛ القيم تعليمية فقط ولا تؤثر على الرواتب.';
   display();
 });
 $('reset').addEventListener('click',()=>{
   record=null;$('notice').textContent='تمت إعادة ضبط التجربة دون حذف بيانات خادم.';display();
 });
 const close=()=>{
  $('drawer').classList.remove('open');$('drawer').inert=true;$('veil').hidden=true;
  $('menuToggle').setAttribute('aria-expanded','false');$('menuToggle').focus();
 };
 $('menuToggle').addEventListener('click',()=>{
  $('drawer').inert=false;$('veil').hidden=false;$('drawer').classList.add('open');
  $('menuToggle').setAttribute('aria-expanded','true');$('closeDrawer').focus();
 });
 $('closeDrawer').addEventListener('click',close);
 $('veil').addEventListener('click',close);
 document.addEventListener('keydown',e=>{if(e.key==='Escape' && $('drawer').classList.contains('open'))close();});
 document.querySelectorAll('#drawer a').forEach(a=>a.addEventListener('click',close));
 display();
})();
