/* Demonstration-only access simulation. NEVER use browser-side logic as authorization. */
(function () {
'use strict';
const scenarios = {
 active: {label:'موظف نشط في إدارة المساعدات',module:true,view:true,all:false,dept:1},
 inactive: {label:'موظف موقوف؛ لا تتاح له إدارة فعالة',module:true,view:true,all:false,dept:null},
 department_off: {label:'الإدارة معطلة؛ لا تتاح طلباتها',module:true,view:true,all:false,dept:null},
 global: {label:'صلاحيتا العرض والعرض الشامل صادرتان معًا',module:true,view:true,all:true,dept:null},
 global_without_base: {label:'الصلاحية الشاملة وحدها غير كافية',module:true,view:false,all:true,dept:null},
 module_off: {label:'الوحدة معطلة على الخادم',module:false,view:true,all:true,dept:null},
};
const applications = [
 {reference:'MK-DEMO-001',dept:1,label:'إدارة المساعدات'},
 {reference:'MK-DEMO-002',dept:2,label:'إدارة الإسكان'},
 {reference:'MK-DEMO-003',dept:null,label:'غير مسند لإدارة'},
];
function mayView(s, r) {
 if (!s.module || !s.view) return false;
 if (s.all) return true;
 return Number.isInteger(s.dept) && s.dept>0 && Number.isInteger(r.dept) && r.dept>0 && s.dept===r.dept;
}
function render() {
 const scenario=scenarios[document.getElementById('ba-role').value]||scenarios.inactive;
 const accessible=applications.filter(r=>mayView(scenario,r));
 document.getElementById('ba-count').textContent=String(accessible.length)+' / '+String(applications.length);
 document.getElementById('ba-description').textContent=scenario.label;
 const target=document.getElementById('ba-records');target.replaceChildren();
 applications.forEach(r=>{
  const allowed=mayView(scenario,r), article=document.createElement('article');article.className='ba-record';
  const title=document.createElement('strong');title.textContent=r.reference;
  const dept=document.createElement('span');dept.textContent='الإدارة: '+r.label;
  const result=document.createElement('p');result.className='ba-result';result.textContent=allowed?'✓ مسموح بعرض الطلب':'🔒 الطلب محجوب';
  article.append(title,dept,result);target.appendChild(article);
 });
}
document.getElementById('ba-role').addEventListener('change',render);
render();
})();
