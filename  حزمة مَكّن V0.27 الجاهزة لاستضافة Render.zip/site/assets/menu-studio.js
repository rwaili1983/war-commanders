/* Interactive no-backend navigation studio, V0.18. */
(function () {
'use strict';
const N=window.MakkenNav,M=window.Makken,esc=M.esc,SERVER=window.MakkenNavServer||null;
let serverReady=!SERVER;
let state=N.get(),working=N.clone(state.draft),selection={type:'group',id:working[0]?.id},previewRole='admin',dirty=false,drag=null;
const $=id=>document.getElementById(id);
async function api(url,method='GET',body=null){
 const headers={'Accept':'application/json'};if(body!==null){headers['Content-Type']='application/json';headers['X-CSRF-TOKEN']=SERVER.csrf;}
 const response=await fetch(url,{method,headers,credentials:'same-origin',body:body===null?null:JSON.stringify(body)});
 let json={};try{json=await response.json()}catch{}
 if(!response.ok)throw new Error(response.status===409?'تعارض تعديل: حدّث الصفحة قبل الحفظ':(json.message||'فشل الاتصال بالخادم: '+response.status));
 return json;
}
function notify(t,err=false){const el=$('studioNotice');el.textContent=t;el.classList.toggle('error',err)}
function selected(){if(!selection)return null;for(const g of working){if(selection.type==='group'&&g.id===selection.id)return g;if(selection.type==='item'){const it=g.items.find(x=>x.id===selection.id);if(it)return it}}return null}
function groupFor(itemId){return working.find(g=>g.items.some(i=>i.id===itemId))}
function setSelection(type,id){selection={type,id};render()}
function move(arr,index,offset){const j=index+offset;if(j<0||j>=arr.length)return false;[arr[index],arr[j]]=[arr[j],arr[index]];return true}
function mutate(){dirty=true;render()}
function catOptions(){return N.DEPARTMENTS.map((t,i)=>`<option value="${i}">${String(i+1).padStart(2,'0')} — ${esc(t)}</option>`).join('')}
function renderTree(){
 $('treeCount').textContent=`${working.length} مجموعة — ${working.reduce((a,g)=>a+g.items.length,0)} صفحة`;
 $('studioTree').innerHTML=working.map((g,ix)=>`
  <section class="studio-group ${selection?.type==='group'&&selection?.id===g.id?'selected':''}" draggable="true" data-group="${g.id}" data-drop-group="${g.id}">
   <div class="studio-group-head"><span class="icon-box" aria-hidden="true">${esc(g.icon)}</span>
    <button class="studio-tree-select" data-select-group="${g.id}" aria-label="تعديل ${esc(g.title)}">${esc(g.title)} ${g.enabled?'':'(مخفية)'}</button>
    <div class="studio-action-group"><button class="tree-btn" data-group-up="${g.id}" aria-label="تحريك الإدارة للأعلى" ${ix===0?'disabled':''}>↑</button><button class="tree-btn" data-group-down="${g.id}" aria-label="تحريك الإدارة للأسفل" ${ix===working.length-1?'disabled':''}>↓</button></div></div>
    <div class="studio-items">${g.items.map((it,j)=>`
     <div class="studio-item ${selection?.type==='item'&&selection.id===it.id?'selected':''}" draggable="true" data-item="${it.id}" data-drop-item="${it.id}" data-parent="${g.id}">
       <span class="icon-box" aria-hidden="true">${esc(it.icon)}</span>
       <button class="studio-tree-select" data-select-item="${it.id}" aria-label="تعديل صفحة ${esc(it.title)}">${esc(it.title)}${it.enabled?'':' (مخفية)'}</button>
       <div class="studio-action-group"><button class="tree-btn" data-item-up="${it.id}" aria-label="تحريك الصفحة للأعلى" ${j===0?'disabled':''}>↑</button><button class="tree-btn" data-item-down="${it.id}" aria-label="تحريك الصفحة للأسفل" ${j===g.items.length-1?'disabled':''}>↓</button></div>
     </div>`).join('')}
     <button class="mini-btn studio-add" data-add-item="${g.id}">＋ إضافة صفحة فرعية</button>
    </div>
   </section>`).join('')||'<div class="studio-empty">ابدأ بإضافة إدارة جديدة</div>';
}
function renderRoles(target){return `<div class="studio-checks">${Object.entries(N.ROLES).map(([r,label])=>`<label><input type="checkbox" name="role" value="${r}" ${target.roles.includes(r)?'checked':''}>${esc(label)}</label>`).join('')}</div>`}
function renderProperties(){const obj=selected();if(!obj){$('studioProperties').innerHTML='<div class="studio-empty">اختر إدارة أو صفحة لتعديل خصائصها</div>';return}
const group=selection.type==='group';
const fields=`<form id="itemForm" autocomplete="off"><label class="studio-field">${group?'اسم الإدارة':'اسم الصفحة'}<input class="form-control" name="title" maxlength="80" required value="${esc(obj.title)}"></label>
<div class="studio-inline"><label class="studio-field">الأيقونة<select class="form-control" name="icon">${N.ICONS.map(i=>`<option value="${esc(i)}" ${obj.icon===i?'selected':''}>${esc(i)}</option>`).join('')}</select></label>
<label class="studio-field">الحالة<select class="form-control" name="enabled"><option value="true" ${obj.enabled?'selected':''}>مفعّل</option><option value="false" ${!obj.enabled?'selected':''}>مخفي</option></select></label></div>
<div class="studio-field"><span>الأدوار التي يمكنها رؤية ${group?'الإدارة':'الصفحة'} في نسخة العرض</span>${renderRoles(obj)}<small>للعرض التجريبي فقط — الصلاحيات الحقيقية تتحقق على الخادم.</small></div>
${!group?`<label class="studio-field">نوع الصفحة<select class="form-control" name="kind"><option value="screen" ${obj.kind==='screen'?'selected':''}>شاشة جاهزة</option><option value="custom" ${obj.kind==='custom'?'selected':''}>صفحة تعريفية مخصصة (تجريبية)</option></select></label>
<div id="screenField"><label class="studio-field">الشاشة المرتبطة<select class="form-control" name="screen">${Object.entries(N.SCREENS).map(([v,t])=>`<option value="${esc(v)}" ${obj.screen===v?'selected':''}>${esc(t)}</option>`).join('')}</select></label></div>
<div id="customField"><label class="studio-field">نص الصفحة التجريبية<textarea name="content" class="form-control" maxlength="2000" rows="5">${esc(obj.content||'')}</textarea></label></div>`:''}
<button class="btn" type="submit">تطبيق التعديلات على المسودة</button></form><button class="mini-btn studio-danger" id="deleteSelection" style="margin-top:12px;width:100%">حذف ${group?'الإدارة':'الصفحة'}</button>`;
$('studioProperties').innerHTML=fields;showKind();}
function showKind(){const form=$('itemForm');if(!form||selection?.type==='group')return;const custom=form.elements.kind.value==='custom';$('screenField').hidden=custom;$('customField').hidden=!custom}
function renderPreview(){
 $('menuPreview').innerHTML=N.visible(working,(window.MakkenNavModules||M.get().modules),previewRole).map(g=>`<section class="preview-group"><div class="preview-head"><span>${esc(g.icon)}</span><span>${esc(g.title)}</span></div>${g.items.map(it=>`<div class="preview-link"><span>${esc(it.icon)}</span>${esc(it.title)}</div>`).join('')}</section>`).join('')||'<p class="preview-empty">لا توجد عناصر مرئية لهذا الدور والوحدات المفعلة</p>';
 $('dirtyLabel').textContent=dirty?'تغييرات لم تُحفظ':'المسودة محفوظة';
 $('savedLabel').textContent=state.publishedAt?'آخر نشر: '+new Date(state.publishedAt).toLocaleString('ar-SA'):'التكوين الأصلي منشور';
 const revisions=$('revisions');const value=revisions.value;
 revisions.innerHTML=state.history.map((h,i)=>`<option value="${i}">${esc(new Date(h.at).toLocaleString('ar-SA'))}</option>`).join('')||'<option value="">لا توجد نسخ سابقة</option>';
 if(value&&state.history[Number(value)])revisions.value=value;
 $('restoreRevision').disabled=!state.history.length;
}
function render(){renderTree();renderProperties();renderPreview()}
function addGroup(name='إدارة جديدة'){
 if(working.length>=40){notify('وصلت إلى الحد الأعلى للمجموعات',true);return}
 const id=N.uid('group');working.push({id,title:name,icon:'🏢',enabled:true,roles:Object.keys(N.ROLES),items:[]});selection={type:'group',id};mutate();notify('أُضيفت الإدارة إلى المسودة؛ احفظها ثم انشرها.');}
function addItem(groupId){const group=working.find(g=>g.id===groupId);if(!group)return;if(group.items.length>=30){notify('الحد الأعلى 30 صفحة في الإدارة',true);return}
 const id=N.uid('item');group.items.push({id,title:'صفحة جديدة',icon:'📋',enabled:true,roles:Object.keys(N.ROLES),kind:'custom',screen:'',module:'',content:'هذه صفحة تعريفية تجريبية قابلة للتعديل.'});selection={type:'item',id};mutate();notify('أُضيفت الصفحة إلى المسودة');}
async function save(){try{
 if(SERVER){if(!serverReady)throw new Error('لم يكتمل تحميل صلاحيات الخادم');state=await api(SERVER.update,'PUT',{draft:N.normalize(working),revision:state.revision});}
 else state=N.draft(working);
 working=N.clone(state.draft);dirty=false;render();notify('تم حفظ المسودة. لا تؤثر على القائمة المنشورة حتى النشر.');return true
 }catch(err){notify(err.message,true);return false}}
async function publish(){if(dirty&&!(await save()))return;if(!window.confirm('نشر القائمة سيعتمد التغييرات الجديدة. متابعة؟'))return;try{
 state=SERVER?await api(SERVER.publish,'POST',{revision:state.revision}):N.publish();
 working=N.clone(state.draft);dirty=false;render();notify('تم نشر القائمة بنجاح.')
 }catch(err){notify(err.message,true)}}
function handleAction(target){const a=target.closest('button');if(!a)return;
 for(const kind of ['select-group','select-item']){const id=a.dataset[kind==='select-group'?'selectGroup':'selectItem'];if(id){setSelection(kind==='select-group'?'group':'item',id);return}}
 if(a.dataset.addItem){addItem(a.dataset.addItem);return}
 for(const type of ['group','item'])for(const delta of [-1,1]){
  const id=a.dataset[type+(delta===-1?'Up':'Down')];if(!id)continue;
  if(type==='group'){const ix=working.findIndex(g=>g.id===id);if(ix>=0&&move(working,ix,delta))mutate()}
  else {const g=groupFor(id);if(g){const ix=g.items.findIndex(x=>x.id===id);if(move(g.items,ix,delta))mutate()}}
  return;
 }
}
function wireDnd(){const tree=$('studioTree');tree.addEventListener('dragstart',ev=>{const item=ev.target.closest('[data-item]');const group=ev.target.closest('[data-group]');if(item){drag={type:'item',id:item.dataset.item};}else if(group){drag={type:'group',id:group.dataset.group};}else return;ev.dataTransfer.effectAllowed='move';ev.dataTransfer.setData('text/plain',drag.id)});
 tree.addEventListener('dragover',ev=>{if(drag&&ev.target.closest('[data-drop-group],[data-drop-item]')){ev.preventDefault();ev.dataTransfer.dropEffect='move'}});
 tree.addEventListener('drop',ev=>{if(!drag)return;ev.preventDefault();const targetItem=ev.target.closest('[data-drop-item]');const targetGroup=ev.target.closest('[data-drop-group]');
  if(drag.type==='group'&&targetGroup){const src=working.findIndex(x=>x.id===drag.id),dst=working.findIndex(x=>x.id===targetGroup.dataset.dropGroup);if(src>=0&&dst>=0&&src!==dst){const [g]=working.splice(src,1);working.splice(dst,0,g);mutate()}}
  if(drag.type==='item'&&(targetItem||targetGroup)){
    const source=groupFor(drag.id);const dest=working.find(x=>x.id===(targetItem?targetItem.dataset.parent:targetGroup.dataset.dropGroup));
    if(source&&dest){const si=source.items.findIndex(x=>x.id===drag.id);if(si>=0){const [it]=source.items.splice(si,1);const ti=targetItem?dest.items.findIndex(x=>x.id===targetItem.dataset.dropItem):dest.items.length;
       if(dest.items.length>=30){source.items.splice(si,0,it);notify('الإدارة المستهدفة ممتلئة',true)}else {dest.items.splice(Math.max(0,ti),0,it);mutate()}}}
  }
  drag=null;
 });tree.addEventListener('dragend',()=>drag=null)}
function download(content,filename){const blob=new Blob([content],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
function init(){
 $('catalogSelect').innerHTML=catOptions();$('previewRole').innerHTML=Object.entries(N.ROLES).map(([id,title])=>`<option value="${id}">${esc(title)}</option>`).join('');$('previewRole').value=previewRole;
 $('studioTree').addEventListener('click',ev=>handleAction(ev.target));wireDnd();
 $('studioProperties').addEventListener('change',ev=>{if(ev.target.name==='kind')showKind()});
 $('studioProperties').addEventListener('submit',ev=>{if(ev.target.id!=='itemForm')return;ev.preventDefault();const obj=selected();if(!obj)return;const form=ev.target;const data=new FormData(form);const roles=data.getAll('role');if(!roles.length){notify('حدد دورًا واحدًا على الأقل',true);return}
 obj.title=String(data.get('title')||'').trim().slice(0,80);obj.icon=data.get('icon');obj.enabled=data.get('enabled')==='true';obj.roles=roles;
 if(selection.type==='item'){obj.kind=data.get('kind')==='custom'?'custom':'screen';obj.screen=obj.kind==='screen'?data.get('screen'):'';obj.content=obj.kind==='custom'?String(data.get('content')||'').slice(0,2000):'';obj.module=obj.kind==='screen'?(N.SCREEN_MODULE[obj.screen]||''):''}
 try{N.normalize(working);mutate();notify('تم تطبيق التغييرات على المسودة. احفظ وانشر بعد المراجعة.')}catch(err){notify(err.message,true)}
 });
 $('studioProperties').addEventListener('click',ev=>{if(ev.target.id!=='deleteSelection')return;const obj=selected();if(!obj)return;if(!confirm('حذف «'+obj.title+'» من المسودة؟'))return;
 if(selection.type==='group')working=working.filter(x=>x.id!==obj.id);else {const g=groupFor(obj.id);if(g)g.items=g.items.filter(x=>x.id!==obj.id)}
 selection=working.length?{type:'group',id:working[0].id}:null;mutate();notify('حُذف العنصر من المسودة')
 });
 $('addGroup').onclick=()=>addGroup();$('catalogToggle').onclick=()=>$('catalogBox').hidden=!$('catalogBox').hidden;
 $('catalogAdd').onclick=()=>addGroup(N.DEPARTMENTS[Number($('catalogSelect').value)]||'إدارة جديدة');
 $('saveDraft').onclick=save;$('publishNav').onclick=publish;
 $('resetStudio').onclick=()=>{if(!confirm('استعادة الهيكل الأصلي في المسودة؟'))return;
 if(SERVER){working=N.defaultMenu();dirty=true;}else{state=N.reset();working=N.clone(state.draft);dirty=false;}
 selection={type:'group',id:working[0].id};render();notify('أعيد الهيكل الأصلي. احفظ وانشر عند التأكد.');};
 $('exportStudio').onclick=async()=>{if(dirty&&!(await save()))return;download(JSON.stringify({schema:1,draft:working},null,2),'makken-menu-v018.json');notify('صُدّرت المسودة كملف JSON')};
 $('importFile').onchange=async ev=>{const file=ev.target.files[0];if(!file)return;if(file.size>200000){notify('الملف أكبر من الحجم المسموح',true);return}
  try{const parsed=JSON.parse(await file.text());working=N.normalize(parsed.draft||parsed.groups);selection=working.length?{type:'group',id:working[0].id}:null;mutate();notify('تم استيراد مسودة آمنة. راجعها قبل الحفظ والنشر.')}catch(err){notify('تعذر استيراد الملف: '+err.message,true)}ev.target.value='';
 };
 $('previewRole').onchange=ev=>{previewRole=ev.target.value;renderPreview()};
 $('applyDemoRole').onclick=()=>{N.setRole(previewRole);notify('تم تعيين الدور للمحاكاة في لوحة التحكم. يمكن العودة إلى مدير النظام من هنا.')};
 $('restoreRevision').onclick=async()=>{const i=$('revisions').value;if(i===''||!state.history[Number(i)])return;if(!confirm('استعادة هذا الإصدار المنشور؟'))return;try{
 state=SERVER?await api(SERVER.rollback,'POST',{revision:state.revision,history_index:Number(i)}):N.restore(i);
 working=N.clone(state.draft);dirty=false;selection={type:'group',id:working[0]?.id};render();notify('استعيد الإصدار المنشور بنجاح.')
 }catch(err){notify(err.message,true)}};
 window.addEventListener('beforeunload',ev=>{if(dirty){ev.preventDefault();ev.returnValue=''}});
 render();if(SERVER){
  $('saveDraft').disabled=true;$('publishNav').disabled=true;
  api(SERVER.draft).then(data=>{state=data;working=N.normalize(data.draft);serverReady=true;selection={type:'group',id:working[0]?.id};$('saveDraft').disabled=false;$('publishNav').disabled=false;render();notify('تم تحميل القائمة المحفوظة على خادم Laravel.');}).catch(err=>notify('تعذر تحميل قائمة الخادم: '+err.message,true));
 }else notify('يمكنك تخصيص المسودة الآن، ثم حفظها ونشرها.');
}
document.addEventListener('DOMContentLoaded',init);
})();
