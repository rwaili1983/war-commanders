/* Makken V0.15 page blueprint. Preview storage only; NOT a permission or publishing backend. */
(function (w) {
  'use strict';
  const KEY = 'makken_builder_v015';
  const KEYS = ['stats','projects','news','gallery','about'];
  const LABELS = {stats:'الإحصاءات',projects:'المشاريع',news:'الأخبار والإعلانات',gallery:'ألبوم الصور',about:'عن الجمعية'};
  const TYPES = ['cards','editorial','minimal'];
  const DEFAULT = {
    header:{title:'جمعية الأثر التنموية',subtitle:'بوابة الخدمات والمبادرات',style:'standard',sticky:true},
    hero:{eyebrow:'أهلًا بك في منصة العطاء',title:'من العطاء تبدأ الحكايات الجميلة',description:'نسعى إلى بناء فرص حياة أفضل للأسر بالشراكة مع مجتمع يؤمن بأن العطاء يصنع أثرًا مستدامًا.',background:'aurora',ctaText:'استكشف المشاريع',ctaUrl:'#projects'},
    sections:[
      {key:'stats',title:'أثرنا بالأرقام',subtitle:'إحصاءات تعرّفك على أنشطة الجمعية',visible:true,style:'cards'},
      {key:'projects',title:'مشاريع تستحق الدعم',subtitle:'اكتشف مشاريع الجمعية ومراحل تمويلها في متجر المشاريع.',visible:true,style:'cards'},
      {key:'news',title:'آخر الأخبار والإعلانات',subtitle:'تابع مستجدات البرامج والأنشطة والإعلانات الرسمية.',visible:true,style:'editorial'},
      {key:'gallery',title:'ألبوم الصور والأنشطة',subtitle:'لمحات من مبادرات الخير والتمكين والعمل المجتمعي.',visible:true,style:'cards'},
      {key:'about',title:'بوابة واحدة تجمع خدمات الجمعية',subtitle:'بوابة المستفيدين ولوحة إدارة مستقلة للموظفين.',visible:true,style:'minimal'}
    ],
    cards:{style:'raised',radius:'rounded'},
    footer:{description:'نموذج تسويقي لمنصة مكن؛ جميع المحتويات والبيانات استعراضية.',showLinks:true,copyright:'منصة مَكّن'},
    announcement:{text:''}
  };
  const clone=v=>JSON.parse(JSON.stringify(v));
  const str=(v,limit)=>String(typeof v==='string'?v:'').trim().slice(0,limit);
  const choose=(value,allowed,def)=>allowed.includes(value)?value:def;
  function normalize(raw){
    const input=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
    const h=input.header||{},hero=input.hero||{},f=input.footer||{},cards=input.cards||{},ad=input.announcement||{};
    const rawSections=Array.isArray(input.sections)?input.sections:DEFAULT.sections;
    const seen=new Set();const sections=[];
    for(const item of rawSections){if(!item||typeof item!=='object'||!KEYS.includes(item.key)||seen.has(item.key))continue;
      seen.add(item.key);const d=DEFAULT.sections.find(x=>x.key===item.key);
      sections.push({key:item.key,title:str(item.title,100)||d.title,subtitle:str(item.subtitle,220),visible:item.visible!==false,style:choose(item.style,TYPES,d.style)});
    }
    for(const d of DEFAULT.sections)if(!seen.has(d.key))sections.push(clone(d));
    const url=str(hero.ctaUrl,120);
    return {header:{title:str(h.title,110)||DEFAULT.header.title,subtitle:str(h.subtitle,110),style:choose(h.style,['standard','centered','minimal'],'standard'),sticky:h.sticky!==false},
      hero:{eyebrow:str(hero.eyebrow,100),title:str(hero.title,160)||DEFAULT.hero.title,description:str(hero.description,350),background:choose(hero.background,['aurora','solid','light','sand'],'aurora'),ctaText:str(hero.ctaText,60)||DEFAULT.hero.ctaText,ctaUrl:(/^#[a-z-]+$/.test(url)||/^\/(?!\/)[a-zA-Z0-9/_#-]*$/.test(url))?url:'#projects'},
      sections,cards:{style:choose(cards.style,['raised','outlined','flat'],'raised'),radius:choose(cards.radius,['rounded','square'],'rounded')},
      footer:{description:str(f.description,250),showLinks:f.showLinks!==false,copyright:str(f.copyright,100)||DEFAULT.footer.copyright},announcement:{text:str(ad.text,220)}};
  }
  function legacyDefaults(){
    const v=clone(DEFAULT);
    // Preserve V0.14 local edits when the page-builder key is first created.
    try{if(w.Makken&&typeof w.Makken.get==='function'){
      const old=w.Makken.get(),st=old.settings||{};
      v.header.title=str(st.organization,110)||v.header.title;
      v.hero.title=str(st.hero,160)||v.hero.title;
      v.hero.description=str(st.about,350)||v.hero.description;
      v.announcement.text=str(st.announcement,220);
      const oldSections=Array.isArray(old.sections)?old.sections:[];
      if(oldSections.length){const order=['stats',...oldSections.map(x=>x.id)];
        v.sections=order.filter((key,i)=>order.indexOf(key)===i&&KEYS.includes(key))
          .map(key=>{const copy=clone(DEFAULT.sections.find(x=>x.key===key));const prior=oldSections.find(x=>x.id===key);if(prior)copy.visible=prior.enabled!==false;return copy});
        for(const section of DEFAULT.sections)if(!v.sections.some(x=>x.key===section.key))v.sections.push(clone(section));
      }
    }}catch(e){}
    return v;
  }
  function load(){try{const v=JSON.parse(localStorage.getItem(KEY)||'null');if(v&&v.schema===1&&v.draft&&v.published)return {schema:1,draft:normalize(v.draft),published:normalize(v.published),revision:Math.max(0,Number(v.revision)||0),history:Array.isArray(v.history)?v.history.slice(0,15):[]};}catch(e){}const previous=legacyDefaults();return {schema:1,draft:clone(previous),published:clone(previous),revision:0,history:[]}}
  function persist(data){localStorage.setItem(KEY,JSON.stringify(data));w.dispatchEvent(new CustomEvent('makken:builder-change'));return data;}
  const api={KEY,DEFAULT:clone(DEFAULT),LABELS,normalize,load,
    saveDraft:(raw)=>{const db=load();db.draft=normalize(raw);persist(db);return db;},
    publish:()=>{const db=load();db.history.unshift({revision:db.revision,at:new Date().toISOString(),layout:clone(db.published)});db.history=db.history.slice(0,15);db.published=normalize(db.draft);db.revision++;persist(db);return db;},
    discardDraft:()=>{const db=load();db.draft=clone(db.published);persist(db);return db;},
    rollback:(index)=>{const db=load(),old=db.history[Number(index)];if(!old||!old.layout)throw new Error('الإصدار غير متوفر');db.history.splice(Number(index),1);db.history.unshift({revision:db.revision,at:new Date().toISOString(),layout:clone(db.published)});db.published=normalize(old.layout);db.draft=clone(db.published);db.revision++;persist(db);return db;},
    export:()=>JSON.stringify({schema:1,draft:load().draft,published:load().published,revision:load().revision},null,2),
    import:(json)=>{if(typeof json!=='string'||json.length>100000)throw new Error('ملف غير صالح أو كبير جدًا');const file=JSON.parse(json);if(!file||file.schema!==1||!file.draft)throw new Error('صيغة الملف غير مدعومة');const db=load();db.draft=normalize(file.draft);persist(db);return db;}
  };
  w.MakkenBuilder=api;
})(window);
