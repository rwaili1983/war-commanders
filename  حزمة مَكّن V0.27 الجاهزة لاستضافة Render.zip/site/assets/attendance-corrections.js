'use strict';
/* In-memory demo only. Security and real clock calculations belong to Laravel. */
(() => {
 const $ = id => document.getElementById(id);
 const requests = [];
 const events = [];
 const localDate = () => new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 $('day').value=localDate(); $('day').max=localDate();
 function mark(type,text){ events.unshift({type,text}); render(); }
 function safeText(tag,text,cls){const el=document.createElement(tag);if(cls)el.className=cls;el.textContent=text;return el;}
 function render(){
  $('pendingCount').textContent=requests.filter(x=>x.status==='pending').length;
  $('approvedCount').textContent=requests.filter(x=>x.status==='approved').length;
  $('queue').replaceChildren(); $('timeline').replaceChildren();
  if(!requests.length)$('queue').append(safeText('p','لا توجد طلبات معلقة.','notice'));
  requests.forEach((r,i)=>{
   const item=document.createElement('article'); item.className='request-item';
   item.append(safeText('h4','طلب رقم '+(i+1)+' · '+r.day),safeText('p','التوقيت المطلوب: '+r.start+' – '+r.end),safeText('p','السبب: '+r.reason));
   item.append(safeText('span',({pending:'بانتظار المراجعة',approved:'معتمد تجريبيًا',rejected:'مرفوض تجريبيًا'})[r.status],'status-label '+r.status));
   if(r.status==='pending'){
    const actions=document.createElement('div');actions.className='actions';
    [['اعتماد تجريبي','approved'],['رفض تجريبي','rejected']].forEach(([label,status])=>{
     const b=safeText('button',label);b.type='button';if(status==='rejected')b.className='reject';
     b.addEventListener('click',()=>{r.status=status;mark(status,'قرار '+(status==='approved'?'اعتماد':'رفض')+' تجريبي للطلب '+(i+1)+' — لا تغيّر على الخادم');});actions.append(b);
    });item.append(actions);
   }
   $('queue').append(item);
  });
  if(!events.length)$('timeline').append(safeText('p','لم تُسجل أحداث بعد.'));
  events.forEach(event=>$('timeline').append(safeText('p',event.text)));
 }
 $('requestForm').addEventListener('submit',event=>{
  event.preventDefault();
  const date=$('day').value,start=$('start').value,end=$('end').value,reason=$('reason').value.trim();
  const today=localDate();const day=new Date(date+'T12:00:00Z');
  const age=Math.round((new Date(today+'T12:00:00Z')-day)/86400000);
  if(!date||!start||!end||!Number.isFinite(age)||age<0||age>30||start>=end||reason.length<6||requests.some(r=>r.day===date&&r.status==='pending')){
   $('formMessage').textContent='راجع التاريخ (آخر 30 يومًا)، وترتيب الأوقات والسبب؛ لا يمكن تكرار طلب معلق لليوم نفسه.';return;
  }
  requests.unshift({day:date,start,end,reason,status:'pending'});
  $('reason').value=''; $('formMessage').textContent='تمت إضافة طلب تجريبي للمراجعة، ولم يُغيّر أي سجل حقيقي.';
  mark('submitted','طلب تصحيح جديد ليوم '+date+' — بانتظار المراجعة');
 });
 $('clearDemo').addEventListener('click',()=>{requests.length=0;events.length=0;$('formMessage').textContent='تمت إعادة ضبط بيانات التجربة فقط.';render();});
 const close=()=>{$('drawer').classList.remove('open');$('drawer').inert=true;$('veil').hidden=true;$('menuToggle').setAttribute('aria-expanded','false');$('menuToggle').focus();};
 $('menuToggle').addEventListener('click',()=>{$('drawer').inert=false;$('veil').hidden=false;$('drawer').classList.add('open');$('menuToggle').setAttribute('aria-expanded','true');$('closeDrawer').focus();});
 $('closeDrawer').addEventListener('click',close);$('veil').addEventListener('click',close);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('drawer').classList.contains('open'))close();});
 document.querySelectorAll('#drawer a').forEach(a=>a.addEventListener('click',close));
 render();
})();
