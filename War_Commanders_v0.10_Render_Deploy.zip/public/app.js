(() => {
  'use strict';
  const E=window.WarEngine;
  const assetURL=p=>window.WarAssetMap?.[p]||p;
  const $=id=>document.getElementById(id);
  const $$=selector=>Array.from(document.querySelectorAll(selector));
  const cvs=$('battleCanvas'), ctx=cvs.getContext('2d');
  const mini=$('minimap'), mx=mini.getContext('2d');
  const renderer3d=window.WarRenderer3D?.create($('battle3D'),$('weatherCanvas'));
  let use3D=!!renderer3d?.ready, weatherIndex=0, highQuality=false;
  const weatherList=[{name:'صحو',icon:'☀',kind:'clear'},{name:'عاصفة رملية',icon:'🌪',kind:'dust'},{name:'أمطار',icon:'🌧',kind:'rain'},{name:'ليل',icon:'☾',kind:'night'}];
  let state=E.createState({stage:1}), playing=false, paused=false, view='home', showcaseMode=false, activeCustomMap=null;
  let mode='solo', myTeam=1, session=null, serverOnline=false, eventSource=null, serverStats=null;
  let selected=[], selectedBuildingId=null, pendingBuild=null, panMode=false, drag=null, touchContacts=new Map(), pinch=null, ignoreGestureUntilClear=false, lastFrame=performance.now(), lastUI=0, latestLog=0;
  let cam={cx:600,cy:360,zoom:1};
  let audioOn=false, musicOn=false, actBusy=false, toastTimer=null, resultHandled=false, last3DRender=0;
  const assetsRoot='assets/images/';
  const artSprites={};
  for(const category of ['unit','building'])for(const name of category==='unit'?['infantry','scout','tank','artillery','helicopter','jet','rocket','antiair','engineer','patrol','destroyer']:['hq','factory','refinery','tower','barracks','airbase','radar','dock']){
    const im=new Image();im.src=assetURL(assetsRoot+category+'-'+name+'.svg');artSprites[name]=im;
  }
  const terrainImgs={};
  for(const name of ['desert','dust','forest','night','snow','coast','canyon']){const im=new Image();im.src=assetURL(assetsRoot+'terrain-'+name+'.webp');terrainImgs[name]=im;}
  const soundFiles=['ui-click','unit-select','build','train','invalid','rifle','cannon','explosion','victory','defeat','helicopter','jet','wind','rain'];
  const audioFiles={};for(const name of soundFiles){const el=new Audio(assetURL('assets/audio/'+name+'.wav'));el.preload='auto';audioFiles[name]=el;}
  const ambient=new Audio(assetURL('assets/audio/ambient-loop.wav'));ambient.loop=true;ambient.volume=.21;ambient.preload='auto';
  let seenFx=new Set(),lastShotSound=0;
  const weatherAudio=new Audio(assetURL('assets/audio/wind.wav'));weatherAudio.loop=true;weatherAudio.volume=.16;
  const rainAudio=new Audio(assetURL('assets/audio/rain.wav'));rainAudio.loop=true;rainAudio.volume=.18;
  function updateWeatherAudio(){weatherAudio.pause();rainAudio.pause();if(!audioOn||!playing||view!=='game'||paused)return;const kind=weatherList[weatherIndex].kind;if(kind==='dust')weatherAudio.play().catch(()=>{});if(kind==='rain')rainAudio.play().catch(()=>{});}
  function playSound(name,volume=.6){if(!audioOn)return;try{const original=audioFiles[name];if(!original)return;const el=original.cloneNode();el.volume=volume;el.play().catch(()=>{});}catch{}}
  function updateAudioButtons(){$('soundBtn').textContent=audioOn?'🔊':'🔇';$('musicBtn').textContent=musicOn?'♬':'♫';$('soundBtn').classList.toggle('active',audioOn);$('musicBtn').classList.toggle('active',musicOn);$('soundBtn').setAttribute('aria-pressed',String(audioOn));$('musicBtn').setAttribute('aria-pressed',String(musicOn));}
  function inspectEffects(){if(!playing||paused||!state?.effects?.length)return;const now=performance.now();for(const fx of state.effects){if(seenFx.has(fx.id))continue;seenFx.add(fx.id);if(now-lastShotSound>110){if(fx.kind==='blast')playSound('explosion',.18);else if(fx.kind==='airstrike')playSound('jet',.3);else if(fx.kind==='heavy')playSound('cannon',.25);else if(fx.kind==='shot')playSound('rifle',.09);lastShotSound=now;}}if(seenFx.size>4000)seenFx.clear();}
  const colors={1:'#69d7da',2:'#fa8171',0:'#e8d49c'};
  const missionIcons=['✦','◆','♜','☀','⛰','✈','☾','⬡','⚔','♛','❄','⚓','⛰','✧','🏆','🌉','⚓','🏝️'];
  const saved={
    get(k,fallback){try{return JSON.parse(localStorage.getItem(k))??fallback}catch{return fallback}},
    set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}
  };
  let highest=saved.get('warcommanders_unlock',1);
  const clamp=(v,l,h)=>Math.max(l,Math.min(h,v));
  const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  const flatTime=s=>{const v=Math.floor(s||0);return String(Math.floor(v/60)).padStart(2,'0')+':'+String(v%60).padStart(2,'0')};
  const escapeHTML=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function toast(text){const el=$('toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2800)}
  function beep(f=600,d=.07){playSound(f<260?'invalid':f>800?'victory':'unit-select',Math.min(.55,Math.max(.18,d*2)))}
  function nav(name){
    if(name==='game'&&!playing){startMission(clamp(highest,1,E.MISSIONS.length));return}
    view=name;
    $$('.view').forEach(e=>e.classList.toggle('active',e.dataset.view===name));
    $$('.nav-button').forEach(e=>e.classList.toggle('active',e.dataset.nav===name));
    $('mobileNav').classList.remove('open');
    if(name==='home')renderMissions();
    if(name==='game'){setTimeout(()=>{resizeCanvas();render();updateWeatherAudio();},35)}else{weatherAudio.pause();rainAudio.pause()}
    if(name==='lobby')paintLobby(serverStats);
  }
  $$('.nav-button,.mobile-nav button,[data-nav]').forEach(el=>el.addEventListener('click',()=>nav(el.dataset.nav)));
  $('menuBtn').onclick=()=>$('mobileNav').classList.toggle('open');
  $('soundBtn').onclick=()=>{audioOn=!audioOn;updateAudioButtons();updateWeatherAudio();toast(audioOn?'المؤثرات الصوتية مفعلة':'المؤثرات الصوتية مكتومة');playSound('ui-click')};
  $('musicBtn').onclick=()=>{musicOn=!musicOn;updateAudioButtons();if(musicOn){ambient.play().catch(()=>{musicOn=false;updateAudioButtons()})}else ambient.pause();toast(musicOn?'موسيقى الخلفية قيد التشغيل':'تم إيقاف موسيقى الخلفية')};
  updateAudioButtons();
  const terrainColors={rock:'#868b86',ridge:'#7b8178',water:'#277994',ruins:'#828789',forest:'#296f50',road:'#a49b82',dunes:'#bc9e6b',ice:'#a3e6e8',mud:'#75644c',bridge:'#cda273'};
  function previewMap(i){const m=E.MAPS[i],palette={desert:'#947e56',dust:'#777568',forest:'#365f4c',night:'#34495a',snow:'#a7bfc9',coast:'#538b91',canyon:'#905e46'};
    const f=m.features.map(v=>{const col=terrainColors[v.kind]||'#789';return v.shape==='rect'?`<rect x="${v.x/5}" y="${v.y/5}" width="${v.w/5}" height="${v.h/5}" transform="translate(${-v.w/10} ${-v.h/10})" fill="${col}" rx="3" opacity=".95"/>`:`<circle cx="${v.x/5}" cy="${v.y/5}" r="${v.r/5}" fill="${col}" opacity=".92"/>`;}).join('');
    const pts=m.points.map((a,n)=>`<circle cx="${a[0]/5}" cy="${a[1]/5}" r="4.5" fill="#e6ca79" stroke="#fff7d6" stroke-width="1.1"/>`).join('');
    return `<div class="mission-thumb"><svg viewBox="0 0 240 144" role="img" aria-label="مخطط تضاريس ${escapeHTML(m.label)}"><rect width="240" height="144" fill="${palette[E.MISSIONS[i].theme]}"/>${f}<circle cx="24" cy="72" r="8" fill="#53d8df"/><circle cx="216" cy="72" r="8" fill="#f58d7d"/>${pts}</svg><span>${escapeHTML(m.icon)} ${escapeHTML(m.label)}</span></div>`;
  }
  function renderMissions(){
    $('progressBadge').textContent=`وصلت إلى المهمة ${highest} من ${E.MISSIONS.length}`;
    $('homeMissions').innerHTML=E.MISSIONS.map((m,i)=>`<button class="mission-card ${i+1>highest?'locked':''}" ${i+1>highest?'disabled':''} data-stage="${i+1}"><span class="index">${i+1>highest?'🔒':missionIcons[i]}</span><span class="difficulty">${'★'.repeat(Math.min(5,Math.ceil((i+1)/2)))}</span>${previewMap(i)}<h3>${escapeHTML(m.title)}</h3><p>${escapeHTML(m.region)}</p></button>`).join('');
    $('missionSideList').innerHTML=E.MISSIONS.map((m,i)=>`<button class="side-mission ${state.stage===i+1?'active':''}" ${i+1>highest?'disabled':''} data-stage="${i+1}"><span>${i+1>highest?'🔒':String(i+1).padStart(2,'0')}</span>${escapeHTML(m.title)}</button>`).join('');
    $$('[data-stage]').forEach(btn=>btn.addEventListener('click',()=>startMission(Number(btn.dataset.stage))));
  }
  function startMission(stage,tryMap=false,customMap=null){
    if(stage>highest&&!tryMap){toast('أكمل المراحل السابقة أولًا');return}
    mode='solo';showcaseMode=!!tryMap||!!customMap;activeCustomMap=customMap?JSON.parse(JSON.stringify(customMap)):null;myTeam=1;session=null;rememberRoom();state=E.createState({stage,map:activeCustomMap});
    playing=true;paused=false;pendingBuild=null;selected=[];selectedBuildingId=null;resultHandled=false;latestLog=0;seenFx.clear();
    cam={cx:innerWidth<750?300:600,cy:360,zoom:innerWidth<750?1.8:1};
    $('resultOverlay').hidden=true;$('pauseBtn').textContent='⏸ إيقاف';$('pauseBtn').disabled=false;
    $('missionTitle').textContent=customMap?state.mapLabel:E.MISSIONS[stage-1].title;
    $('missionSubtitle').textContent=E.MISSIONS[stage-1].caption+' · '+E.MAPS[stage-1].detail;
    $('gameModePill').textContent=customMap?'خريطة مخصصة · فردي':showcaseMode?'وضع استكشاف الخرائط':'الحملة الفردية';
    $('mapIndicator').textContent=(customMap?'🛠️':E.MAPS[stage-1].icon)+' '+state.mapLabel+' · ذكاء اصطناعي';
    $('terrainLegend').textContent='🌲 الغابة: غطاء وبطء · 🪨 الصخور والماء: عوائق · 🛣️ الطريق: حركة أسرع';
    renderMissions();nav('game');toast('انطلقت المهمة! حدد قواتك ووجّهها نحو نقاط السيطرة.');
  }
  $('startBtn').onclick=()=>startMission(highest);
  $('restartBtn').onclick=()=>{if(mode==='online'){toast('لا يمكن إعادة المباراة الجماعية من جهة واحدة');return}startMission(state.stage,showcaseMode,activeCustomMap)};
  $('resultRetryBtn').onclick=()=>startMission(state.stage,showcaseMode);
  $('pauseBtn').onclick=()=>{if(mode!=='solo')return;paused=!paused;updateWeatherAudio();$('pauseBtn').textContent=paused?'▶ متابعة':'⏸ إيقاف';playSound('ui-click');toast(paused?'تم إيقاف المعركة':'استؤنفت المعركة')};
  $('nextBtn').onclick=()=>startMission(state.stage<E.MISSIONS.length?Math.min(highest,state.stage+1):1);
  $('deselectBtn').onclick=()=>{selected=[];selectedBuildingId=null;pendingBuild=null;setSelectionText()};
  function setSelectionText(){
    if(pendingBuild){$('selectionText').textContent='اختر موقع بناء '+E.BUILDING[pendingBuild].label+' بالقرب من قاعدتك';$('mapHint').textContent='المس موقعًا مناسبًا لوضع المبنى';}
    else if(selectedBuildingId){const b=state.entities.find(e=>e.id===selectedBuildingId&&e.team===myTeam&&e.category==='building');if(b){const c=E.buildingCost(b);$('selectionText').textContent=`${E.BUILDING[b.kind].label} · المستوى ${b.level||1}/3 · ${Math.round(b.hp/b.maxHp*100)}٪ سلامة${c?' · الترقية: ⬡ '+c.credits+' / ϟ '+c.energy:' · الحد الأقصى'}`;}else selectedBuildingId=null;}
    else if(selected.length){const names=[...new Set(selected.map(id=>state.entities.find(e=>e.id===id)?.kind).filter(Boolean))].map(k=>E.UNIT[k]?.label||E.BUILDING[k]?.label||k);$('selectionText').textContent=`تم تحديد ${selected.length} وحدة: ${names.join('، ')} — المس موقع التحرك أو هدف الهجوم`;$('mapHint').textContent='المس الأرض للتحرك، أو عدواً للهجوم';}
    else {$('selectionText').textContent='حدد وحداتك على الخريطة لإصدار الأوامر';$('mapHint').textContent='حدد وحدة ثم المس وجهتها — سحب المربع لتحديد مجموعة';}
    $$('[data-build]').forEach(b=>b.classList.toggle('active',b.dataset.build===pendingBuild));
    const upgradeBtn=$('upgradeBuildingBtn');
    if(upgradeBtn){const b=state.entities.find(e=>e.id===selectedBuildingId&&e.team===myTeam&&e.category==='building');const c=b&&E.buildingCost(b);upgradeBtn.disabled=!c;upgradeBtn.textContent=b?c?`⬆ ترقية ${E.BUILDING[b.kind].label} (⬡ ${c.credits} · ϟ ${c.energy})`:'✓ المبنى في المستوى 3':'⬆ حدد مبنى لترقيته';}
    updateTechButtons();
  }
  function dispatch(action){
    if(mode==='online'){
      if(!session){toast('اتصال الغرفة غير متاح');return}
      api('/api/room/action',{token:session.token,action}).then(r=>{if(!r.ok){toast(r.error||'تعذر تنفيذ الأمر');beep(180,.12)}else beep(620,.06)}).catch(e=>toast('تعذر الاتصال بالخادم'));
    } else {
      if(paused){toast('تابع المعركة قبل إصدار الأوامر');return}
      const r=E.act(state,1,action);
      if(!r.ok){toast(r.error);playSound('invalid',.45)}else playSound(action.kind==='helicopter'?'helicopter':action.kind==='jet'?'jet':action.type==='train'?'train':action.type==='build'?'build':'unit-select',.5);
    }
  }
  function updateTechButtons(){for(const b of $$('[data-tech]')){const k=b.dataset.tech,level=state.players[myTeam]?.tech?.[k]||0,c=E.techCost(k,level);b.disabled=!playing||!c;b.querySelector('small').textContent=c?`المستوى ${level}/3 · ⬡ ${c.credits} · ϟ ${c.energy}`:'تم تطويره للمستوى 3';}}
  $('upgradeBuildingBtn').onclick=()=>{if(!selectedBuildingId){toast('اختر أحد مبانيك من ساحة المعركة');return}dispatch({type:'upgrade',scope:'building',id:selectedBuildingId});setTimeout(setSelectionText,100)};
  $$('[data-tech]').forEach(b=>b.onclick=()=>{dispatch({type:'upgrade',scope:'tech',kind:b.dataset.tech});setTimeout(updateTechButtons,100)});
  $$('[data-train]').forEach(b=>b.onclick=()=>{if(!playing){toast('ابدأ المهمة أولًا');return}dispatch({type:'train',kind:b.dataset.train})});
  $$('[data-build]').forEach(b=>b.onclick=()=>{if(!playing)return;pendingBuild=pendingBuild===b.dataset.build?null:b.dataset.build;selected=[];selectedBuildingId=null;setSelectionText();beep()});
  function resizeCanvas(){const rect=cvs.getBoundingClientRect();const dpr=Math.min(2,window.devicePixelRatio||1);if(rect.width<1)return;cvs.width=Math.round(rect.width*dpr);cvs.height=Math.round(rect.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);if(renderer3d?.ready)renderer3d.resize(rect.width,rect.height,highQuality?dpr:Math.min(dpr,window.matchMedia("(pointer:coarse)").matches?1.1:1.5));}
  window.addEventListener('resize',()=>{if(view==='game')resizeCanvas()});
  function transform(){
    const w=cvs.clientWidth||650,h=cvs.clientHeight||390;
    const base=Math.min(w/E.WIDTH,h/E.HEIGHT);
    const scale=base*cam.zoom;
    const halfW=w/scale/2,halfH=h/scale/2;
    cam.cx=clamp(cam.cx,Math.min(E.WIDTH/2,halfW),Math.max(E.WIDTH/2,E.WIDTH-halfW));
    cam.cy=clamp(cam.cy,Math.min(E.HEIGHT/2,halfH),Math.max(E.HEIGHT/2,E.HEIGHT-halfH));
    return {w,h,scale,left:cam.cx-halfW,top:cam.cy-halfH};
  }
  function toWorld(clientX,clientY){if(use3D&&renderer3d?.ready)return renderer3d.pick(clientX,clientY,cvs.getBoundingClientRect(),cam);const r=cvs.getBoundingClientRect(),t=transform();return {x:(clientX-r.left)/t.scale+t.left,y:(clientY-r.top)/t.scale+t.top};}
  function toCanvas(p,t){return {x:(p.x-t.left)*t.scale,y:(p.y-t.top)*t.scale};}
  function roundedRect(x,y,w,h,r=9){ctx.beginPath();ctx.roundRect(x,y,w,h,r)}
  function drawTacticalMap2D(g,features){for(const f of features){g.save();g.globalAlpha=.94;const col=terrainColors[f.kind]||'#6a7d7c';
      if(f.shape==='circle'){g.beginPath();g.ellipse(f.x,f.y,f.r,f.r*.83,.1,0,Math.PI*2);g.fillStyle=col;g.fill();}
      else{g.fillStyle=col;g.beginPath();g.roundRect(f.x-f.w/2,f.y-f.h/2,f.w,f.h,11);g.fill();}
      if(f.kind==='water'||f.kind==='ice'){g.strokeStyle=f.kind==='water'?'#b8e6e777':'#e4ffff8b';g.lineWidth=2;for(let i=-2;i<=2;i++){const x=f.x+(i*18);g.beginPath();g.moveTo(x,f.y-15);g.quadraticCurveTo(x+10,f.y,x,f.y+14);g.stroke();}}
      if(f.kind==='ridge'||f.kind==='rock'){g.strokeStyle='#e9d9ba83';g.lineWidth=2;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(f.x+i*20-30,f.y+22);g.lineTo(f.x+i*20,f.y-12);g.lineTo(f.x+i*20+26,f.y+16);g.stroke();}}
      if(f.kind==='forest'){for(let i=0;i<13;i++){let a=i*2.399, r=f.r*.65*Math.sqrt((i+1)/14),x=f.x+Math.cos(a)*r,y=f.y+Math.sin(a)*r;g.fillStyle=i%3?'#164f38':'#3c9261';g.beginPath();g.arc(x,y,7+i%3*2,0,Math.PI*2);g.fill();}}
      if(f.kind==='ruins'){g.fillStyle='#35464c';for(let j=0;j<5;j++)g.fillRect(f.x-f.w*.34+j*f.w*.12,f.y-f.h*.27+(j%2)*14,11,22)}
      if(f.kind==='bridge'){g.fillStyle='#ead1a4';for(let yy=f.y-f.h/2+9;yy<f.y+f.h/2;yy+=21)g.fillRect(f.x-f.w/2+5,yy,f.w-10,4)}
      if(f.kind==='road'){g.setLineDash([15,15]);g.strokeStyle='#e9d49b8c';g.lineWidth=2;g.beginPath();g.moveTo(f.x-f.w*.46,f.y);g.lineTo(f.x+f.w*.46,f.y);g.stroke();g.setLineDash([]);}
      g.restore();
    }}
  function worldBackground(){
    const themes={desert:['#273941','#475c54','#756d50'],dust:['#34424b','#595e53','#8d785f'],forest:['#1e3c3d','#35534a','#536958'],night:['#142939','#253747','#475560'],snow:['#576e7b','#b0c0c8','#d8e2e5'],coast:['#315965','#5e8884','#a9a07e'],canyon:['#473c39','#855f4e','#a98967']};
    const p=themes[state.theme]||themes.desert;const grd=ctx.createLinearGradient(0,0,1200,720);grd.addColorStop(0,p[0]);grd.addColorStop(.5,p[1]);grd.addColorStop(1,p[2]);ctx.fillStyle=grd;ctx.fillRect(0,0,1200,720);
    const terrain=terrainImgs[state.theme]||terrainImgs.desert;
    if(terrain.complete&&terrain.naturalWidth){ctx.save();ctx.globalAlpha=.67;ctx.drawImage(terrain,0,0,1200,720);ctx.restore();}
    ctx.fillStyle='#bdc8a607';for(let x=0;x<1200;x+=25)for(let y=0;y<720;y+=28){let k=Math.sin(x*2.19+y*.86+state.stage*2.3);if(k>.24){ctx.beginPath();ctx.arc(x+(k*7),y+(k*8),1.3+(k*3),0,Math.PI*2);ctx.fill()}}
    ctx.strokeStyle='#e9e2c80d';ctx.lineWidth=1;ctx.beginPath();for(let x=0;x<=1200;x+=60){ctx.moveTo(x,0);ctx.lineTo(x,720)}for(let y=0;y<=720;y+=60){ctx.moveTo(0,y);ctx.lineTo(1200,y)}ctx.stroke();
    drawTacticalMap2D(ctx,state.features||[]);
    for(let i=0;i<55;i++){const x=(i*177+81)%1200,y=(i*131+77)%720;const r=4+(i*7)%17;ctx.fillStyle=i%3===0?'#0e292b34':'#b2a37d22';ctx.beginPath();ctx.ellipse(x,y,r*1.4,r*.52,Math.sin(i)*2,0,Math.PI*2);ctx.fill()}
    for(const [bx,team] of [[120,1],[1080,2]]){const radius=260;let glow=ctx.createRadialGradient(bx,350,20,bx,350,radius);glow.addColorStop(0,team===1?'#4dc9dc20':'#ef797121');glow.addColorStop(1,'#00000000');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(bx,355,radius,0,Math.PI*2);ctx.fill()}
    ctx.strokeStyle='#a9dce623';ctx.lineWidth=4;ctx.strokeRect(4,4,1192,712);
  }
  function drawPoint(pt){const c=colors[pt.owner],pulse=.5+Math.sin(state.time*3+pt.id)*.5;ctx.save();ctx.translate(pt.x,pt.y);ctx.strokeStyle=pt.owner?c:'#d9dbc1';ctx.lineWidth=2;ctx.setLineDash([9,7]);ctx.beginPath();ctx.arc(0,0,64,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);ctx.strokeStyle=c;ctx.lineWidth=5;ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(0,0,36+3*pulse,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;ctx.fillStyle='#0d2333b9';ctx.beginPath();ctx.arc(0,0,29,0,Math.PI*2);ctx.fill();ctx.fillStyle=c;ctx.font='bold 16px Tahoma';ctx.textAlign='center';ctx.fillText(String(pt.id),0,6);ctx.font='bold 12px Tahoma';ctx.fillText(pt.label,0,-47);if(pt.progress<100&&pt.progress>0){ctx.strokeStyle=colors[pt.capturedBy];ctx.lineWidth=7;ctx.beginPath();ctx.arc(0,0,44,-Math.PI/2,-Math.PI/2+Math.PI*2*pt.progress/100);ctx.stroke()}ctx.restore()}
  function drawBuilding(e){const col=colors[e.team],sz=e.size;ctx.save();ctx.translate(e.x,e.y);
    ctx.fillStyle='#06121baa';ctx.beginPath();ctx.ellipse(7,12,sz*1.36,sz*.85,0,0,Math.PI*2);ctx.fill();
    const sprite=artSprites[e.kind];if(sprite?.complete&&sprite.naturalWidth){
      ctx.drawImage(sprite,-sz*1.35,-sz*1.35,sz*2.7,sz*2.7);
      ctx.strokeStyle=col;ctx.lineWidth=2.4;ctx.strokeRect(-sz*.94,-sz*.88,sz*1.88,sz*1.76);
      ctx.restore();drawHp(e);return;
    }
    ctx.fillStyle='#0e242d';ctx.strokeStyle='#839b9988';ctx.lineWidth=3;roundedRect(-sz,-sz*.79,sz*2,sz*1.58,7);ctx.fill();ctx.stroke();
    ctx.fillStyle=e.team===1?'#315c66':'#795046';roundedRect(-sz*.86,-sz*.66,sz*1.72,sz*1.32,5);ctx.fill();
    ctx.fillStyle='#203342';ctx.strokeStyle=col;ctx.lineWidth=2;
    if(e.kind==='hq'){roundedRect(-sz*.55,-sz*.53,sz*1.1,sz*1.06,5);ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.fillRect(-sz*.2,-sz*.2,sz*.4,sz*.4);for(let i=-1;i<=1;i++){ctx.fillStyle='#132d36';ctx.fillRect(i*18-6,-sz*.68,12,7)} }
    else if(e.kind==='barracks'){for(let i=-1;i<=1;i++){ctx.fillStyle='#203744';roundedRect(i*sz*.51-8,-sz*.6,18,sz*1.2,3);ctx.fill();ctx.stroke()}}
    else if(e.kind==='factory'){roundedRect(-sz*.58,-sz*.5,sz*1.16,sz,5);ctx.fill();ctx.stroke();ctx.fillStyle=col;for(let i=-1;i<=1;i++)ctx.fillRect(i*18-5,2,10,15)}
    else if(e.kind==='refinery'){for(let i=-1;i<=1;i++){ctx.fillStyle='#263c42';ctx.beginPath();ctx.arc(i*sz*.5,0,sz*.35,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(i*sz*.5,0,4,0,Math.PI*2);ctx.fill()}}
    else if(e.kind==='tower'){ctx.fillStyle='#233b44';ctx.beginPath();ctx.arc(0,0,sz*.76,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.fillRect(-7,-sz*.96,14,sz*.96)}
    ctx.fillStyle='#eaf5f5';ctx.font='bold 11px Tahoma';ctx.textAlign='center';ctx.fillText(E.BUILDING[e.kind].label,0,-sz-13);ctx.restore();drawHp(e);
  }
  function drawUnit(e){const col=colors[e.team];ctx.save();ctx.translate(e.x,e.y);ctx.rotate(e.angle||0);ctx.fillStyle='#081e25bb';ctx.beginPath();ctx.ellipse(4,6,e.size*1.1,e.size*.75,0,0,Math.PI*2);ctx.fill();
    const sprite=artSprites[e.kind];if(sprite?.complete&&sprite.naturalWidth){
      ctx.drawImage(sprite,-e.size*1.38,-e.size*1.38,e.size*2.76,e.size*2.76);
      ctx.strokeStyle=col;ctx.globalAlpha=.8;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,e.size*.83,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;
      ctx.restore();drawHp(e);return;
    }
    if(e.kind==='infantry'){ctx.fillStyle=e.team===1?'#508a84':'#ac6e60';ctx.beginPath();ctx.arc(0,0,9,0,Math.PI*2);ctx.fill();ctx.strokeStyle=col;ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#28333b';ctx.fillRect(4,-2,15,4)}
    else if(e.kind==='scout'){ctx.fillStyle='#1f3339';ctx.fillRect(-e.size,-e.size*.55,e.size*2,e.size*1.1);ctx.strokeStyle=col;ctx.strokeRect(-e.size,-e.size*.55,e.size*2,e.size*1.1);ctx.fillStyle=col;ctx.fillRect(0,-4,e.size,8)}
    else if(e.kind==='tank'){ctx.fillStyle='#26323e';roundedRect(-20,-24,40,48,5);ctx.fill();ctx.fillStyle='#3e5758';roundedRect(-17,-20,34,40,4);ctx.fill();ctx.strokeStyle=col;ctx.lineWidth=2;ctx.stroke();ctx.fillStyle=col;ctx.fillRect(0,-3,31,6);ctx.fillStyle='#24353f';ctx.beginPath();ctx.arc(0,0,12,0,Math.PI*2);ctx.fill();ctx.stroke()}
    else if(e.kind==='artillery'){ctx.fillStyle='#293b43';roundedRect(-17,-20,34,40,4);ctx.fill();ctx.strokeStyle=col;ctx.lineWidth=3;ctx.stroke();ctx.fillStyle=col;ctx.fillRect(3,-5,40,10);ctx.fillRect(-10,-10,20,20)}
    ctx.restore();drawHp(e);
  }
  function drawHp(e){const width=e.size*1.8;ctx.fillStyle='#0e1b24cc';ctx.fillRect(e.x-width/2,e.y-e.size-15,width,4);ctx.fillStyle=e.team===1?'#6be4d5':'#f48979';ctx.fillRect(e.x-width/2,e.y-e.size-15,width*clamp(e.hp/e.maxHp,0,1),4)}
  function drawEffects(){for(const fx of state.effects){ctx.save();
    const age=fx.kind==='blast'?.65-fx.ttl:.2-fx.ttl;
    if(fx.kind==='blast'){
      const r=14+Math.max(0,age)*72;
      const light=ctx.createRadialGradient(fx.x,fx.y,1,fx.x,fx.y,r*1.8);
      light.addColorStop(0,'rgba(255,240,170,'+Math.min(.95,fx.ttl*1.5)+')');
      light.addColorStop(.2,'rgba(255,156,56,'+Math.min(.85,fx.ttl*1.4)+')');
      light.addColorStop(1,'rgba(255,100,10,0)');ctx.fillStyle=light;ctx.beginPath();ctx.arc(fx.x,fx.y,r*1.8,0,7);ctx.fill();
      ctx.strokeStyle='rgba(255,191,113,'+Math.min(1,fx.ttl*1.7)+')';ctx.lineWidth=5;ctx.beginPath();ctx.arc(fx.x,fx.y,r,0,7);ctx.stroke();
      for(let i=0;i<7;i++){const a=i*2.399+fx.id,rp=Math.max(0,age)*42+9;
        ctx.fillStyle='rgba(45,50,50,'+Math.min(.52,fx.ttl)+')';ctx.beginPath();ctx.arc(fx.x+Math.cos(a)*rp,fx.y+Math.sin(a)*rp,10+age*20,0,7);ctx.fill();
        ctx.fillStyle='rgba(255,206,95,'+Math.min(.8,fx.ttl*2)+')';ctx.beginPath();ctx.arc(fx.x+Math.cos(a)*(rp+15),fx.y+Math.sin(a)*(rp+15),2.2,0,7);ctx.fill();
      }
    }else{
      ctx.strokeStyle=fx.kind==='heavy'?'#ffd285':'#fff8d3';ctx.lineWidth=fx.kind==='heavy'?6:2.5;ctx.shadowColor='#ffb54b';ctx.shadowBlur=15;
      ctx.beginPath();ctx.moveTo(fx.x,fx.y);ctx.lineTo(fx.tx,fx.ty);ctx.stroke();
      ctx.fillStyle='#ffdc8a';ctx.beginPath();ctx.arc(fx.tx,fx.ty,fx.kind==='heavy'?8:4,0,7);ctx.fill();
    }
    ctx.restore();}}
  function drawScene(){const t=transform();ctx.clearRect(0,0,t.w,t.h);ctx.fillStyle='#0b212b';ctx.fillRect(0,0,t.w,t.h);ctx.save();ctx.scale(t.scale,t.scale);ctx.translate(-t.left,-t.top);worldBackground();state.points.forEach(drawPoint);state.entities.filter(e=>e.category==='building').forEach(drawBuilding);state.entities.filter(e=>e.category==='unit').forEach(drawUnit);drawEffects();
    for(const e of state.entities)if(selected.includes(e.id)){ctx.save();ctx.strokeStyle='#aafef0';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.beginPath();ctx.arc(e.x,e.y,e.size+13,0,Math.PI*2);ctx.stroke();ctx.restore();if(e.dest){ctx.strokeStyle='#9ae6d45a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.dest.x,e.dest.y);ctx.stroke()}}
    if(pendingBuild){const mouse=window._pointerWorld;if(mouse){const size=E.BUILDING[pendingBuild].size;ctx.strokeStyle='#c7efd3';ctx.lineWidth=2;ctx.setLineDash([8,6]);ctx.strokeRect(mouse.x-size,mouse.y-size,size*2,size*2);ctx.setLineDash([])}}
    ctx.restore();if(paused&&mode==='solo'){ctx.fillStyle='#04101ac7';ctx.fillRect(0,0,t.w,t.h);ctx.fillStyle='#d6ecea';ctx.font='bold 32px Tahoma';ctx.textAlign='center';ctx.fillText('المعركة متوقفة',t.w/2,t.h/2)}
  }
  function drawMini(){const w=mini.width,h=mini.height;mx.clearRect(0,0,w,h);mx.fillStyle='#284541';mx.fillRect(0,0,w,h);for(const f of state.features||[]){mx.fillStyle=terrainColors[f.kind]||'#566';if(f.shape==='circle'){mx.beginPath();mx.arc(f.x/E.WIDTH*w,f.y/E.HEIGHT*h,f.r/E.WIDTH*w,0,7);mx.fill()}else{mx.fillRect((f.x-f.w/2)/E.WIDTH*w,(f.y-f.h/2)/E.HEIGHT*h,f.w/E.WIDTH*w,f.h/E.HEIGHT*h)}}for(const p of state.points){mx.fillStyle=colors[p.owner];mx.beginPath();mx.arc(p.x/E.WIDTH*w,p.y/E.HEIGHT*h,5,0,7);mx.fill()}for(const e of state.entities){mx.fillStyle=colors[e.team];const sz=e.category==='building'?4:2;mx.fillRect(e.x/E.WIDTH*w-sz/2,e.y/E.HEIGHT*h-sz/2,sz,sz)}const t=transform();mx.strokeStyle='#ffffffbb';mx.lineWidth=1;mx.strokeRect(t.left/E.WIDTH*w,t.top/E.HEIGHT*h,t.w/t.scale/E.WIDTH*w,t.h/t.scale/E.HEIGHT*h)}
  function gameUI(){if(!state||view!=='game')return;const p=state.players[myTeam];if(!p)return;
    $('creditsText').textContent=Math.floor(p.credits).toLocaleString('ar-SA');$('energyText').textContent=Math.floor(p.energy).toLocaleString('ar-SA');$('timeText').textContent=flatTime(state.time);
    $('armyText').textContent=state.entities.filter(e=>e.team===myTeam&&e.category==='unit').length;
    $('pointStatus').innerHTML=state.points.map(pt=>`<span class="${pt.owner===myTeam?'mine':pt.owner?'theirs':''}">${escapeHTML(pt.label)} ${pt.owner===myTeam?'✓':pt.owner?'✕':'◌'}</span>`).join('');
    if(state.events.length&&state.events[state.events.length-1].id!==latestLog){latestLog=state.events[state.events.length-1].id;$('eventLog').innerHTML=state.events.slice(-7).reverse().map(e=>`<div><span style="color:${e.team===myTeam?'#76e0d5':'#a7b7c7'}">${flatTime(e.time)}</span> ${escapeHTML(e.text)}</div>`).join('')}
    selected=selected.filter(id=>state.entities.some(e=>e.id===id&&e.team===myTeam&&e.category==='unit'));
    if(state.finished&&!resultHandled){resultHandled=true;finishGame()}
    updateTechButtons();if(selectedBuildingId)setSelectionText();drawMini();
  }
  function finishGame(){const won=state.winner===myTeam;const kills=state.players[myTeam]?.killed||0;const starScore=won?(state.time<100?3:state.time<200?2:1):0;
    $('resultOverlay').hidden=false;$('resultIcon').textContent=won?'🏆':'🛡️';$('resultTitle').textContent=won?'انتصار مستحق!':'انتهت المعركة';
    $('resultInfo').textContent=won?`نجحت في المهمة خلال ${flatTime(state.time)} · دمرت ${kills} هدفًا.`:'خسرت هذه الجولة. أعد بناء قواتك وحاول السيطرة على النقاط مبكرًا.';
    $('resultStars').textContent=won?'★'.repeat(starScore)+'☆'.repeat(3-starScore):'☆☆☆';
    $('nextBtn').style.display=won&&mode==='solo'&&!showcaseMode?'':'none';$('resultRetryBtn').style.display=mode==='solo'?'':'none';
    if(won&&mode==='solo'&&!showcaseMode){highest=Math.max(highest,Math.min(E.MISSIONS.length,state.stage+1));saved.set('warcommanders_unlock',highest);renderMissions();playSound('victory',.75)}else playSound(won?'victory':'defeat',.75);
  }
  function render(){if(view!=='game'||!playing)return;if(cvs.width===0)resizeCanvas();if(use3D&&renderer3d?.ready)renderer3d.render(state,selected,pendingBuild,window._pointerWorld,cam,weatherList[weatherIndex].kind,performance.now(),paused);else drawScene()}
  function frame(now){const dt=Math.min(.15,(now-lastFrame)/1000);lastFrame=now;
    if(playing&&view==='game'){
      if(mode==='solo'&&!paused)E.tick(state,dt);
      inspectEffects();if(!use3D||now-last3DRender>34){render();last3DRender=now;}if(now-lastUI>180){gameUI();$('zoomValue').textContent=Math.round(cam.zoom*100)+'%';lastUI=now}
    }
    requestAnimationFrame(frame);
  }
  function canvasPointer(e){return toWorld(e.clientX,e.clientY)}
  function updateGraphicsMode(){use3D=!!renderer3d?.ready&&use3D;$('mapFrame').classList.toggle('three-on',use3D);$('toggle3D').textContent=use3D?'◈ 3D':'▣ 2D';$('toggle3D').classList.toggle('active',use3D);$('toggle3D').setAttribute('aria-pressed',String(use3D));}
  $('toggle3D').onclick=()=>{if(!renderer3d?.ready){toast('الجهاز لا يدعم WebGL — العرض ثنائي الأبعاد متاح');return}use3D=!use3D;updateGraphicsMode();toast(use3D?'تم تفعيل ساحة المعركة ثلاثية الأبعاد':'تم تفعيل العرض الكلاسيكي ثنائي الأبعاد');};
  $('weatherBtn').onclick=()=>{weatherIndex=(weatherIndex+1)%weatherList.length;const w=weatherList[weatherIndex];$('weatherBtn').textContent=w.icon+' '+w.name;updateWeatherAudio();toast('الطقس: '+w.name);};
  updateGraphicsMode();
  $('qualityBtn').onclick=()=>{highQuality=!highQuality;$('qualityBtn').setAttribute('aria-pressed',String(highQuality));$('qualityBtn').classList.toggle('active',highQuality);$('qualityBtn').textContent=highQuality?'✦ جودة عالية':'⚙ جودة اقتصادية';resizeCanvas();toast(highQuality?'تم تفعيل دقة الرسومات العالية':'تم تفعيل وضع توفير أداء الرسومات');};
  // Pointer-event touch controls: 1 finger select/order; 2 fingers pan/pinch.
  function gestureSnapshot(){const a=[...touchContacts.values()];if(a.length<2)return null;return {cx:(a[0].x+a[1].x)/2,cy:(a[0].y+a[1].y)/2,d:Math.max(4,Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)),zoom:cam.zoom};}
  cvs.addEventListener('pointerdown',e=>{
    if(!playing||state.finished||paused)return;
    e.preventDefault();
    try{cvs.setPointerCapture(e.pointerId)}catch{}
    if(e.pointerType==='touch'){touchContacts.set(e.pointerId,{x:e.clientX,y:e.clientY});if(touchContacts.size>=2){pinch=gestureSnapshot();drag=null;ignoreGestureUntilClear=true;$('selectionRect').style.display='none';return;}}
    if(ignoreGestureUntilClear)return;
    const p=canvasPointer(e);drag={pointerId:e.pointerId,start:p,last:p,px:e.clientX,py:e.clientY,startPx:e.clientX,startPy:e.clientY,pan:panMode||e.button===1,shift:e.shiftKey};window._pointerWorld=p;
  });
  cvs.addEventListener('pointermove',e=>{
    if(e.pointerType==='touch'&&touchContacts.has(e.pointerId))touchContacts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(touchContacts.size>=2){
      const next=gestureSnapshot();if(pinch&&next){
        const t=transform(),scale=use3D&&renderer3d?.ready?renderer3d.unitsPerPixel(cam):{x:1/t.scale,y:1/t.scale};
        cam.cx-=(next.cx-pinch.cx)*scale.x;cam.cy+=(next.cy-pinch.cy)*scale.y;
        cam.zoom=clamp(cam.zoom*next.d/pinch.d,1,3.4);
        cam.cx=clamp(cam.cx,0,E.WIDTH);cam.cy=clamp(cam.cy,0,E.HEIGHT);
      }pinch=next;return;
    }
    if(ignoreGestureUntilClear)return;
    window._pointerWorld=canvasPointer(e);if(!drag||drag.pointerId!==e.pointerId)return;
    const movement=Math.hypot(e.clientX-drag.startPx,e.clientY-drag.startPy);
    if(drag.pan){const t=transform();if(use3D&&renderer3d?.ready){const px=renderer3d.unitsPerPixel(cam);cam.cx-=(e.clientX-drag.px)*px.x;cam.cy+=(e.clientY-drag.py)*px.y;}else{cam.cx-=(e.clientX-drag.px)/t.scale;cam.cy-=(e.clientY-drag.py)/t.scale;}cam.cx=clamp(cam.cx,0,E.WIDTH);cam.cy=clamp(cam.cy,0,E.HEIGHT);drag.px=e.clientX;drag.py=e.clientY;return;}
    const rect=$('selectionRect');if(movement>12){const box=cvs.getBoundingClientRect();let x1=use3D&&renderer3d?.ready?drag.startPx-box.left:(drag.start.x-transform().left)*transform().scale,y1=use3D&&renderer3d?.ready?drag.startPy-box.top:(drag.start.y-transform().top)*transform().scale;let x2=e.clientX-box.left,y2=e.clientY-box.top;rect.style.display='block';rect.style.left=Math.min(x1,x2)+'px';rect.style.top=Math.min(y1,y2)+'px';rect.style.width=Math.abs(x1-x2)+'px';rect.style.height=Math.abs(y1-y2)+'px';}
  });
  cvs.addEventListener('pointerup',e=>{
    if(e.pointerType==='touch')touchContacts.delete(e.pointerId);
    if(ignoreGestureUntilClear){if(!touchContacts.size){ignoreGestureUntilClear=false;pinch=null;}$('selectionRect').style.display='none';drag=null;return;}
    if(!drag||drag.pointerId!==e.pointerId)return;
    const start=drag.start,end=canvasPointer(e),moved=Math.hypot(e.clientX-drag.startPx,e.clientY-drag.startPy);$('selectionRect').style.display='none';if(!drag.pan){
      if(moved>16){const minx=Math.min(start.x,end.x),miny=Math.min(start.y,end.y),maxx=Math.max(start.x,end.x),maxy=Math.max(start.y,end.y);selected=state.entities.filter(u=>u.category==='unit'&&u.team===myTeam&&u.x>=minx&&u.x<=maxx&&u.y>=miny&&u.y<=maxy).map(u=>u.id);pendingBuild=null;setSelectionText();if(selected.length)beep();}
      else handleMapClick(end,e.shiftKey,e.button,e);
    }drag=null;
  });
  cvs.addEventListener('pointercancel',e=>{if(e.pointerType==='touch')touchContacts.delete(e.pointerId);if(!touchContacts.size){ignoreGestureUntilClear=false;pinch=null;}drag=null;$('selectionRect').style.display='none'});
  cvs.addEventListener('contextmenu',e=>e.preventDefault());
  cvs.addEventListener('wheel',e=>{e.preventDefault();cam.zoom=clamp(cam.zoom+(e.deltaY<0?.18:-.18),1,3.4)},{passive:false});
  $('zoomIn').onclick=()=>cam.zoom=clamp(cam.zoom+.3,1,3.4);
  $('zoomOut').onclick=()=>cam.zoom=clamp(cam.zoom-.3,1,3.4);
  $('panToggle').onclick=()=>{panMode=!panMode;$('panToggle').classList.toggle('active',panMode);toast(panMode?'اسحب الخريطة للتحريك':'يمكنك تحديد القوات الآن')};
  mini.addEventListener('click',e=>{const r=mini.getBoundingClientRect();cam.cx=clamp((e.clientX-r.left)/r.width*E.WIDTH,0,E.WIDTH);cam.cy=clamp((e.clientY-r.top)/r.height*E.HEIGHT,0,E.HEIGHT)});
  function handleMapClick(p,shift,button,event){
    if(pendingBuild){dispatch({type:'build',kind:pendingBuild,x:p.x,y:p.y});pendingBuild=null;selectedBuildingId=null;setSelectionText();return}
    const clicked=state.entities.slice().reverse().find(e=>dist(e,p)<=e.size+12 || (use3D&&event&&renderer3d?.ready&&['helicopter','jet'].includes(e.kind)&&renderer3d.projectedDistance(e,event.clientX,event.clientY,cvs.getBoundingClientRect(),cam)<30));
    if(clicked?.team===myTeam){if(clicked.category==='unit'){selectedBuildingId=null;if(shift){selected=selected.includes(clicked.id)?selected.filter(id=>id!==clicked.id):[...selected,clicked.id]}else selected=[clicked.id];beep(690,.04)}else{selected=[];pendingBuild=null;selectedBuildingId=clicked.id;toast('المبنى جاهز للترقية — المستوى '+(clicked.level||1))}setSelectionText();return}
    if(selected.length){dispatch({type:'command',ids:selected,x:p.x,y:p.y,targetId:clicked&&clicked.team!==myTeam?clicked.id:null});return}
    if(clicked?.team!==myTeam&&clicked){toast('حدد قواتك أولًا ثم اختر الهدف');return}
    selected=[];selectedBuildingId=null;setSelectionText();
  }

  function rememberRoom(){try{if(session)sessionStorage.setItem('warcommanders_room_session',JSON.stringify(session));else sessionStorage.removeItem('warcommanders_room_session')}catch{}}
  function resumeRoom(){try{const s=JSON.parse(sessionStorage.getItem('warcommanders_room_session')||'null');if(s&&/^[0-9A-F]{6}$/.test(s.code)&&typeof s.token==='string'&&s.token.length<=128&&(s.team===1||s.team===2)){session=s;myTeam=s.team;$('createdCode').textContent=s.code;$('roomCreated').hidden=false;$('roomWaitText').textContent='جارٍ استعادة اتصال المباراة...';return true;}}catch{}return false;}
  // Android-only discovery: the native bridge sends opt-in UDP probes; its results are
  // verified against /api/health and shown here. Browser never probes LAN devices.
  window.WarNativeDiscovery={onResult(payload){
    let data;try{data=typeof payload==='string'?JSON.parse(payload):payload}catch{return}
    const container=$('discoveredServers');container.replaceChildren();
    $('discoverLANBtn').disabled=false;
    if(!data.ok){$('discoveryStatus').textContent=data.error||'تعذر اكتشاف خوادم اللعبة';return}
    $('discoveryStatus').textContent=data.hosts.length?'الخوادم المكتشفة: '+data.hosts.length:'لم يتم العثور على خادم. شغّل خادم Wi-Fi على الكمبيوتر.';
    data.hosts.forEach((host,i)=>{
      try{const origin=window.WarServerLink.normalize(host.url);const card=document.createElement('div');card.className='discovered-host';
        const info=document.createElement('div'),name=document.createElement('strong'),address=document.createElement('small'),btn=document.createElement('button');
        name.textContent='خادم قادة الحروب '+(i+1);address.textContent=origin;btn.className='btn secondary';btn.textContent='اتصال';
        btn.onclick=()=>{$('serverUrlInput').value=origin;$('connectLANBtn').click()};
        info.append(name,address);card.append(info,btn);container.append(card);
      }catch{}
    });
  }};
  $('discoverLANBtn').onclick=()=>{
    if(!window.WarAndroid?.discoverLAN){$('discoveryStatus').textContent='الاكتشاف التلقائي متاح من تطبيق Android المبني من مشروع v0.7 فقط؛ أدخل عنوان الخادم يدويًا هنا.';return}
    $('discoverLANBtn').disabled=true;$('discoveryStatus').textContent='جارٍ البحث عن خوادم اللعبة في Wi-Fi...';$('discoveredServers').replaceChildren();
    try{window.WarAndroid.discoverLAN()}catch(e){$('discoverLANBtn').disabled=false;$('discoveryStatus').textContent='تعذر تشغيل اكتشاف Wi-Fi';}
  };
  $('connectLANBtn').onclick=()=>{try{const url=window.WarServerLink.normalize($('serverUrlInput').value);saved.set('warcommanders_server_url',url);toast('جارٍ فتح خادم اللعبة...');window.location.assign(url)}catch(e){toast(e.message||'عنوان غير صالح')}};
  $('serverUrlInput').value=saved.get('warcommanders_server_url','');
  $('serverUrlInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('connectLANBtn').click()});
  $('retryServerBtn').onclick=()=>{ping();toast('جارٍ فحص الاتصال')};
  async function api(route,body){const resp=await fetch(route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const data=await resp.json();return data;}
  function clientId(){let id=saved.get('warcommanders_cid',null);if(!id){id='client-'+Math.random().toString(36).slice(2,13);saved.set('warcommanders_cid',id)}return id}
  function getNick(){const n=$('nickInput').value.trim().slice(0,22)||'قائد';saved.set('warcommanders_nick',n);return n}
  async function ping(){try{const r=await fetch('/api/health',{cache:'no-store'});if(!r.ok)throw Error('offline');const v=await r.json();if(!v.ok)throw Error('offline');serverOnline=true;$('netDot').classList.add('online');$('netText').textContent='الخادم متصل';$('serverLabel').textContent='جاهز للعب الجماعي';openStream();}catch{serverOnline=false;$('netDot').classList.remove('online');$('netText').textContent='الفردي متاح';$('serverLabel').textContent='الخادم غير مشغّل';$('onlineCount').textContent='—';$('battleCount').textContent='—';$('roomCount').textContent='—'}}
  function openStream(){if(!serverOnline)return;if(eventSource){eventSource.close();eventSource=null}
    let url='/api/stream?clientId='+encodeURIComponent(clientId())+'&name='+encodeURIComponent(getNick())+'&visible='+($('visiblePresence').checked?'1':'0');if(session)url+='&token='+encodeURIComponent(session.token);
    const es=new EventSource(url);eventSource=es;
    es.addEventListener('hello',e=>{try{const v=JSON.parse(e.data);if(session&&!v.authenticated){session=null;rememberRoom();$('roomCreated').hidden=true;toast('انتهت جلسة الغرفة، أنشئ غرفة جديدة');openStream();}}catch{}});
    es.addEventListener('stats',e=>{try{serverStats=JSON.parse(e.data);paintLobby(serverStats)}catch{}});
    es.addEventListener('room',e=>{try{const r=JSON.parse(e.data);handleRoom(r)}catch{}});
    es.addEventListener('roomClosed',e=>{try{const msg=JSON.parse(e.data);if(session&&msg.code===session.code){session=null;rememberRoom();$('roomCreated').hidden=true;playing=false;mode='solo';nav('lobby');toast('أُغلقت الغرفة من المضيف أو لانتهاء مهلة الاتصال');}}catch{}});
    es.onerror=()=>{$('netText').textContent='إعادة الاتصال بالخادم...'};
    es.onopen=()=>{$('netText').textContent='الخادم متصل'};
  }
  function paintLobby(stats){if(!stats)return;
    $('onlineCount').textContent=String(stats.online);$('battleCount').textContent=String(stats.inBattle);$('roomCount').textContent=String(stats.rooms);
    $('playerList').innerHTML=stats.players.length?stats.players.map(p=>`<div class="player-item"><span><i class="online-bubble"></i>${escapeHTML(p.name)}</span><span style="color:#9bb1bd">متصل</span></div>`).join(''):'<p class="muted-para">لا يوجد لاعبون نشطون.</p>';
    $('openRoomList').innerHTML=stats.openRooms.length?stats.openRooms.map(r=>`<div class="open-room-item"><span>${escapeHTML(r.players[0]?.name||'قائد')} · ${r.joined}/${r.capacity} · ${escapeHTML(r.code)} · ${escapeHTML(E.MAPS[(r.stage||1)-1]?.label||'ساحة العمليات')}</span><button data-room="${escapeHTML(r.code)}">انضمام</button></div>`).join(''):'<p class="muted-para">لا توجد غرف عامة بانتظار لاعب.</p>';
    $$('[data-room]').forEach(b=>b.onclick=()=>{$('roomCodeInput').value=b.dataset.room;joinRoom()});
  }
  $('createRoomBtn').onclick=async()=>{
    if(!serverOnline){toast('لتفعيل الغرف: شغّل node server.js أولًا');return}
    try{const r=await api('/api/room/create',{name:getNick(),public:$('publicRoom').checked,capacity:Number($('roomCapacity').value),stage:Number($('roomMap').value)});if(!r.ok)throw Error(r.error);session={code:r.code,token:r.token,team:r.team};rememberRoom();$('createdCode').textContent=r.code;$('roomCreated').hidden=false;$('roomWaitText').textContent='بانتظار اكتمال اللاعبين...';openStream();toast('الغرفة جاهزة، شارك الرمز مع صديقك')}catch(e){toast(e.message||'لم يتم إنشاء الغرفة')}
  };
  async function joinRoom(){if(!serverOnline){toast('الخادم غير متصل');return}
    const code=$('roomCodeInput').value.trim().toUpperCase();if(!/^[A-F0-9]{6}$/.test(code)){toast('أدخل رمز الغرفة المكون من 6 أحرف');return}
    try{const r=await api('/api/room/join',{name:getNick(),code});if(!r.ok)throw Error(r.error);session={code:r.code,token:r.token,team:r.team};rememberRoom();myTeam=r.team;mode='online';$('createdCode').textContent=r.code;$('roomCreated').hidden=false;$('roomWaitText').textContent=r.room.started?'جارٍ بدء المعركة...':`اللاعبون ${r.room.joined}/${r.room.capacity} — بانتظار اكتمال الغرفة`;openStream();toast(r.room.started?'انضممت إلى المعركة — انطلق!':'انضممت إلى الغرفة — بانتظار بقية اللاعبين')}catch(e){toast(e.message||'فشل الانضمام')}
  }
  $('leaveRoomBtn').onclick=async()=>{
    if(!session)return;
    try{const result=await api('/api/room/leave',{token:session.token});if(!result.ok)throw Error(result.error);session=null;rememberRoom();$('roomCreated').hidden=true;openStream();toast('تمت مغادرة غرفة الانتظار');}
    catch(e){toast(e.message||'تعذر مغادرة الغرفة')}
  };
  $('joinRoomBtn').onclick=joinRoom;
  $('roomCodeInput').addEventListener('keydown',e=>{if(e.key==='Enter')joinRoom()});
  $('copyInviteBtn').onclick=async()=>{if(!session)return;const link=location.protocol==='file:'?session.code:location.origin+location.pathname+'?room='+session.code;try{await navigator.clipboard.writeText(link);toast('تم نسخ الدعوة')}catch{toast('رمز الغرفة: '+session.code)}};
  function handleRoom(r){if(!session||r.code!==session.code)return;
    if(!r.started){$('roomWaitText').textContent='اللاعبون '+r.joined+' / '+r.capacity+' — بانتظار اكتمال الغرفة...';return}
    state=r.state;if(!state)return;
    if(mode!=='online'||!playing){mode='online';myTeam=session.team;playing=true;paused=false;selected=[];selectedBuildingId=null;pendingBuild=null;resultHandled=false;latestLog=0;seenFx.clear();cam={cx:myTeam===1?310:900,cy:360,zoom:innerWidth<750?1.8:1};
      $('missionTitle').textContent='مبارزة القادة · '+r.code+' · '+state.mapLabel;
      $('missionSubtitle').textContent=(r.capacity===4?'الفريق الأزرق ضد الفريق الأحمر — 2 ضد 2':`${r.players[0]?.name||'القائد الأول'} ضد ${r.players[1]?.name||'القائد الثاني'}`)+' — المعركة مباشرة';
      $('gameModePill').textContent=r.capacity===4?'مواجهة 2 ضد 2':'مواجهة 1 ضد 1';$('mapIndicator').textContent=(E.MAPS[state.stage-1]?.icon||'🗺️')+' '+state.mapLabel+' · مباشر';$('terrainLegend').textContent='🌲 الغابة: غطاء · 🪨 العوائق: التفاف · 🛣️ الطريق: أسرع';$('pauseBtn').disabled=true;$('resultOverlay').hidden=true;nav('game');toast('بدأت المباراة الجماعية!')}
  }
  const fromUrl=new URLSearchParams(location.search).get('room');if(fromUrl&&/^[a-f\d]{6}$/i.test(fromUrl)){$('roomCodeInput').value=fromUrl.toUpperCase();setTimeout(()=>nav('lobby'),0)}
  $('nickInput').value=saved.get('warcommanders_nick','قائد الصقور');
  $('visiblePresence').checked=saved.get('warcommanders_visible',false);
  $('visiblePresence').onchange=()=>{saved.set('warcommanders_visible',$('visiblePresence').checked);if(serverOnline)openStream()};
  $('nickInput').addEventListener('change',()=>{getNick();if(serverOnline)openStream()});
  $('mapExploreSelect').innerHTML=E.MAPS.map((m,i)=>`<option value="${i+1}">${m.icon} ${String(i+1).padStart(2,'0')} · ${escapeHTML(m.label)}</option>`).join('');
  $('mapExploreBtn').onclick=()=>startMission(Number($('mapExploreSelect').value)||1,true);
  window.addEventListener('war:custom-map',event=>{const map=event.detail;startMission(16,true,map);});
  $('roomMap').innerHTML=E.MAPS.map((m,i)=>`<option value="${i+1}">${m.icon} ${String(i+1).padStart(2,'0')} · ${escapeHTML(m.label)}</option>`).join('');
  resumeRoom();renderMissions();setSelectionText();ping();requestAnimationFrame(frame);
  setInterval(()=>{if(!serverOnline&&view==='lobby')ping()},15000);
  if('serviceWorker' in navigator && (location.protocol==='https:' || ['localhost','127.0.0.1'].includes(location.hostname))){navigator.serviceWorker.register('/sw.js').catch(()=>{});}
})();
