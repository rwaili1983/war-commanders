(function(){'use strict';
const E=window.WarEngine,T=window.WarMapTools;const $=id=>document.getElementById(id);if(!E||!T||!$('editorCanvas'))return;
const cv=$('editorCanvas'),g=cv.getContext('2d');let model=T.preset(E.MAPS[15]||E.MAPS[0],'coast'),undo=[],redo=[],tool='forest';
const palette={desert:'#84714e',coast:'#456f78',forest:'#3b644b',snow:'#a7bdc9',night:'#314457',canyon:'#885f43',dust:'#8c7e62'};
const colors={water:'#247c9a',bridge:'#d8aa69',road:'#c7b99b',rock:'#777f7b',ridge:'#59666b',forest:'#287453',ruins:'#a0a6a6',dunes:'#c8a16c',ice:'#94d5e5',mud:'#736753'};
function say(msg,bad=false){$('editorStatus').textContent=msg;$('editorStatus').dataset.bad=bad?'1':'0'}
function push(){undo.push(T.clone(model));if(undo.length>35)undo.shift();redo=[]}
function draw(){
 g.fillStyle=palette[model.theme]||palette.coast;g.fillRect(0,0,1200,720);
 g.lineWidth=1;g.strokeStyle='#ffffff20';for(let x=0;x<1200;x+=60){g.beginPath();g.moveTo(x,0);g.lineTo(x,720);g.stroke()}for(let y=0;y<720;y+=60){g.beginPath();g.moveTo(0,y);g.lineTo(1200,y);g.stroke()}
 for(const f of model.features){g.fillStyle=colors[f.kind]||'#767';g.strokeStyle=f.kind==='bridge'?'#f9deb8':'#172c3560';g.lineWidth=f.kind==='bridge'?4:2;if(f.shape==='circle'){g.beginPath();g.arc(f.x,f.y,f.r,0,Math.PI*2);g.fill();g.stroke()}else{g.fillRect(f.x-f.w/2,f.y-f.h/2,f.w,f.h);g.strokeRect(f.x-f.w/2,f.y-f.h/2,f.w,f.h)}
 if(f.kind==='bridge'){g.fillStyle='#534739';for(let y=f.y-f.h/2+6;y<f.y+f.h/2;y+=18)g.fillRect(f.x-f.w/2+8,y,f.w-16,2)}
 }
 for(let i=0;i<3;i++){const [x,y]=model.points[i];g.beginPath();g.arc(x,y,32,0,7);g.fillStyle='#ffcc5a60';g.fill();g.strokeStyle='#f8e5aa';g.lineWidth=4;g.stroke();g.fillStyle='#fff';g.font='bold 26px Tahoma';g.textAlign='center';g.fillText(String(i+1),x,y+10)}
 for(const [x,y,c,txt] of [[120,355,'#51d3df','A'],[1080,355,'#f47a70','B']]){g.fillStyle=c;g.beginPath();g.arc(x,y,39,0,7);g.fill();g.fillStyle='#182e37';g.font='bold 25px sans-serif';g.fillText(txt,x,y+9)}
 $('editorFeatureCount').textContent=String(model.features.length)+' / '+T.MAX_FEATURES;
}
function safeModel(){return T.normalize({...model,label:$('editorName').value,theme:$('editorTheme').value})}
function preview(){try{model=safeModel();say('الخريطة صالحة ويمكن تجربتها أو حفظها');draw();return true}catch(e){say(e.message,true);return false}}
function setModel(newModel){model=T.normalize(newModel);$('editorName').value=model.label;$('editorTheme').value=model.theme;draw();say('جاهز للتعديل — اختر تضريسًا واضغط على الخريطة')}
$('editorPreset').innerHTML=E.MAPS.map((m,i)=>`<option value="${i}">${i+1} · ${m.label}</option>`).join('');$('editorPreset').value='15';
$('editorPresetLoad').onclick=()=>{push();const i=Number($('editorPreset').value);setModel(T.preset(E.MAPS[i],E.MISSIONS[i].theme));};
const labels={water:'🌊 ماء',bridge:'🌉 جسر',forest:'🌲 غابة',rock:'🪨 صخور',ridge:'⛰️ جبال',ruins:'🏙️ مبانٍ',road:'🛣️ طريق',dunes:'🏜️ كثبان',mud:'🟤 طين',ice:'❄️ جليد'};
$('editorBrushes').innerHTML=T.KINDS.map(k=>`<button type="button" data-brush="${k}" class="editor-brush">${labels[k]}</button>`).join('')+'<button type="button" data-brush="erase" class="editor-brush">⌫ مسح</button>';
function updateBrush(){document.querySelectorAll('[data-brush]').forEach(b=>b.classList.toggle('active',b.dataset.brush===tool));}
$('editorBrushes').addEventListener('click',e=>{const b=e.target.closest('[data-brush]');if(b){tool=b.dataset.brush;updateBrush();say(tool==='erase'?'المس تضريسًا لحذفه':'المس الخريطة لإضافة: '+labels[tool]);}});updateBrush();
cv.addEventListener('pointerdown',e=>{
 const rect=cv.getBoundingClientRect(),x=Math.min(1199,Math.max(0,(e.clientX-rect.left)/rect.width*1200)),y=Math.min(719,Math.max(0,(e.clientY-rect.top)/rect.height*720));
 if(tool==='erase'){const i=model.features.findLastIndex(f=>f.shape==='circle'?Math.hypot(f.x-x,f.y-y)<=f.r:Math.abs(f.x-x)<f.w/2&&Math.abs(f.y-y)<f.h/2);if(i>=0){push();model.features.splice(i,1)}}
 else if(model.features.length>=T.MAX_FEATURES){say('وصلت إلى الحد الأقصى للتضاريس',true);return}else{push();model.features.push(T.feature(tool,x,y))}
 draw();say('تم تعديل الخريطة — احفظ أو جرّب بعد التحقق');
});
$('editorUndo').onclick=()=>{if(undo.length){redo.push(T.clone(model));setModel(undo.pop())}};
$('editorRedo').onclick=()=>{if(redo.length){undo.push(T.clone(model));setModel(redo.pop())}};
$('editorName').addEventListener('input',()=>{model.label=$('editorName').value;});
$('editorTheme').onchange=()=>{model.theme=$('editorTheme').value;draw()};
$('editorValidate').onclick=preview;
$('editorSave').onclick=()=>{if(!preview())return;try{localStorage.setItem('warcommanders_custom_map_v1',JSON.stringify(model));say('حُفظ التصميم على هذا الجهاز فقط')}catch{say('فشل الحفظ: مساحة التخزين غير متاحة',true)}};
$('editorPlay').onclick=()=>{if(!preview())return;window.dispatchEvent(new CustomEvent('war:custom-map',{detail:T.clone(model)}))};
$('editorExport').onclick=()=>{if(!preview())return;const blob=new Blob([JSON.stringify(model,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='war-commanders-custom-map.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);say('تم تصدير ملف JSON إلى جهازك')};
$('editorImport').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;try{if(file.size>16000)throw Error('ملف الخريطة كبير جدًا');const raw=JSON.parse(await file.text());push();setModel(T.normalize(raw));say('تم استيراد الخريطة وفحصها')}catch(err){say('تعذر الاستيراد: '+err.message,true)}finally{e.target.value=''}};
try{const prior=localStorage.getItem('warcommanders_custom_map_v1');if(prior)setModel(T.normalize(JSON.parse(prior)));else setModel(model)}catch{setModel(model)}
})();
