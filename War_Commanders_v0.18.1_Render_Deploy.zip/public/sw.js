/* Offline-first cache for static assets. API and multiplayer always require a running server. */
const VERSION='war-commanders-assets-v181-mobile-fix';
const CORE=['/','/index.html','/styles.css','/engine.js','/maptools.js','/map-editor.js','/app.js','/landscape-hud.js','/control-groups.js','/adaptive-performance.js','/server-link.js','/renderer3d.js','/favicon.svg','/manifest.webmanifest',
'/assets/images/cinematic-cover.webp','/assets/images/base-overview.webp','/assets/images/combat-scene.webp',
'/assets/images/world-map.webp','/assets/images/command-technology.webp','/assets/images/alliance.webp',
...['desert','dust','forest','night','snow','coast','canyon'].map(n=>`/assets/images/terrain-${n}.webp`),
...['infantry','scout','tank','heavyTank','mortar','drone','jammer','artillery','helicopter','jet','rocket','antiair','engineer','patrol','destroyer'].map(n=>`/assets/images/unit-${n}.svg`),
...['hq','factory','refinery','tower','barracks','airbase','radar','dock'].map(n=>`/assets/images/building-${n}.svg`),
...['ambient-loop','ui-click','unit-select','build','train','invalid','rifle','cannon','explosion','victory','defeat','helicopter','jet','wind','rain','tank-engine','mortar-fire','missile-flight','radar-ping','radio-order','drone-flight','field-ambience'].map(n=>`/assets/audio/${n}.wav`)];
self.addEventListener('install',ev=>ev.waitUntil(caches.open(VERSION).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',ev=>ev.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',ev=>{
 const r=ev.request;if(r.method!=='GET'||new URL(r.url).pathname.startsWith('/api/'))return;
 if(['/', '/index.html'].includes(new URL(r.url).pathname)){
   ev.respondWith(fetch(r).then(response=>{if(response.ok){const copy=response.clone();caches.open(VERSION).then(cache=>cache.put(r,copy));}return response;}).catch(()=>caches.match(r)));
   return;
 }
 ev.respondWith(caches.match(r).then(cached=>cached || fetch(r).then(response=>{if(response.ok&&new URL(r.url).origin===self.location.origin){const copy=response.clone();caches.open(VERSION).then(cache=>cache.put(r,copy));}return response;})));
});
