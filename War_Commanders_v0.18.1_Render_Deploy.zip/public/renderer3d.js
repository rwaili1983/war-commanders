/* WAR COMMANDERS — standalone dependency-free WebGL 3D renderer.
 * All meshes, terrain, vehicles, aircraft and VFX are generated locally.
 * The simulation remains authoritative in engine.js/server.js.
 */
(function(root){'use strict';
const R=Math.PI/180, WORLD_SCALE=45, ELEVATION=20, DEPTH=22;
const SIN_ELEV=ELEVATION/Math.hypot(ELEVATION,DEPTH);
const TAU=Math.PI*2;
let activeWorldWidth=1200,activeWorldHeight=720;
const teamColor={1:'#35cad8',2:'#ef7564',0:'#e9c986'};
function color(c){if(Array.isArray(c))return c;const h=c.replace('#','');return [parseInt(h.substring(0,2),16)/255,parseInt(h.substring(2,4),16)/255,parseInt(h.substring(4,6),16)/255];}
const shade=(col,v)=>color(col).map(x=>Math.min(1,Math.max(0,x*v)));
function norm(v){const n=Math.hypot(...v)||1;return v.map(x=>x/n)}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
function lookAt(e,c){const z=norm(e.map((v,i)=>v-c[i])),x=norm(cross([0,1,0],z)),y=cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,e),-dot(y,e),-dot(z,e),1]);}
function ortho(w,h){return new Float32Array([2/w,0,0,0,0,2/h,0,0,0,0,-1/80,0,0,0,-0.03,1]);}
function mul(a,b){const m=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)m[c*4+r]+=a[k*4+r]*b[c*4+k];return m;}
function rnd(seed){return ((Math.sin(seed*127.1+78.233)*43758.5453)%1+1)%1;}
class Mesh{
 constructor(){this.data=[]}
 tri(a,b,c,col){const v=cross(b.map((x,i)=>x-a[i]),c.map((x,i)=>x-a[i]));const n=norm(v),clr=color(col);for(const p of [a,b,c])this.data.push(...p,...n,...clr);}
 quad(a,b,c,d,col){this.tri(a,b,c,col);this.tri(a,c,d,col)}
 box(x,y,z,w,h,d,col,angle=0){const ca=Math.cos(angle),sa=Math.sin(angle),p=(xx,yy,zz)=>[x+xx*ca-zz*sa,y+yy,z+xx*sa+zz*ca];const x0=-w/2,x1=w/2,z0=-d/2,z1=d/2,y0=0,y1=h;
 const A=p(x0,y0,z0),B=p(x1,y0,z0),C=p(x1,y0,z1),D=p(x0,y0,z1),a=p(x0,y1,z0),b=p(x1,y1,z0),c=p(x1,y1,z1),d0=p(x0,y1,z1);
 this.quad(a,b,c,d0,col);this.quad(D,C,B,A,shade(col,.54));this.quad(A,B,b,a,shade(col,.72));this.quad(B,C,c,b,shade(col,.87));this.quad(C,D,d0,c,shade(col,.65));this.quad(D,A,a,d0,shade(col,.83));}
 cylinder(x,y,z,r,h,col,n=12){const top=y+h;for(let i=0;i<n;i++){const a=i*TAU/n,b=(i+1)*TAU/n;const q=[x+r*Math.cos(a),y,z+r*Math.sin(a)],p=[x+r*Math.cos(b),y,z+r*Math.sin(b)],Q=[q[0],top,q[2]],P=[p[0],top,p[2]];this.quad(q,p,P,Q,col);this.tri([x,top,z],Q,P,shade(col,1.16));}}
 cone(x,y,z,r,h,col,n=10){for(let i=0;i<n;i++){const a=i*TAU/n,b=(i+1)*TAU/n;this.tri([x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],[x,y+h,z],col);}}
 tube(a,b,r,col,steps=8){const d=norm(b.map((x,i)=>x-a[i]));let t=cross(d,[0,1,0]);if(Math.hypot(...t)<.001)t=cross(d,[0,0,1]);t=norm(t);const q=cross(d,t);for(let i=0;i<steps;i++){const f=i*TAU/steps,g=(i+1)*TAU/steps;const off=k=>t.map((v,j)=>r*(v*Math.cos(k)+q[j]*Math.sin(k)));const o0=off(f),o1=off(g);this.quad(a.map((v,j)=>v+o0[j]),a.map((v,j)=>v+o1[j]),b.map((v,j)=>v+o1[j]),b.map((v,j)=>v+o0[j]),col)}}
 sphere(x,y,z,r,col,lat=5,lon=8){for(let j=0;j<lat;j++){const t0=Math.PI*j/lat,t1=Math.PI*(j+1)/lat;for(let i=0;i<lon;i++){const a=i*TAU/lon,b=(i+1)*TAU/lon;const p=(t,h)=>[x+r*Math.sin(t)*Math.cos(h),y+r*Math.cos(t),z+r*Math.sin(t)*Math.sin(h)];this.quad(p(t0,a),p(t0,b),p(t1,b),p(t1,a),col)}}}
 disk(x,y,z,r,col,n=24){for(let i=0;i<n;i++){const a=i*TAU/n,b=(i+1)*TAU/n;this.tri([x,y,z],[x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],col)}}
 ring(x,y,z,r,width,col){const n=32;for(let i=0;i<n;i++){const a=i*TAU/n,b=(i+1)*TAU/n;this.quad([x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],[x+(r+width)*Math.cos(b),y,z+(r+width)*Math.sin(b)],[x+(r+width)*Math.cos(a),y,z+(r+width)*Math.sin(a)],col)}}
}
function pWorld(x,y){return [(x-activeWorldWidth/2)/WORLD_SCALE,(y-activeWorldHeight/2)/WORLD_SCALE]}
function pos(e){return pWorld(e.x,e.y)}
function drawTerrain(b,theme,features=[],mapW=1200,mapH=720){const palette={desert:['#77715b','#8d8367','#b0a080'],dust:['#6c6b60','#827c68','#a39778'],forest:['#355a45','#49734e','#6e875b'],night:['#304451','#394c59','#596870'],snow:['#91a5b4','#bacbd5','#e2e6e9'],coast:['#46737b','#749d96','#c0ba99'],canyon:['#795240','#9b6b53','#bb916a']}[theme]||['#77715b','#8d8367','#b0a080'];
 const tw=mapW/WORLD_SCALE,th=mapH/WORLD_SCALE;
 b.box(0,-.45,0,tw+1,.36,th+1,shade(palette[0],.6));const nX=Math.min(56,Math.ceil(tw*1.25)),nZ=Math.min(36,Math.ceil(th*1.25));
 for(let i=0;i<nX;i++)for(let k=0;k<nZ;k++){const x=-tw/2+(i+.5)*tw/nX,z=-th/2+(k+.5)*th/nZ,v=rnd(i*113+k*23),col=shade(palette[v<.22?0:v<.73?1:2],.9+rnd(i+k*99)*.17);b.box(x,-.07,z,tw/nX+.012,.09,th/nZ+.012,col)}
 for(let i=0;i<Math.min(135,Math.round(mapW/1200*100));i++){let x=rnd(i*42+3)*tw-tw/2,z=rnd(i*39+91)*th-th/2;const nearBase=Math.abs(x)>tw/2-3.5&&Math.abs(z)<5.0;if(nearBase||Math.abs(z-(4.4-x*.28))<1.5)continue;
 const v=rnd(i*31+19),r=.1+v*.20;
 if((theme==='forest'||theme==='coast') && i%4!==0){b.cylinder(x,.03,z,.05,.22,'#594d37',5);b.cone(x,.19,z,r*1.5,.5,'#2e6953',7);b.cone(x,.42,z,r*1.1,.37,'#477f5b',7)}
 else {b.sphere(x,.04,z,r,shade(theme==='night'?'#536875':'#797565',.75+v*.3),3,6)} }
 for(let i=0;i<features.length;i++)drawTacticalFeature(b,features[i],i+features.length*11);
 // distant ridge silhouettes frame the battleground without blocking interactions
 for(let i=0;i<12;i++){const x=-tw/2+(i+.5)*tw/12,bound=th/2+.5,z=i%2?bound:-bound;b.cone(x,-.11,z,1.1+rnd(i)*.9,.6+rnd(i+3)*.8,shade(palette[0],.75),7)}
}

// Terrain objects are part of the actual map: their collision geometry is shared with engine.js.
function drawTacticalFeature(b,f,seed){const [x,z]=pWorld(f.x,f.y),r=(f.r||Math.min(f.w,f.h)*.43)/WORLD_SCALE,w=(f.w||f.r*2)/WORLD_SCALE,h=(f.h||f.r*2)/WORLD_SCALE;
 if(f.kind==='water'){
   if(f.shape==='rect')b.box(x,.028,z,w,.025,h,'#236786');else b.disk(x,.035,z,r,'#236786');
   for(let j=0;j<8;j++){const px=x+(rnd(seed*11+j*17)-.5)*w,pz=z+(rnd(seed*37+j*13)-.5)*h;b.box(px,.057,pz,.36,.012,.025,'#6aaabe')}
 }else if(f.kind==='bridge'){
   b.box(x,.13,z,w,.23,h,'#a99b7e');for(const side of [-1,1]){b.box(x+side*(w/2-.10),.38,z,.11,.26,h,'#d5d1c4');for(let i=-1;i<=1;i++)b.box(x+side*(w/2-.19),.12,z+i*h*.34,.18,.35,.12,'#746957')}
 }else if(f.kind==='ridge'||f.kind==='rock'){
   const count=f.kind==='ridge'?Math.max(3,Math.floor(Math.max(w,h)*2.5)):5;
   for(let i=0;i<count;i++){
     const dx=f.kind==='ridge'?(w>h?((i+.5)/count-.5)*w:(rnd(seed+i*19)-.5)*w):Math.cos(i*TAU/count)*r*.37;
     const dz=f.kind==='ridge'?(h>=w?((i+.5)/count-.5)*h:(rnd(seed+i*23)-.5)*h):Math.sin(i*TAU/count)*r*.37;
     let size=f.kind==='rock'?r*.78:Math.min(w,h)*.6;
     b.cylinder(x+dx,.02,z+dz,size,.12,'#4b5151',7);
     b.cone(x+dx,.13,z+dz,size*.95,.56+rnd(i+seed)*.74,'#838a85',7);
     b.cone(x+dx+.08,.2,z+dz+.1,size*.48,.32,'#b2aaa0',6);
   }
 }else if(f.kind==='ruins'){
   b.box(x,.045,z,w,.08,h,'#545a59');
   for(let i=0;i<7;i++){const bx=x+(rnd(i*19+seed)-.5)*w*.78,bz=z+(rnd(i*43+seed)-.5)*h*.78;
     b.box(bx,.13,bz,.38,.25+rnd(i+seed)*.8,.42,'#7d857f');
     b.box(bx,.85,bz,.32,.045,.34,'#a5a9a0');
   }
 }else if(f.kind==='forest'){
   const n=Math.min(28,Math.max(9,Math.round(r*r*27)));
   b.disk(x,.025,z,r,'#345e4a');
   for(let i=0;i<n;i++){const a=rnd(i*37+seed)*TAU,d=Math.sqrt(rnd(i*13+seed))*r*.93,tx=x+Math.cos(a)*d,tz=z+Math.sin(a)*d,th=.3+rnd(i+seed*3)*.28;
     b.cylinder(tx,.035,tz,.047,th,'#66553e',5);
     b.cone(tx,.16+th*.48,tz,.20+th*.2,.46+th*.25,i%3===0?'#4c9366':'#27724e',7);
   }
 }else if(f.kind==='road'){
    b.box(x,.05,z,w,.033,h,'#66675a');
    for(let j=0;j<Math.max(3,Math.round(w/1.4));j++){const px=x-w/2+(j+.5)*w/Math.max(3,Math.round(w/1.4));b.box(px,.075,z,.32,.008,.027,'#bcb4a0')}
 }else if(f.kind==='dunes'){
   b.disk(x,.055,z,r,'#97805a');for(let i=0;i<8;i++){const a=i*TAU/8,d=r*(.25+.24*rnd(i+seed));b.cone(x+Math.cos(a)*d,.075,z+Math.sin(a)*d,r*.35,.17+rnd(i*7+seed)*.12,'#c1a477',10)}
 }else if(f.kind==='ice'){
   b.disk(x,.04,z,r,'#93d5da');for(let i=0;i<5;i++){const a=i*TAU/5;b.box(x+Math.sin(a)*r*.55,.065,z+Math.cos(a)*r*.55,r*.42,.02,.13,'#e0f3e9',a)}
 }else if(f.kind==='mud'||f.kind==='marsh'){
   b.disk(x,.048,z,r,f.kind==='marsh'?'#52694d':'#75664a');for(let i=0;i<10;i++){const a=rnd(i+seed)*TAU,d=r*rnd(i*15+seed);const xx=x+Math.cos(a)*d,zz=z+Math.sin(a)*d;
     b.disk(xx,.061,zz,r*.13,i%3===0?'#537f73':f.kind==='marsh'?'#74845b':'#514f44',9);
     if(f.kind==='marsh'&&i%2===0){b.tube([xx,.07,zz],[xx,.27,zz],.02,'#a3b477',5);b.cone(xx,.22,zz,.08,.20,'#8c9f64',5);}
   }
 }else if(f.kind==='trench'){
   b.box(x,.02,z,w,.025,h,'#514d40');
   for(const side of [-1,1]){b.box(x,.07,z+side*(h/2-.10),w,.21,.19,'#8b8067');
     for(let i=0;i<Math.max(2,Math.floor(w/.45));i++){const bx=x-w/2+(i+.5)*w/Math.max(2,Math.floor(w/.45));b.box(bx,.27,z+side*(h/2-.10),.18,.13,.25,i%2?'#967d60':'#726f52');}}
 }
}
function drawBuilding(b,e){const [x,z]=pos(e),s=e.size/36,col=teamColor[e.team];b.disk(x,.025,z,s*1.3,'#34423c');
 const metal=e.team===1?'#445b61':'#67504a';const roof=e.team===1?'#304f60':'#704e47';b.box(x,.035,z,s*1.85,.14,s*1.5,'#353d41');
 if(e.kind==='hq'){
  b.box(x,.16,z,s*1.62,.72,s*1.24,metal);b.box(x,.88,z,s*.99,.49,s*.9,roof);b.box(x,1.37,z,s*.45,.32,s*.45,'#d5c8a2');
  for(const side of [-1,1]){b.box(x+side*s*.69,.48,z,s*.12,.25,s*.46,col);b.box(x+side*s*.72,.95,z,s*.2,.17,s*.55,'#1e3947')}
  b.box(x,1.8,z,.04,.85,.04,'#c2c4bb');b.sphere(x,2.76,z,.13,col,4,8);
  for(let ix=-1;ix<=1;ix++)b.box(x+ix*.34,.45,z-s*.65,.18,.24,.06,'#6ecbde');
 }else if(e.kind==='barracks'){
  for(let i=-1;i<=1;i++){b.box(x+i*s*.46,.18,z,s*.42,.6,s*1.1,roof);b.box(x+i*s*.46,.77,z,s*.43,.13,s*1.1,'#bcc4b6');b.box(x+i*s*.46,.25,z-s*.58,.13,.25,.06,col)}
 }else if(e.kind==='factory'){
  b.box(x,.18,z,s*1.6,.67,s*1.13,metal);b.box(x,.85,z,s*1.75,.13,s*1.2,'#899690');
  for(let i=-1;i<=1;i++)b.box(x+i*s*.47,.27,z-s*.59,s*.28,.35,.08,'#162a36');
  b.cylinder(x+s*.44,.93,z+s*.17,.11,.72,'#afb5a7',8);
 }else if(e.kind==='refinery'){
  for(let i=-1;i<=1;i++){b.cylinder(x+i*s*.49,.2,z,s*.33,.83,'#667c7c',12);b.cylinder(x+i*s*.49,1.03,z,s*.35,.10,col,12)}
  b.tube([x-s*.6,.3,z+s*.35],[x+s*.6,.3,z+s*.35],.08,'#d3bb7b');
 }else if(e.kind==='tower'){
  b.cylinder(x,.2,z,s*.57,.83,'#65747a',10);b.cylinder(x,1.05,z,s*.74,.18,roof,10);b.box(x,1.23,z,s*.9,.25,s*.55,col);b.tube([x,1.40,z],[x+s*.72,1.5,z],.09,'#a2adad');
 }else if(e.kind==='radar'){
  b.cylinder(x,.20,z,s*.47,1.05,'#5b747c',10);b.tube([x,1.25,z],[x,2.0,z],.045,'#c2caca');
  b.sphere(x,2.02,z,.34,col,6,9);b.ring(x,1.95,z,.65,.055,'#85d6dc');
 }else if(e.kind==='dock'){
  b.box(x,.10,z,s*1.45,.24,s*1.15,'#6b6556');for(const side of [-1,1])b.box(x+side*s*.65,.11,z+s*.25,.15,.45,s*.85,'#b0a587');b.box(x,.41,z,s*.72,.36,s*.55,metal);b.tube([x,1,z],[x+s*.75,1.5,z],.04,'#e4c989');
 }else if(e.kind==='airbase'){
  b.box(x,.18,z,s*1.62,.22,s*1.48,'#42565d');b.box(x,.4,z+s*.45,s*1.62,.46,s*.45,metal);
  b.ring(x,.46,z-s*.15,s*.45,.08,'#e8d98b');
  b.box(x,.47,z-s*.15,s*.9,.05,.06,'#dfd19c');b.box(x,.47,z-s*.15,.06,.05,s*.9,'#dfd19c');
  b.cylinder(x+s*.54,.87,z+s*.52,.12,.48,col,9);
 }
 if((e.level||1)>1){b.box(x,.2,z-s*.9,s*.75,.07,.15,'#f3d67d');b.box(x,.22,z+s*.9,s*.75,.07,.15,'#f3d67d');}
 if((e.level||1)>2)b.ring(x,.19,z,s*1.3,.08,'#8debd9');
 b.box(x,.17,z+s*.83,s*.9,.035,.07,col);
}
function frameUnit(x,z,ang){const co=Math.cos(ang),si=Math.sin(ang);return (dx,yy,dz)=>[x+co*dx-si*dz,yy,z+si*dx+co*dz];}
function drawUnit(b,e,time,compact=false){const [x,z]=pos(e),s=e.size/22,a=e.angle||0,rot=frameUnit(x,z,a);const col=teamColor[e.team],dark=e.team===1?'#263f45':'#533d39',arm=e.team===1?'#657874':'#967c69';const aerial=!!['helicopter','jet','drone'].includes(e.kind);
 b.disk(x,.036,z,s*(aerial?.65:.8),'#2d3c36');
 if(e.kind==='infantry'||e.kind==='engineer'||e.kind==='mortar'){
  b.cylinder(x,.08,z,.17*s,.43*s,arm,7);b.sphere(x,.65*s+.08,z,.15*s,'#bcac8c',5,7);b.cylinder(x,.76*s,z,.15*s,.11*s,col,7);
  b.tube(rot(0,.4*s,0),rot(.56*s,.4*s,0),.055*s,e.kind==='engineer'?'#f9dc89':'#343f40');
  for(const zz of [-.16,.16])b.box(...rot(-.01,.03,zz*s),.11*s,.27*s,.12*s,'#273637',a);
  if(e.kind==='mortar'){b.tube(rot(.13*s,.3*s,0),rot(.52*s,.83*s,0),.11*s,'#707778');b.box(...rot(.10*s,.08*s,0),.4*s,.08*s,.36*s,'#293c40',a);}
 }else if(e.kind==='scout'||e.kind==='tank'||e.kind==='heavyTank'||e.kind==='jammer'||e.kind==='artillery'||e.kind==='rocket'||e.kind==='antiair'){
  let h=e.kind==='heavyTank'?.55:e.kind==='tank'?.44:.30, width=e.kind==='heavyTank'?1.02:e.kind==='tank'?.91:.74;
  for(const dz of [-.35,.35]){const p=rot(0,.12*s,dz*s);b.box(p[0],p[1],p[2],1.15*s,.24*s,.26*s,'#232e34',a);for(const j of (compact?[-2,2]:[-2,-1,0,1,2])){const wheel=rot(j*.22*s,.16*s,dz*s);b.cylinder(wheel[0],wheel[1],wheel[2],.08*s,.04*s,'#999d90',6)}}
  const k=rot(0,.25*s,0);b.box(k[0],k[1],k[2],1.28*s,h*s,width*s,arm,a);
  const turret=rot(-.09*s,(.25+h)*s,.0);b.cylinder(turret[0],turret[1],turret[2],.29*s,.17*s,dark,10);
  const bar=rot(.15*s,(.30+h)*s,0),tip=rot((e.kind==='artillery'?1.19:e.kind==='heavyTank'?1.08:.8)*s,(.30+h)*s,0);b.tube(bar,tip,(e.kind==='artillery'?.08:.05)*s,'#cad5c4');
  if(e.kind==='rocket'){for(const dz of [-.20,.20]){const st=rot(.25*s,(.35+h)*s,dz*s),end=rot(.92*s,(.35+h)*s,dz*s);b.tube(st,end,.09*s,'#d5ab7b');}}
  if(e.kind==='jammer'){const q=rot(-.28*s,(.65+h)*s,0);b.cylinder(q[0],q[1],q[2],.20*s,.10*s,'#63b0b4',10);b.tube(q,rot(-.28*s,(1.05+h)*s,0),.018*s,'#b9d9d3');}
  if(e.kind==='antiair'){for(const dz of [-.18,.18]){const st=rot(.12*s,(.35+h)*s,dz*s),end=rot(.67*s,(.65+h)*s,dz*s);b.tube(st,end,.046*s,'#a6d3d4');}}
  const mark=rot(-.48*s,(.26+h)*s,0);b.box(mark[0],mark[1],mark[2],.13*s,.055*s,.24*s,col,a);
  if(!compact){
    // Side skirts, armor seams, optics and colored front navigation lights.
    for(const side of [-1,1]){
      const skirt=rot(-.12*s,.32*s,side*.49*s);b.box(skirt[0],skirt[1],skirt[2],.92*s,.13*s,.075*s,dark,a);
      const headlight=rot(.58*s,.31*s,side*.34*s);b.box(headlight[0],headlight[1],headlight[2],.06*s,.10*s,.12*s,'#e4d99d',a);
    }
    const sensor=rot(-.31*s,(.50+h)*s,.17*s);b.box(sensor[0],sensor[1],sensor[2],.13*s,.13*s,.13*s,'#9de6e0',a);
    if(e.kind==='tank'||e.kind==='heavyTank'||e.kind==='rocket'){const antenna=rot(-.41*s,(.55+h)*s,-.22*s);b.tube(antenna,rot(-.41*s,(1.12+h)*s,-.22*s),.016*s,'#b1baba',5)}
  }
 }else if(e.kind==='patrol'||e.kind==='destroyer'){
  const length=(e.kind==='destroyer'?2.6:1.85)*s,width=(e.kind==='destroyer'?.86:.67)*s;
  b.box(...rot(0,.13*s,0),length,.24*s,width,dark,a);b.box(...rot(-.12*s,.34*s,0),length*.69,.26*s,width*.68,arm,a);
  b.box(...rot(-.18*s,.62*s,0),length*.33,.32*s,width*.45,col,a);
  b.tube(rot(.12*s,.63*s,0),rot(.8*s,.65*s,0),.05*s,'#d9d5b7');
  if(e.kind==='destroyer'){for(const dx of [-.68,.53]){const q=rot(dx*s,.58*s,0);b.cylinder(q[0],q[1],q[2],.15*s,.13*s,'#b9c5c0',8)}}
  if(!compact){
    b.tri(rot(length*.55,.25*s,0),rot(length*.34,.13*s,-width*.38),rot(length*.34,.13*s,width*.38),'#8b9b98');
    for(const side of [-1,1]){const light=rot(-length*.22,.55*s,side*width*.31);b.box(light[0],light[1],light[2],.07*s,.09*s,.09*s,side===1?'#74d9ae':'#ff8e86',a)}
    b.tube(rot(-length*.22,.73*s,0),rot(-length*.22,1.35*s,0),.023*s,'#d0d9d4',6);
  }
 }else if(e.kind==='drone'){
  const hh=2.15+Math.sin(time*.003+e.id)*.12; b.box(...rot(0,hh,0),.65*s,.12*s,.38*s,'#859b91',a);
  for(const dx of [-.27,.27])for(const dz of [-.31,.31]){const q=rot(dx*s,hh,dz*s);b.cylinder(q[0],q[1],q[2],.16*s,.035*s,'#2b4446',10);}
  b.sphere(...rot(.3*s,hh-.10,0),.09*s,'#60ddde',4,7);
 }else if(e.kind==='helicopter'){
  const hh=1.95+Math.sin(time*.003+e.id)*.1,body=rot(0,hh,0);b.sphere(body[0],body[1],body[2],s*.47,arm,5,10);
  b.tube(rot(-.4*s,hh,0),rot(-1.1*s,hh,0),.075*s,'#7e8a82');
  b.box(...rot(.23*s,hh-.035,0),.3*s,.17*s,.56*s,'#1d4f67',a);
  for(const dz of [-.36,.36])b.tube(rot(-.45*s,hh-.33,dz*s),rot(.55*s,hh-.34,dz*s),.04*s,'#d8d4b6');
  b.tube(rot(0,hh+.22,0),rot(0,hh+.42,0),.04,'#e4d6b6');
  const rotor= time*.012;for(const offset of (compact?[0]:[0,Math.PI/2])){const q0=rot(Math.cos(rotor+offset)*1.0*s,hh+.42,Math.sin(rotor+offset)*1.0*s),q1=rot(-Math.cos(rotor+offset)*1.0*s,hh+.42,-Math.sin(rotor+offset)*1.0*s);b.tube(q0,q1,.033*s,'#c8dbd2')}
  if(!compact){const rt=time*.018;const tail=rot(-1.12*s,hh+.02,.0);b.tube([tail[0],tail[1]+Math.sin(rt)*.25*s,tail[2]+Math.cos(rt)*.25*s],[tail[0],tail[1]-Math.sin(rt)*.25*s,tail[2]-Math.cos(rt)*.25*s],.022*s,'#e0e5d5',5);}
 }else if(e.kind==='jet'){
  const hh=2.5+Math.sin(time*.003+e.id)*.12;
  b.tube(rot(-.88*s,hh,0),rot(.93*s,hh,0),.17*s,arm,9);
  b.tri(rot(.25*s,hh,.09*s),rot(-.55*s,hh,.95*s),rot(-.5*s,hh,-.93*s),col);
  b.tri(rot(-.65*s,hh,.09*s),rot(-1.02*s,hh,.47*s),rot(-1*s,hh,-.45*s),dark);
  b.tri(rot(-.82*s,hh,0),rot(-1*s,hh+.43*s,0),rot(-.60*s,hh,0),col);
  b.box(...rot(.25*s,hh+.13,0),.27*s,.09*s,.23*s,'#1e5065',a);
 }
}
function drawVfx(b,state,now){for(const fx of state.effects){const [x,z]=pWorld(fx.x,fx.y);if(fx.kind==='blast'){
 const t=(.65-fx.ttl)/.65,s=.17+t*.85;b.sphere(x,.12+t*.4,z,s, t<.5?'#ffc267':'#c45d34',4,8);b.ring(x,.09,z,s*1.3,.05,'#f9b560');
 for(let k=0;k<4;k++){const v=k*2.1+fx.id;b.sphere(x+Math.cos(v)*t*.7,.6+t*.8+Math.cos(k)*.19,z+Math.sin(v)*t*.7,.2+t*.26,'#73706d',4,7)}
 }else if(fx.tx!=null){const [tx,tz]=pWorld(fx.tx,fx.ty);const heavy=fx.kind==='heavy';b.tube([x,heavy?.75:.55,z],[tx,.47,tz],heavy?.045:.021,heavy?'#ffd88b':'#ffeabc',5);b.sphere(tx,.5,tz,heavy?.13:.09,'#ffbb69',4,7)} }
}
function drawPoints(b,state,time){for(const pt of state.points){const [x,z]=pWorld(pt.x,pt.y),col=teamColor[pt.owner];b.disk(x,.065,z,.72,'#273f42');b.ring(x,.075,z,.69,.09,col);b.ring(x,.078,z,1.31,.038,pt.owner?'#6e9d9a':'#a9a68b');b.cylinder(x,.12,z,.12,.5,'#35454a');b.sphere(x,.83,z,.18,col,5,9);}}
function drawSelection(b,entities,selected,pending,mouse,time){let rings=0;for(const e of entities)if(selected.includes(e.id)){const [x,z]=pos(e),r=e.size/22*.93+.11;b.ring(x,.09,z,r,.035,'#80fff0');
   if(rings<3){const spec=globalThis.WarEngine?.UNIT?.[e.kind];if(spec?.range){const radius=spec.range/WORLD_SCALE;b.ring(x,.058,z,radius,.021,'#4b9f9c');rings++;}}
   if(e.dest){const [dx,dz]=pWorld(e.dest.x,e.dest.y);b.tube([x,.09,z],[dx,.09,dz],.013,'#8dd9c1',5)}}
 if(pending&&mouse){const [x,z]=pWorld(mouse.x,mouse.y);b.ring(x,.08,z,.9,.05,'#baf2bf')}
}
function shader(gl,type,source){const sh=gl.createShader(type);gl.shaderSource(sh,source);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(sh));return sh}
function compile(gl){const vertex=shader(gl,gl.VERTEX_SHADER,`attribute vec3 a_pos;attribute vec3 a_nrm;attribute vec3 a_col;uniform mat4 u_matrix;uniform vec3 u_sun;varying vec3 v_col;uniform float u_light;void main(){gl_Position=u_matrix*vec4(a_pos,1.0);float nd=max(0.0,dot(normalize(a_nrm),u_sun));float shade=max(.22,nd*.74+.38)*u_light;v_col=clamp(a_col*shade,0.0,1.0);}`);
 const frag=shader(gl,gl.FRAGMENT_SHADER,`precision mediump float;varying vec3 v_col;void main(){gl_FragColor=vec4(v_col,1.0);}`);const p=gl.createProgram();gl.attachShader(p,vertex);gl.attachShader(p,frag);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));return p;}
function create(canvas,weatherCanvas){let gl=null;try{gl=canvas.getContext('webgl',{antialias:true,alpha:false,preserveDrawingBuffer:true})||canvas.getContext('experimental-webgl');}catch{}if(!gl)return {ready:false};
 let program;try{program=compile(gl)}catch(e){console.warn('3D renderer unavailable',e);return {ready:false}}
 const loc={position:gl.getAttribLocation(program,'a_pos'),normal:gl.getAttribLocation(program,'a_nrm'),color:gl.getAttribLocation(program,'a_col'),matrix:gl.getUniformLocation(program,'u_matrix'),sun:gl.getUniformLocation(program,'u_sun'),light:gl.getUniformLocation(program,'u_light')};
 const buffers={terrain:gl.createBuffer(),dynamic:gl.createBuffer()};let terrainKey=null,terrainLength=0,ctx=weatherCanvas.getContext('2d'),width=700,height=500,dpr=1;
 const motionCache=new Map(),trails=[];let trailId=0;
 gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.uniform3f(loc.sun,.45,.78,.54);
 function sizes(cam){const aspect=width/height,h=Math.max(14.4,27.2/aspect)*1.16/Math.max(.65,cam.zoom);return {h,w:h*aspect}}
 function bindBuffer(buffer,data,usage){gl.bindBuffer(gl.ARRAY_BUFFER,buffer);if(data)gl.bufferData(gl.ARRAY_BUFFER,data,usage);const st=9*4;gl.enableVertexAttribArray(loc.position);gl.vertexAttribPointer(loc.position,3,gl.FLOAT,false,st,0);gl.enableVertexAttribArray(loc.normal);gl.vertexAttribPointer(loc.normal,3,gl.FLOAT,false,st,3*4);gl.enableVertexAttribArray(loc.color);gl.vertexAttribPointer(loc.color,3,gl.FLOAT,false,st,6*4);}
 function resize(w,h,pixelRatio=1){width=Math.max(1,w);height=Math.max(1,h);dpr=Math.min(1.65,pixelRatio);const cw=Math.round(width*dpr),ch=Math.round(height*dpr);if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch}if(weatherCanvas.width!==cw||weatherCanvas.height!==ch){weatherCanvas.width=cw;weatherCanvas.height=ch}gl.viewport(0,0,cw,ch)}
 function pick(clientX,clientY,rect,cam){const s=sizes(cam),u=(clientX-rect.left)/Math.max(1,rect.width)*2-1,v=1-(clientY-rect.top)/Math.max(1,rect.height)*2;return {x:Math.max(4,Math.min(activeWorldWidth-4,cam.cx+u*s.w/2*WORLD_SCALE)),y:Math.max(4,Math.min(activeWorldHeight-4,cam.cy-v*s.h/(2*SIN_ELEV)*WORLD_SCALE))}}
 function unitsPerPixel(cam){const s=sizes(cam);return {x:s.w*WORLD_SCALE/width,y:s.h*WORLD_SCALE/(height*SIN_ELEV)}}
 function projectedDistance(entity,px,py,rect,cam){const s=sizes(cam),xz=pos(entity),cx=(cam.cx-activeWorldWidth/2)/WORLD_SCALE,cz=(cam.cy-activeWorldHeight/2)/WORLD_SCALE;
  const altitude=entity.kind==='jet'?2.5:entity.kind==='helicopter'?2.0:0;
  const sx=rect.left+rect.width*(.5+(xz[0]-cx)/s.w),sy=rect.top+rect.height*(.5-(altitude*DEPTH/Math.hypot(ELEVATION,DEPTH)-(xz[1]-cz)*SIN_ELEV)/s.h);
  return Math.hypot(px-sx,py-sy);
 }
 function weatherFX(kind,now,compact=false){const W=weatherCanvas.width,H=weatherCanvas.height;ctx.clearRect(0,0,W,H);if(kind==='clear')return;const night=kind==='night';if(night){ctx.fillStyle='rgba(2,13,37,.25)';ctx.fillRect(0,0,W,H);return}
 if(kind==='dust'){ctx.fillStyle='rgba(168,121,55,.15)';ctx.fillRect(0,0,W,H)}else{ctx.fillStyle='rgba(8,25,43,.12)';ctx.fillRect(0,0,W,H)}
 const count=compact?(kind==='rain'?60:35):(kind==='rain'?150:75),spd=kind==='rain'?1.45:.56;ctx.strokeStyle=kind==='rain'?'rgba(197,235,251,.43)':'rgba(237,194,131,.30)';ctx.lineWidth=kind==='rain'?1.2*dpr:2*dpr;ctx.beginPath();for(let i=0;i<count;i++){const seed=rnd(i*193+41),seedY=rnd(i*41+13),x=((seed*W+now*spd*(kind==='rain'?.2:.12))%(W+80))-40,y=((seedY*H+now*spd*(kind==='rain'?.48:.095))%(H+80))-40;ctx.moveTo(x,y);ctx.lineTo(x+(kind==='rain'?9:23)*dpr,y+(kind==='rain'?28:5)*dpr)}ctx.stroke();}
 function render(state,selected,pending,mouse,cam,weather,now,paused,options={}){if(!state)return;
 activeWorldWidth=state.width||1200;activeWorldHeight=state.height||720;
 const compact=!!options.economy;
 const view=sizes(cam),margin=180;
 const xRadius=view.w*WORLD_SCALE/2+margin, yRadius=view.h*WORLD_SCALE/(2*SIN_ELEV)+margin;
 const inView=e=>Math.abs(e.x-cam.cx)<=xRadius+e.size&&Math.abs(e.y-cam.cy)<=yRadius+e.size;
 const k=(state.mapId||state.theme)+':'+(state.mapVersion||0)+':'+activeWorldWidth+'x'+activeWorldHeight;if(terrainKey!==k){motionCache.clear();trails.length=0;const terrain=new Mesh();drawTerrain(terrain,state.theme,state.features||[],activeWorldWidth,activeWorldHeight);const data=new Float32Array(terrain.data);terrainLength=data.length/9;bindBuffer(buffers.terrain,data,gl.STATIC_DRAW);terrainKey=k}
 const mesh=new Mesh();drawPoints(mesh,state,now);
 if(!paused){const alive=new Set();for(const e of state.entities){if(e.category!=='unit')continue;alive.add(e.id);const prev=motionCache.get(e.id);const moving=prev&&Math.hypot(e.x-prev.x,e.y-prev.y)>1;
   if(moving&&(!prev.sample||now-prev.sample>130)){
     const kind=e.kind==='patrol'||e.kind==='destroyer'?'wake':['helicopter','jet'].includes(e.kind)?'contrail':'dust';
     if(e.kind!=='infantry'&&e.kind!=='engineer')trails.push({id:++trailId,x:prev.x,y:prev.y,born:now,kind});
     motionCache.set(e.id,{x:e.x,y:e.y,sample:now});
   }else if(!prev||!moving)motionCache.set(e.id,{x:e.x,y:e.y,sample:prev?.sample||now});
 }for(const id of motionCache.keys())if(!alive.has(id))motionCache.delete(id);
 }
 for(let i=trails.length-1;i>=0;i--)if(now-trails[i].born>1250)trails.splice(i,1);
 if(trails.length>85)trails.splice(0,trails.length-85);
 for(const t of trails){const [x,z]=pWorld(t.x,t.y),age=Math.max(0,(now-t.born)/1250),sz=.07+age*.26;if(t.kind==='wake'){mesh.ring(x,.062,z,sz,.018,'#a6e6e7');mesh.ring(x,.063,z,sz*.55,.013,'#70b6ca');}else if(t.kind==='contrail')mesh.sphere(x,2.2+age*.5,z,sz*.8,'#b9c9d0',3,5);else mesh.sphere(x,.13+age*.32,z,sz,'#8c897c',3,5);}
 for(const e of state.entities){if(!inView(e))continue;if(e.category==='building')drawBuilding(mesh,e);else drawUnit(mesh,e,now,compact);
   if(e.maxHp&&e.hp/e.maxHp<.43){const [x,z]=pos(e);const d=Math.sin(now*.002+e.id)*.12;mesh.sphere(x+d,e.category==='building'?1.35:0.73,z,.15+(.43-e.hp/e.maxHp)*.28,'#585f5d',4,6);}

   if(e.hp>0&&e.hp<e.maxHp&&e.maxHp>0){const [x,z]=pos(e),f=Math.max(0,Math.min(1,e.hp/e.maxHp)),w=e.category==='building'?.65:.37,h=e.category==='building'?2.25:1.55;mesh.box(x,h,z,w,.045,.09,'#432d31');mesh.box(x-(w*(1-f))/2,h+.045,z,w*f,.05,.10,f>.45?'#70d5a1':'#e8a16d');}
 }drawVfx(mesh,state,now);drawSelection(mesh,state.entities,selected,pending,mouse,now);
 const t=pWorld(cam.cx,cam.cy),eye=[t[0],ELEVATION,t[1]+DEPTH],target=[t[0],0,t[1]],size=sizes(cam),matrix=mul(ortho(size.w,size.h),lookAt(eye,target));
 gl.uniformMatrix4fv(loc.matrix,false,matrix);gl.uniform1f(loc.light,weather==='night'?.61:weather==='dust'?.85:weather==='rain'?.73:1);
 if(weather==='night')gl.clearColor(.055,.075,.13,1);else if(weather==='dust')gl.clearColor(.35,.29,.22,1);else gl.clearColor(.075,.12,.13,1);
 gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 bindBuffer(buffers.terrain,null,gl.STATIC_DRAW);gl.drawArrays(gl.TRIANGLES,0,terrainLength);
 const data=new Float32Array(mesh.data);bindBuffer(buffers.dynamic,data,gl.DYNAMIC_DRAW);gl.drawArrays(gl.TRIANGLES,0,data.length/9);weatherFX(weather,now,compact);
 if(paused){ctx.fillStyle='rgba(4,15,24,.66)';ctx.fillRect(0,0,weatherCanvas.width,weatherCanvas.height);ctx.font=`bold ${32*dpr}px sans-serif`;ctx.textAlign='center';ctx.fillStyle='#eefeff';ctx.fillText('المعركة متوقفة',weatherCanvas.width/2,weatherCanvas.height/2)}
 }
 return {ready:true,resize,pick,unitsPerPixel,projectedDistance,render};
}
root.WarRenderer3D={create};
})(typeof window!=='undefined'?window:globalThis);
