/* WAR COMMANDERS - deterministic-enough simulation shared by browser + Node.js */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.WarEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const WIDTH = 1200, HEIGHT = 720;
  const UNIT = {
    infantry: { label: 'مشاة', hp: 95, speed: 66, range: 86, damage: 18, reload: 0.82, cost: 85, energy: 5, size: 12 },
    scout: { label: 'استطلاع', hp: 140, speed: 85, range: 105, damage: 16, reload: 0.53, cost: 120, energy: 8, size: 15 },
    tank: { label: 'دبابة', hp: 290, speed: 44, range: 138, damage: 42, reload: 1.35, cost: 205, energy: 13, size: 21 },
    artillery: { label: 'مدفعية', hp: 175, speed: 32, range: 245, damage: 69, reload: 2.5, cost: 295, energy: 21, size: 19 },
    helicopter: { label: 'مروحية', hp: 205, speed: 104, range: 150, damage: 26, reload: .92, cost: 315, energy: 26, size: 19, air: true },
    jet: { label: 'مقاتلة', hp: 165, speed: 150, range: 205, damage: 46, reload: 1.85, cost: 465, energy: 40, size: 18, air: true },
    rocket: { label: 'راجمة صواريخ', hp: 160, speed: 37, range: 275, damage: 62, reload: 2.85, cost: 360, energy: 28, size: 19, splash: 38 },
    antiair: { label: 'دفاع جوي', hp: 220, speed: 48, range: 220, damage: 53, reload: 1.38, cost: 275, energy: 22, size: 19, airOnly: true },
    engineer: { label: 'مهندس صيانة', hp: 120, speed: 70, range: 88, damage: 0, reload: 1, cost: 155, energy: 13, size: 12, repair: 24 },
    patrol: { label: 'زورق دورية', hp: 215, speed: 82, range: 176, damage: 28, reload: 1.25, cost: 285, energy: 22, size: 19, naval: true },
    destroyer: { label: 'مدمرة بحرية', hp: 430, speed: 51, range: 255, damage: 64, reload: 2.18, cost: 510, energy: 42, size: 28, naval: true, splash: 32 },
    heavyTank: { label: 'دبابة اقتحام', hp: 520, speed: 31, range: 165, damage: 73, reload: 2.1, cost: 520, energy: 42, size: 27 },
    mortar: { label: 'هاون متحرك', hp: 130, speed: 44, range: 295, damage: 47, reload: 2.35, cost: 260, energy: 17, size: 16, splash: 36 },
    drone: { label: 'مسيرة استطلاع', hp: 85, speed: 128, range: 102, damage: 9, reload: .8, cost: 185, energy: 17, size: 12, air: true },
    jammer: { label: 'تشويش إلكتروني', hp: 165, speed: 50, range: 0, damage: 0, reload: 1.5, cost: 275, energy: 23, size: 17 }
  };
  const BUILDING = {
    hq: { label: 'مركز القيادة', hp: 1150, size: 54, cost: 0, energy: 0 },
    barracks: { label: 'الثكنات', hp: 410, size: 36, cost: 180, energy: 20 },
    factory: { label: 'مصنع المدرعات', hp: 490, size: 41, cost: 330, energy: 35 },
    refinery: { label: 'منشأة الموارد', hp: 320, size: 35, cost: 230, energy: 25 },
    tower: { label: 'برج دفاعي', hp: 310, size: 27, cost: 165, energy: 18, range: 195, damage: 27, reload: 0.8 },
    airbase: { label: 'قاعدة جوية', hp: 550, size: 43, cost: 395, energy: 34 },
    radar: { label: 'رادار دفاعي', hp: 340, size: 31, cost: 290, energy: 28, range: 245, damage: 32, reload: .95, airOnly: true },
    dock: { label: 'ميناء حربي', hp: 465, size: 34, cost: 350, energy: 36 }
  };
  const MISSIONS = [
    { title: 'شرارة البداية', region: 'سهول النصر', theme: 'desert', difficulty: 1, caption: 'أمّن الموارد واستولِ على نقاط السيطرة.' },
    { title: 'وادي الحديد', region: 'الوادي الأحمر', theme: 'desert', difficulty: 2, caption: 'ابنِ مصنع المدرعات قبل الهجوم.' },
    { title: 'حصار القلعة', region: 'الحدود الشرقية', theme: 'dust', difficulty: 3, caption: 'عطّل دفاعات الخصم وحاصر مقره.' },
    { title: 'عاصفة الصحراء', region: 'الكثبان الكبرى', theme: 'desert', difficulty: 4, caption: 'تحرك بسرعة نحو مناطق السيطرة.' },
    { title: 'الجبهة الشمالية', region: 'المرتفعات', theme: 'forest', difficulty: 5, caption: 'استخدم الفرق المختلفة لفتح الجبهة.' },
    { title: 'عملية الصقر', region: 'السهل الأخضر', theme: 'forest', difficulty: 6, caption: 'أبقِ مراكز الإنتاج تحت الحماية.' },
    { title: 'ليلة الحصار', region: 'مدينة الأطراف', theme: 'night', difficulty: 7, caption: 'اصمد أمام هجوم الخصم المتواصل.' },
    { title: 'الدرع الفولاذي', region: 'وادي التحصينات', theme: 'dust', difficulty: 8, caption: 'استثمر في الأبراج والمدفعية.' },
    { title: 'خط الدفاع الأخير', region: 'الأرض المحروقة', theme: 'night', difficulty: 9, caption: 'لا تسمح للخصم بالسيطرة على مركزك.' },
    { title: 'القائد الأعلى', region: 'ساحة المجد', theme: 'desert', difficulty: 10, caption: 'معركة الحسم للسيطرة على الخريطة.' },
    { title: 'أرض الجليد', region: 'الممر المتجمد', theme: 'snow', difficulty: 11, caption: 'احم وحداتك عند الممرات الباردة ووسّع انتشارك.' },
    { title: 'ميناء الصقور', region: 'الخليج الشرقي', theme: 'coast', difficulty: 12, caption: 'أمن الشريط الساحلي واستثمر في الرادار والدفاع الجوي.' },
    { title: 'مضيق الرعد', region: 'الأخدود الصخري', theme: 'canyon', difficulty: 13, caption: 'استخدم المدفعية والراجمات لدفع الجبهة للأمام.' },
    { title: 'القمة البيضاء', region: 'جبال الثلج', theme: 'snow', difficulty: 14, caption: 'رقّ قواتك ومصانعك قبل مواجهة القوات الثقيلة.' },
    { title: 'معركة الحسم', region: 'ساحل النصر', theme: 'coast', difficulty: 15, caption: 'التحكم في الموارد والترقيات مفتاح الفوز النهائي.' },
    { title: 'جسر الفجر', region: 'مضيق الجسر', theme: 'coast', difficulty: 16, caption: 'اعبر الجسر واستخدم الزوارق لحماية خطوط الإمداد.' },
    { title: 'الموانئ المشتعلة', region: 'خليج القوات', theme: 'coast', difficulty: 17, caption: 'دافع عن الموانئ وابنِ الأسطول للسيطرة على الممر البحري.' },
    { title: 'أرخبيل النصر', region: 'الجزر المتنازع عليها', theme: 'coast', difficulty: 18, caption: 'ناور بالمدمرات والزوارق مع حماية الجسر البري.' },
    { title: 'خط الخنادق', region: 'السواتر الغربية', theme: 'dust', difficulty: 19, caption: 'استخدم الخنادق لحماية المشاة وتقدّم عبر الممرات المفتوحة.' },
    { title: 'وادي المستنقعات', region: 'أدغال الشمال', theme: 'forest', difficulty: 20, caption: 'المستنقعات تبطئ القوات، والجسر يحسم طريق التقدم.' },
    { title: 'المدّ الأخير', region: 'خليج المعابر', theme: 'coast', difficulty: 21, caption: 'أمّن الجسر واشتبك بريًا وبحريًا للسيطرة على الخليج.' },
    { title: 'حاجز الفولاذ', region: 'وادي السد', theme: 'canyon', difficulty: 22, caption: 'انتشر بتشكيل خط الدفاع واستفد من الممرات الصخرية.' },
    { title: 'دلتا التحالف', region: 'مضيق الدلتا', theme: 'coast', difficulty: 23, caption: 'اعبر جسرَي الدلتا وادعم قواتك بالسفن.' },
    { title: 'المدينة الرمادية', region: 'حي المعابر', theme: 'night', difficulty: 24, caption: 'قاتل بين المباني المدمرة واستخدم التشكيلات لتغطية الطرق.' },
    { title: 'طريق الإمداد', region: 'ممر السهول', theme: 'forest', difficulty: 25, caption: 'أرسل الدوريات لحماية طرق العبور وصد الهجمات.' },
    { title: 'حراسة المضيق', region: 'الخليج البعيد', theme: 'coast', difficulty: 26, caption: 'أمّن الممرات بالزوارق وتجنب المناطق الصخرية.' },
    { title: 'السور الأخير', region: 'قلعة الأفق', theme: 'night', difficulty: 27, caption: 'استطلع الخنادق وحافظ على نقاط السيطرة.' },
    { title: 'جبهة الصقور الكبرى', region: 'وادي السهول الواسع', theme: 'desert', difficulty: 15, caption: 'ساحة ضخمة: سيطر على خطوط الموارد وشكّل أرتالًا مدرعة.' },
    { title: 'النهران المتقاطعان', region: 'دلتا المعابر الاستراتيجية', theme: 'coast', difficulty: 16, caption: 'ساحة ضخمة: استغل الجسور والموانئ واستطلع الضفاف.' },
    { title: 'المرتفعات المتنازع عليها', region: 'جبال الغابات الشمالية', theme: 'forest', difficulty: 17, caption: 'ساحة ضخمة: تحكم في الممرات الجبلية وادعم جيوشك بالمدفعية.' }
  ];
  // Authored tactical map layouts. Every stage has distinct routes, choke points and cover.
  const C=(kind,x,y,r)=>({kind,shape:'circle',x,y,r}),
        R=(kind,x,y,w,h)=>({kind,shape:'rect',x,y,w,h});
  const SOLID=new Set(['rock','ridge','water','ruins']);
  const MAPS=[
    {id:'victory-plains',label:'سهول الانتصار',icon:'🌾',detail:'ميدان مفتوح للتدريب مع غطاء محدود',points:[[470,220],[610,450],[770,205]], features:[C('rock',585,98,52),C('forest',460,590,80),C('dunes',780,550,105),R('road',620,345,600,68)]},
    {id:'iron-valley',label:'وادي الحديد',icon:'⛰️',detail:'ممران حول جدار صخري يفصل الجبهتين',points:[[450,250],[632,420],[780,252]],features:[R('ridge',600,168,150,270),R('ridge',608,600,170,170),C('forest',420,530,78),C('rock',825,564,65),R('road',616,420,470,80)]},
    {id:'citadel-siege',label:'حصار القلعة',icon:'🏙️',detail:'أنقاض مبانٍ ومسارات التفاف لحرب المدن',points:[[450,160],[612,415],[790,175]],features:[R('ruins',520,300,115,130),R('ruins',725,475,135,130),R('ruins',670,112,115,85),R('road',625,350,620,70),C('forest',375,570,70)]},
    {id:'sandstorm',label:'عاصفة الرمال',icon:'🏜️',detail:'كثبان تبطئ القوات الثقيلة وطرق سريعة',points:[[455,440],[610,240],[785,445]],features:[C('dunes',520,115,105),C('dunes',735,595,118),C('dunes',595,470,91),C('rock',835,285,55),R('road',610,355,700,52)]},
    {id:'northern-front',label:'الجبهة الخضراء',icon:'🌲',detail:'الغابات تمنح غطاءً دفاعيًا مقابل بطء الحركة',points:[[455,225],[605,525],[785,220]],features:[C('forest',425,395,105),C('forest',755,410,112),C('forest',610,150,88),C('rock',600,340,48),R('road',620,610,550,48)]},
    {id:'mountain-eagle',label:'ممر الصقر',icon:'🦅',detail:'جبال ومضيق مركزي يفرضان قتالًا تكتيكيًا',points:[[450,435],[622,340],[800,435]],features:[R('ridge',602,140,185,205),R('ridge',602,590,185,185),C('forest',410,155,80),C('rock',822,165,62),R('road',615,355,740,80)]},
    {id:'night-raid',label:'مدينة الظلال',icon:'🌙',detail:'مبانٍ مهجورة تخلق ساحات قتال ضيقة',points:[[440,475],[620,220],[800,495]],features:[R('ruins',510,280,130,135),R('ruins',740,365,130,125),R('ruins',610,575,100,95),R('road',600,155,690,62),C('forest',415,155,65)]},
    {id:'steel-shield',label:'الدرع الفولاذي',icon:'🛡️',detail:'سواتر صخرية متعددة تحمي مواقع المدفعية',points:[[445,185],[618,455],[810,200]],features:[R('ridge',500,355,115,160),R('ridge',745,335,110,155),C('rock',610,115,65),C('dunes',630,615,80),R('road',615,545,610,56)]},
    {id:'last-line',label:'خط الدفاع',icon:'🔥',detail:'ممرات ملتوية تضيق على الأرتال المدرعة',points:[[465,495],[605,230],[830,445]],features:[R('ridge',495,245,125,170),R('ridge',735,545,140,200),C('rock',735,190,77),C('rock',520,595,56),C('forest',600,390,76)]},
    {id:'grand-command',label:'ساحة القائد',icon:'🏆',detail:'مسارات مفتوحة بجوانب صخرية وعوائق',points:[[470,145],[610,410],[755,145]],features:[C('rock',475,380,67),C('rock',765,390,65),C('dunes',615,95,85),R('road',610,572,660,70),C('forest',610,260,65)]},
    {id:'frozen-gate',label:'البوابة المتجمدة',icon:'❄️',detail:'صفائح جليدية وصخور تؤثر في سرعة التقدم',points:[[440,220],[615,465],[800,225]],features:[C('ice',455,430,110),C('ice',780,470,112),C('rock',600,105,78),R('ridge',614,595,125,150),R('road',620,335,680,56)]},
    {id:'falcon-harbor',label:'ميناء الصقور',icon:'⚓',detail:'شاطئ ومياه مغلقة مع معبر أرضي حاسم',points:[[445,405],[620,355],[790,405]],features:[R('water',610,110,175,210),R('water',610,615,175,210),C('mud',435,540,80),C('forest',810,535,80),R('road',610,355,670,85)]},
    {id:'thunder-pass',label:'مضيق الرعد',icon:'🪨',detail:'جداران صخريان ومسارات تكتيكية للالتفاف',points:[[400,200],[625,360],[800,530]],features:[R('ridge',515,155,140,220),R('ridge',720,570,140,230),C('rock',790,125,63),C('rock',445,560,68),R('road',618,350,590,72)]},
    {id:'white-summit',label:'القمة البيضاء',icon:'🏔️',detail:'قمم ثلجية وممرات متعرجة للهجوم',points:[[440,450],[650,295],[790,460]],features:[R('ridge',540,150,140,240),R('ridge',695,585,140,210),C('ice',800,220,99),C('rock',420,260,54),C('ice',505,560,65)]},
    {id:'final-coast',label:'ساحل الحسم',icon:'🌊',detail:'نهر عريض لا يُعبر إلا من الممر الأوسط',points:[[445,200],[615,362],[790,500]],features:[R('water',610,115,170,230),R('water',610,615,170,210),R('road',610,361,710,92),C('forest',430,490,80),C('mud',825,210,85)]},
    {id:'dawn-bridge',label:'جسر الفجر',icon:'🌉',detail:'قناة وسطية واسعة وجسر للمركبات وزوارق للسيطرة',points:[[410,195],[600,255],[790,530]],features:[R('water',600,355,600,168),C('rock',600,105,68),C('forest',425,570,70),R('bridge',555,355,100,198),R('road',555,275,85,280)]},
    {id:'burning-harbor',label:'الموانئ المشتعلة',icon:'⚓',detail:'ممران بريان حول قناة ساحلية وخط موانئ عسكرية',points:[[430,185],[610,525],[790,185]],features:[R('water',600,367,600,172),R('bridge',505,367,90,210),R('bridge',780,367,90,210),C('rock',630,145,55),C('forest',370,545,65)]},
    {id:'victory-islands',label:'أرخبيل النصر',icon:'🏝️',detail:'قناة عريضة تُحسم بالقطع البحرية والجسر المركزي',points:[[430,210],[612,195],[790,515]],features:[R('water',600,358,600,186),R('bridge',585,358,105,220),C('rock',435,565,64),C('forest',760,155,83),C('dunes',775,540,61)]}
,
    {id:'western-trenches',label:'خط الخنادق',icon:'🪖',detail:'شبكة خنادق ترفع حماية الجنود مع مرتفعات وطرق الالتفاف',points:[[440,160],[606,370],[795,545]],features:[R('trench',460,355,235,65),R('trench',755,355,235,65),C('marsh',630,585,92),R('ridge',614,110,130,155),R('road',605,485,710,55),C('rock',800,150,50)]},
    {id:'marsh-crossing',label:'وادي المستنقعات',icon:'🌿',detail:'مستنقعات تبطئ العربات وجسر وحيد يقطع الممر المائي',points:[[430,195],[600,355],[790,515]],features:[C('marsh',445,460,98),C('marsh',778,230,102),C('forest',550,175,79),C('forest',770,566,67),R('water',610,360,440,120),R('bridge',612,360,96,152),R('trench',815,445,140,54)]},
    {id:'last-tide',label:'المدّ الأخير',icon:'🌊',detail:'ممر بحري طويل؛ الجسر وسط الخريطة والطريق البحري مكشوف',points:[[418,170],[604,360],[800,515]],features:[R('water',607,359,615,155),R('bridge',605,359,98,185),C('marsh',450,550,72),C('rock',813,160,58),R('road',607,505,580,54),C('forest',462,175,70)]},
    {id:'steel-dam',label:'حاجز الفولاذ',icon:'⛰️',detail:'ممران مفتوحان يحيطان بمرتفعات وساتر خنادق',points:[[425,190],[610,355],[785,500]],features:[R('ridge',555,135,128,170),R('ridge',675,585,140,185),C('rock',785,142,54),C('forest',420,550,62),R('road',610,355,660,68),R('trench',760,430,115,48)]},
    {id:'alliance-delta',label:'دلتا التحالف',icon:'🌉',detail:'جسران منفصلان لعبور قناة مائية مع قوات بحرية',points:[[425,192],[610,247],[794,515]],features:[R('water',600,360,440,148),R('bridge',515,360,90,178),R('bridge',702,360,90,178),C('forest',455,155,60),C('marsh',815,545,60),R('trench',792,190,125,47)]},
    {id:'grey-city',label:'المدينة الرمادية',icon:'🏙️',detail:'أحياء مدمرة وشوارع تكتيكية في معركة ليلية',points:[[405,188],[612,358],[815,515]],features:[R('ruins',525,210,120,142),R('ruins',718,474,128,140),R('ruins',610,90,158,88),R('road',620,350,685,68),C('forest',475,550,55),R('trench',830,205,116,52)]},
    {id:'supply-corridor',label:'طريق الإمداد',icon:'🚚',detail:'ممرات سريعة متقاطعة مع مناطق اختباء للدوريات',points:[[405,190],[615,365],[790,515]],features:[R('road',580,350,710,64),R('road',625,520,400,50),C('forest',465,525,90),C('forest',765,150,90),C('rock',590,150,48),R('trench',735,465,130,52)]},
    {id:'harbor-watch',label:'حراسة المضيق',icon:'🚤',detail:'دوريات ساحلية وجسران يحميان خطوط الإمداد',points:[[420,182],[600,240],[780,515]],features:[R('water',600,360,565,152),R('bridge',488,360,100,200),R('bridge',768,360,100,200),C('forest',438,560,65),C('rock',810,170,54),R('road',610,555,550,52)]},
    {id:'last-bastion',label:'السور الأخير',icon:'🏰',detail:'أحياء مدمرة وخنادق حول طريق مركزي متعرج',points:[[430,182],[612,350],[874,540]],features:[R('ruins',495,170,110,100),R('ruins',780,480,100,135),R('ridge',605,140,110,170),R('ridge',605,605,115,175),R('road',615,360,705,76),R('trench',420,450,155,49),R('trench',800,255,150,52)]},
    {id:'great-falcon-front',label:'جبهة الصقور الكبرى · واسعة',icon:'🦅',width:2200,height:1320,detail:'خريطة 2200×1320؛ طرق إمداد، رمال، غابات جانبية ومواقع مفتوحة',points:[[720,320],[1100,710],[1480,970]],features:[R('road',1100,660,1950,85),R('road',1100,360,1100,60),R('road',1000,1020,950,60),C('dunes',900,210,140),C('dunes',1320,1140,170),C('rock',1080,485,85),C('forest',760,1010,165),C('forest',1510,330,155),R('ridge',1120,1080,180,190),R('trench',1550,750,190,52),R('trench',640,625,165,52),C('rock',1220,230,65)]},
    {id:'twin-river-empire',label:'دلتا النهرين · واسعة',icon:'🌉',width:2400,height:1440,detail:'خريطة 2400×1440؛ نهران ومعابر وجزر وإمدادات بحرية',points:[[775,275],[930,710],[1650,1110]],features:[R('water',1180,710,910,185),R('bridge',930,710,90,235),R('bridge',1485,710,100,235),R('water',1210,1070,520,110),R('bridge',1210,1070,95,150),R('road',1200,405,1950,65),R('road',1200,1270,1300,75),C('forest',670,1050,135),C('forest',1730,380,160),C('rock',1015,225,80),C('mud',1480,1180,90),R('ruins',1730,940,155,180),R('trench',700,580,185,55)]},
    {id:'great-highlands',label:'المرتفعات الكبرى · واسعة',icon:'⛰️',width:2600,height:1560,detail:'خريطة 2600×1560؛ ثلاث جبهات وممرات جبلية وغابات ومخازن',points:[[820,555],[1290,800],[1820,1130]],features:[R('ridge',1160,260,230,410),R('ridge',1480,1270,245,390),R('ridge',1480,470,145,350),R('ridge',1120,1180,200,360),R('road',1310,800,2300,90),R('road',1270,1385,1100,70),C('forest',750,1050,205),C('forest',1880,480,190),C('forest',1450,940,120),C('rock',1820,270,115),C('rock',870,360,100),R('trench',1030,680,195,58),R('trench',1810,930,190,58),C('dunes',1850,1340,135)]},
  ];
  const mapWidth=state=>state?.width||WIDTH, mapHeight=state=>state?.height||HEIGHT;
  const SPEED={forest:.78,dunes:.77,mud:.62,ice:.85,road:1.2,bridge:1.1,trench:.87,marsh:.55};
  const COVER={forest:.20,ruins:.24,trench:.30,marsh:.08};
  function inFeature(f,x,y,margin=0){return f.shape==='circle'?Math.hypot(x-f.x,y-f.y)<f.r+margin:Math.abs(x-f.x)<f.w/2+margin&&Math.abs(y-f.y)<f.h/2+margin;}
  function blocked(state,x,y,margin=8,domain='ground'){
    if(x<12+margin||x>mapWidth(state)-12-margin||y<12+margin||y>mapHeight(state)-12-margin)return true;
    const features=state.features||[];
    if(domain==='naval')return !features.some(f=>f.kind==='water'&&inFeature(f,x,y,-margin));
    const onBridge=features.some(f=>f.kind==='bridge'&&inFeature(f,x,y,-margin));
    return features.some(f=>SOLID.has(f.kind)&&!(onBridge&&f.kind==='water')&&inFeature(f,x,y,margin));
  }
  function terrainAt(state,x,y){let factor=1,cover=0;for(const f of state.features||[])if(inFeature(f,x,y)){factor*=SPEED[f.kind]||1;cover=Math.max(cover,COVER[f.kind]||0)}return {speed:Math.max(.4,Math.min(1.25,factor)),cover};}
  function lineOpen(state,a,b,margin=8,domain='ground'){const d=distance(a,b);if(d<1)return true;const steps=Math.ceil(d/15);for(let i=1;i<steps;i++){const t=i/steps;if(blocked(state,a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,margin,domain))return false}return true;}
  function nearestOpen(state,pt,margin=12,domain='ground'){const x=clamp(pt.x,20,mapWidth(state)-20),y=clamp(pt.y,20,mapHeight(state)-20);if(!blocked(state,x,y,margin,domain))return {x,y};for(let r=22;r<=240;r+=22)for(let j=0;j<16;j++){let t=j*Math.PI/8,p={x:clamp(x+Math.cos(t)*r,20,mapWidth(state)-20),y:clamp(y+Math.sin(t)*r,20,mapHeight(state)-20)};if(!blocked(state,p.x,p.y,margin,domain))return p}return {x,y};}
  // 32px A* grid, deterministic and only called when a route crosses solid terrain.
  function findPath(state,start,goal,margin=10,domain='ground'){const dst=nearestOpen(state,goal,margin,domain);if(lineOpen(state,start,dst,margin,domain))return [dst];const CELL=(mapWidth(state)>WIDTH?45:30),cols=Math.ceil(mapWidth(state)/CELL),rows=Math.ceil(mapHeight(state)/CELL);
    const idx=(x,y)=>y*cols+x,loc=i=>({x:(i%cols+.5)*CELL,y:(Math.floor(i/cols)+.5)*CELL});
    const toIdx=p=>idx(clamp(Math.floor(p.x/CELL),0,cols-1),clamp(Math.floor(p.y/CELL),0,rows-1));
    const gridGoal=p=>{const preferred=toIdx(p);const first=loc(preferred);if(!blocked(state,first.x,first.y,margin,domain)&&lineOpen(state,first,p,margin,domain))return preferred;
      let best=-1,bestDist=Infinity;for(let i=0;i<cols*rows;i++){const cell=loc(i),d=distance(cell,p);if(d>120||d>=bestDist||blocked(state,cell.x,cell.y,margin,domain)||!lineOpen(state,cell,p,margin,domain))continue;best=i;bestDist=d;}return best<0?preferred:best;};
    const from=toIdx(start),toward=gridGoal(dst),open=[from],g=new Float64Array(cols*rows).fill(Infinity),f=new Float64Array(cols*rows).fill(Infinity),previous=new Int16Array(cols*rows).fill(-1),seen=new Uint8Array(cols*rows);
    g[from]=0;const goalP=loc(toward);f[from]=distance(start,dst);
    for(let step=0;open.length&&step<cols*rows;step++){
      let bestAt=0;for(let j=1;j<open.length;j++)if(f[open[j]]<f[open[bestAt]])bestAt=j;const current=open.splice(bestAt,1)[0];if(current===toward)break;seen[current]=1;
      let cx=current%cols,cy=Math.floor(current/cols);const base=loc(current);
      for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
        const nx=cx+dx,ny=cy+dy;if(nx<0||ny<0||nx>=cols||ny>=rows)continue;const ni=idx(nx,ny),np=loc(ni);
        if(seen[ni]||blocked(state,np.x,np.y,margin,domain)||!lineOpen(state,base,np,margin,domain))continue;
        const alt=g[current]+Math.hypot(dx,dy)*(CELL/(terrainAt(state,np.x,np.y).speed||1));
        if(alt<g[ni]){previous[ni]=current;g[ni]=alt;f[ni]=alt+distance(np,goalP);if(!open.includes(ni))open.push(ni)}
      }
    }
    if(previous[toward]<0)return [nearestOpen(state,goal,margin,domain)];
    const path=[];let at=toward;while(at!==from&&at>=0&&path.length<80){path.push(loc(at));at=previous[at]}path.reverse();
    path.push(dst);const simplified=[];let pivot=start;for(let i=0;i<path.length;){let j=path.length-1;while(j>i&&!lineOpen(state,pivot,path[j],margin,domain))j--;simplified.push(path[j]);pivot=path[j];i=j+1;}
    return simplified;
  }
  // Authoritative reconnaissance: cells store explored territory separately from current visibility.
  // All clients receive team-scoped snapshots in multiplayer to prevent leaking hidden units.
  const FOG_COLS=30,FOG_ROWS=18,FOG_CELL=40;
  const SIGHT={hq:230,barracks:160,factory:155,refinery:135,tower:260,airbase:210,radar:410,dock:250,
    infantry:135,scout:285,tank:205,artillery:205,helicopter:340,jet:395,rocket:225,antiair:270,engineer:145,patrol:270,destroyer:350,heavyTank:220,mortar:220,drone:465,jammer:300};
  function sightRange(e,state){
    const basic=SIGHT[e.kind]||150;
    if(!state||e.team===0)return basic;
    const jammed=state.entities?.some(j=>j.hp>0&&j.kind==='jammer'&&j.team!==e.team&&Math.hypot(j.x-e.x,j.y-e.y)<260);
    return jammed?Math.round(basic*.6):basic;
  }
  function pointVisible(state,team,x,y,extra=0){
    if(![1,2].includes(Number(team)))return false;
    return state.entities.some(e=>e.team===team&&e.hp>0&&Math.hypot(e.x-x,e.y-y)<=sightRange(e,state)+extra);
  }
  function canSee(state,team,enemy){
    if(!enemy||enemy.hp<=0)return false;
    return enemy.team===Number(team)||pointVisible(state,Number(team),enemy.x,enemy.y,enemy.size*.55);
  }
  function updateIntel(state){
    state.intel ||= {};
    for(const team of [1,2]){
      const cols=Math.ceil(mapWidth(state)/FOG_CELL),rows=Math.ceil(mapHeight(state)/FOG_CELL);
      const intel=state.intel[team] ||= {cols,rows,cell:FOG_CELL,visible:Array(cols*rows).fill(0),explored:Array(cols*rows).fill(0)};
      intel.visible.fill(0);
      for(const e of state.entities){
        if(e.team!==team||e.hp<=0)continue;
        const r=sightRange(e,state),x0=Math.max(0,Math.floor((e.x-r)/FOG_CELL)),x1=Math.min(intel.cols-1,Math.floor((e.x+r)/FOG_CELL));
        const y0=Math.max(0,Math.floor((e.y-r)/FOG_CELL)),y1=Math.min(intel.rows-1,Math.floor((e.y+r)/FOG_CELL));
        for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
          const dx=e.x-(x+.5)*FOG_CELL,dy=e.y-(y+.5)*FOG_CELL;
          if(dx*dx+dy*dy<=(r+FOG_CELL*.7)**2){const k=y*intel.cols+x;intel.visible[k]=1;intel.explored[k]=1;}
        }
      }
    }
    return state.intel;
  }
  function viewForTeam(state,team){
    team=Number(team);if(![1,2].includes(team))return null;
    if(!state.intel?.[team])updateIntel(state);
    return {...state,
      entities:state.entities.filter(e=>e.team===team||canSee(state,team,e)),
      effects:(state.effects||[]).filter(fx=>fx.team===team||pointVisible(state,team,fx.x,fx.y,15)),
      events:(state.events||[]).filter(ev=>!ev.team||ev.team===team),
      players:{[team]:state.players[team]},
      intel:{[team]:state.intel[team]},
    };
  }
  const TECH = {
    armor: {label:'تدريع القوات',baseCost:240,baseEnergy:24,maxLevel:3},
    weapons: {label:'تطوير الأسلحة',baseCost:285,baseEnergy:29,maxLevel:3},
    mobility: {label:'تطوير الحركة',baseCost:220,baseEnergy:21,maxLevel:3}
  };
  function techCost(kind, level){const t=TECH[kind];if(!t||level>=t.maxLevel)return null;return {credits:Math.round(t.baseCost*(level+1)*1.12),energy:Math.round(t.baseEnergy*(level+1))};}
  function buildingCost(e){if(!e||e.category!=='building'||e.level>=3)return null;const spec=BUILDING[e.kind];return {credits:Math.round(Math.max(260,spec.cost)*(.85+e.level*.65)),energy:Math.round(Math.max(22,spec.energy)*(.8+e.level*.5))};}
  const costs = { ...Object.fromEntries(Object.entries(UNIT).map(([k,v]) => [k,{ credits:v.cost,energy:v.energy }])),
                  ...Object.fromEntries(Object.entries(BUILDING).map(([k,v]) => [k,{ credits:v.cost,energy:v.energy }])) };
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const distance = (a,b) => Math.hypot(a.x - b.x, a.y - b.y);
  const teamRes = (state,team) => state.players[team];
  function log(state,msg,team=0) {
    state.events.push({id: ++state.seq, time: Math.floor(state.time), text:msg, team});
    if(state.events.length > 25) state.events.shift();
  }
  function entity(state, team, kind, x, y, isBuilding) {
    const spec = isBuilding ? BUILDING[kind] : UNIT[kind];
    const obj = { id: ++state.seq, team, kind, category: isBuilding ? 'building' : 'unit', x, y,
      level:1, hp: spec.hp, maxHp: spec.hp, size:spec.size, cooldown:0, dest:null, targetId:null, angle: team === 1 ? 0 : Math.PI, kills:0 };
    state.entities.push(obj);
    return obj;
  }
  function createState(options={}) {
    const mission = clamp(Number(options.stage)||1,1,MISSIONS.length);
    const difficulty = MISSIONS[mission-1].difficulty;
    const defaultMap=MAPS[mission-1];
    const custom=options.map;
    const validCustom=custom&&typeof custom==='object'&&Array.isArray(custom.features)&&custom.features.length<=60&&Array.isArray(custom.points)&&custom.points.length===3;
    const layout=validCustom?{
      id:'custom-'+String(custom.id||'local').slice(0,32), label:String(custom.label||'خريطة مخصصة').slice(0,40),
      features:custom.features.filter(f=>f&&['rock','ridge','water','ruins','forest','road','dunes','ice','mud','bridge','trench','marsh'].includes(f.kind)&&['rect','circle'].includes(f.shape)&&[f.x,f.y,f.r||1,f.w||1,f.h||1].every(Number.isFinite)).slice(0,60).map(f=>({...f})),
      points:custom.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))?custom.points:defaultMap.points
    }:defaultMap;
    const worldW=validCustom?WIDTH:(layout.width||WIDTH),worldH=validCustom?HEIGHT:(layout.height||HEIGHT);
    const X=n=>n*worldW/WIDTH,Y=n=>n*worldH/HEIGHT;
    const state = { version:3, width:worldW, height:worldH, stage:mission, mapId:layout.id, mapVersion:validCustom?Date.now():0, mapLabel:layout.label, features:layout.features.map(f=>({...f})), theme:validCustom&&['desert','dust','forest','night','snow','coast','canyon'].includes(custom.theme)?custom.theme:MISSIONS[mission-1].theme,
      name:MISSIONS[mission-1].title, time:0, seq:0, finished:false, winner:null, vsHuman:!!options.vsHuman,
      entities:[], effects:[], events:[], points:[
        { id:1,x:layout.points[0][0],y:layout.points[0][1], owner:0, progress:0, capturedBy:0, label:'ألفا' },
        { id:2,x:layout.points[1][0],y:layout.points[1][1], owner:0, progress:0, capturedBy:0, label:'بيتا' },
        { id:3,x:layout.points[2][0],y:layout.points[2][1], owner:0, progress:0, capturedBy:0, label:'جاما' }
      ],
      players:{ 1:{ credits:540, energy:115, wins:0, killed:0, captured:0, aiTimer:4, momentum:0, tech:{armor:0,weapons:0,mobility:0} },
                2:{ credits:410 + difficulty*48, energy:115, wins:0, killed:0, captured:0, aiTimer:5.5, momentum:0, tech:{armor:0,weapons:0,mobility:0} } },
      dominance:{team:0, seconds:0}
    };
    entity(state,1,'hq',X(120),Y(365),true);
    entity(state,1,'barracks',X(220),Y(470),true);
    entity(state,1,'refinery',X(220),Y(260),true);
    entity(state,1,'infantry',X(270),Y(420),false);
    entity(state,1,'infantry',X(285),Y(340),false);
    entity(state,1,'scout',X(255),Y(385),false);
    entity(state,2,'hq',X(1080),Y(355),true);
    entity(state,2,'barracks',X(980),Y(230),true);
    entity(state,2,'refinery',X(982),Y(460),true);
    entity(state,2,'infantry',X(925),Y(280),false);
    entity(state,2,'infantry',X(922),Y(378),false);
    if(difficulty >= 3) entity(state,2,'tower',X(978),Y(330),true);
    if(difficulty >= 5) entity(state,2,'tank',X(mission>=16?944:900),Y(410),false);
    if(difficulty >= 7) entity(state,2,'factory',X(1060),Y(495),true);
    if(difficulty >= 6) entity(state,2,'airbase',X(1110),Y(630),true);
    if(mission>=11){
      entity(state,2,'radar',X(1032),Y(155),true);
      entity(state,2,'antiair',X(880),Y(210),false);
      if(mission>=13)entity(state,2,'rocket',X(903),Y(500),false);
    }
    if(!validCustom && mission>=16 && state.features.some(f=>f.kind==='water')){
      entity(state,1,'dock',X(310),Y(240),true);entity(state,2,'dock',X(890),Y(240),true);
      const shipA=nearestOpen(state,{x:X(315),y:Y(358)},UNIT.patrol.size*.5,'naval');
      const shipB=nearestOpen(state,{x:X(885),y:Y(358)},UNIT.patrol.size*.5,'naval');
      if(!blocked(state,shipA.x,shipA.y,UNIT.patrol.size*.5,'naval'))entity(state,1,'patrol',shipA.x,shipA.y,false);
      if(!blocked(state,shipB.x,shipB.y,UNIT.patrol.size*.5,'naval'))entity(state,2,'patrol',shipB.x,shipB.y,false);
    }
    if(worldW>WIDTH){
      state.players[1].credits=1550;state.players[1].energy=360;
      state.players[2].credits=1550;state.players[2].energy=360;
      const a=entity(state,1,'factory',X(275),Y(560),true),b=entity(state,2,'factory',X(925),Y(560),true);
      entity(state,1,'tank',X(315),Y(460),false); entity(state,2,'tank',X(890),Y(450),false);
      // Correct initial unit positions that overlap authored rocks or structures in huge maps.
      for(const troop of state.entities.filter(e=>e.category==='unit')){
        const spec=UNIT[troop.kind],domain=spec.air?'air':spec.naval?'naval':'ground';
        if(domain!=='air'&&blocked(state,troop.x,troop.y,troop.size*.38,domain)){
          const safe=nearestOpen(state,troop,troop.size*.38,domain);
          if(!blocked(state,safe.x,safe.y,troop.size*.38,domain)){troop.x=safe.x;troop.y=safe.y;}
        }
      }
    }
    log(state,'بدأت عملية '+state.name+'. سيطر على النقاط أو دمر مركز القيادة المعادي.');
    updateIntel(state);
    return state;
  }
  function find(state,id){return state.entities.find(e=>e.id===id && e.hp>0);}
  function canAfford(state,team,kind) {
    const cost=costs[kind], p=teamRes(state,team);
    return !!cost && p.credits >= cost.credits && p.energy >= cost.energy;
  }
  function spend(state,team,kind) {const c=costs[kind], p=teamRes(state,team);p.credits-=c.credits;p.energy-=c.energy;}
  function applyArmor(state,team){
    const level=state.players[team].tech.armor;
    for(const u of state.entities.filter(e=>e.team===team&&e.category==='unit')){
      const intended=Math.round(UNIT[u.kind].hp*(1+level*.16));
      if(u.maxHp!==intended){const old=u.maxHp;u.maxHp=intended;u.hp=Math.min(intended,u.hp+Math.max(0,intended-old));}
    }
  }
  function act(state,team,action) {
    team=Number(team);
    if (state.finished || ![1,2].includes(team) || !action || typeof action!=='object') return {ok:false,error:'تعذر تنفيذ الأمر'};
    const p=teamRes(state,team);
    if(action.type==='upgrade') {
      if(action.scope==='tech'){
        const kind=String(action.kind||'');const t=TECH[kind];
        if(!t)return {ok:false,error:'ترقية غير معروفة'};
        const level=p.tech[kind]||0,cost=techCost(kind,level);
        if(!cost)return {ok:false,error:'وصل البحث إلى أعلى مستوى'};
        if(p.credits<cost.credits||p.energy<cost.energy)return {ok:false,error:'الموارد غير كافية للبحث'};
        p.credits-=cost.credits;p.energy-=cost.energy;p.tech[kind]=level+1;
        if(kind==='armor')applyArmor(state,team);
        log(state,'اكتملت ترقية '+t.label+' إلى المستوى '+p.tech[kind],team);
        return {ok:true,level:p.tech[kind]};
      }
      if(action.scope==='building'){
        const b=find(state,Number(action.id));
        if(!b||b.team!==team||b.category!=='building')return {ok:false,error:'اختر أحد مبانيك أولًا'};
        const cost=buildingCost(b);
        if(!cost)return {ok:false,error:'المبنى في أعلى مستوى'};
        if(p.credits<cost.credits||p.energy<cost.energy)return {ok:false,error:'الموارد غير كافية للترقية'};
        p.credits-=cost.credits;p.energy-=cost.energy;b.level++;
        const delta=Math.round(BUILDING[b.kind].hp*.34);b.maxHp+=delta;b.hp=Math.min(b.maxHp,b.hp+delta);
        log(state,'ترقية '+BUILDING[b.kind].label+' إلى المستوى '+b.level,team);
        return {ok:true,level:b.level,id:b.id};
      }
      return {ok:false,error:'نوع ترقية غير معروف'};
    }
    if(action.type==='train') {
      const spec=UNIT[action.kind];
      if(!spec) return {ok:false,error:'وحدة غير معروفة'};
      const required=spec.naval?'dock':['infantry','scout','engineer','mortar'].includes(action.kind) ? 'barracks' : (spec.air ? 'airbase' : 'factory');
      const producer=state.entities.find(e=>e.team===team && e.kind===required && e.hp>0);
      if(!producer) return {ok:false,error:required==='dock' ? 'ابنِ ميناءً حربيًا قرب المياه أولًا' : required==='factory' ? 'ابنِ مصنع المدرعات أولًا' : required==='airbase' ? 'ابنِ قاعدة جوية أولًا' : 'تحتاج إلى ثكنات'};
      if(!canAfford(state,team,action.kind)) return {ok:false,error:'الموارد غير كافية'};
      if(state.entities.filter(e=>e.team===team && e.category==='unit').length>=(state.width>WIDTH?75:45)) return {ok:false,error:'بلغت الحد الأقصى للقوات'};
      if(spec.naval&&!state.features.some(f=>f.kind==='water'))return {ok:false,error:'هذه الخريطة لا تحتوي على بحر صالح للإبحار'};
      const spawn=spec.naval?nearestOpen(state,{x:producer.x,y:producer.y+110},spec.size*.5,'naval'):
        nearestOpen(state,{x:clamp(producer.x + (team===1?65:-65)+(Math.random()-.5)*30,20,mapWidth(state)-20), y:clamp(producer.y+(Math.random()-.5)*80,25,mapHeight(state)-25)},spec.size*.45);
      if(spec.naval&&blocked(state,spawn.x,spawn.y,spec.size*.5,'naval'))return {ok:false,error:'لا توجد مياه عميقة قرب الميناء'};
      const {x,y}=spawn;
      spend(state,team,action.kind);
      const newUnit=entity(state,team,action.kind,x,y,false);
      const armor=p.tech.armor||0;
      if(armor){newUnit.maxHp=Math.round(spec.hp*(1+.16*armor));newUnit.hp=newUnit.maxHp;}
      log(state,'تم إنتاج '+spec.label,team);
      return {ok:true,id:newUnit.id};
    }
    if(action.type==='build') {
      const kind=action.kind;
      if(!BUILDING[kind]||kind==='hq')return {ok:false,error:'المبنى غير متاح'};
      const x=Math.round(Number(action.x)), y=Math.round(Number(action.y));
      if(!Number.isFinite(x)||!Number.isFinite(y)||x<65||x>mapWidth(state)-65||y<65||y>mapHeight(state)-65)return {ok:false,error:'موقع البناء خارج الخريطة'};
      if(!state.entities.some(e=>e.team===team&&e.category==='building'&&distance(e,{x,y})<300))return {ok:false,error:'ابنِ بالقرب من قاعدتك'};
      if(state.entities.some(e=>distance(e,{x,y})<e.size+BUILDING[kind].size+12))return {ok:false,error:'الموقع مشغول'};
      if(state.points.some(pt=>distance(pt,{x,y})<80))return {ok:false,error:'لا يمكن البناء على نقطة سيطرة'};
      if(kind==='dock'&&!state.features?.some(f=>f.kind==='water'&&Math.hypot(x-f.x,y-f.y)<Math.max(f.w||f.r*2||0,f.h||f.r*2||0)/2+160))return {ok:false,error:'يجب بناء الميناء قرب المياه'};
      if(blocked(state,x,y,BUILDING[kind].size*.72))return {ok:false,error:'تضاريس غير صالحة للبناء — اختر أرضًا مفتوحة'};
      if(!canAfford(state,team,kind))return {ok:false,error:'الموارد غير كافية'};
      spend(state,team,kind);
      const b=entity(state,team,kind,x,y,true);
      log(state,'اكتمل بناء '+BUILDING[kind].label,team);
      return {ok:true,id:b.id};
    }
    if(action.type==='hold') {
      const ids=Array.isArray(action.ids)?action.ids.slice(0,45):[];
      const valid=[...new Set(ids)].map(id=>find(state,Number(id))).filter(e=>e&&e.team===team&&e.category==='unit');
      if(!valid.length)return {ok:false,error:'حدد وحداتك أولًا'};
      for(const e of valid){e.dest=null;e.route=null;e.routeGoal=null;e.routeTimer=0;e.targetId=null;e.patrol=null;e.stance='hold';}
      return {ok:true,count:valid.length};
    }
    if(action.type==='patrol') {
      if(!Number.isFinite(action.x)||!Number.isFinite(action.y)||action.x<12||action.x>mapWidth(state)-12||action.y<12||action.y>mapHeight(state)-12)
        return {ok:false,error:'نقطة الدورية خارج حدود الخريطة'};
      const ids=Array.isArray(action.ids)?action.ids.slice(0,45):[];
      const valid=[...new Set(ids)].map(id=>find(state,Number(id))).filter(e=>e&&e.team===team&&e.category==='unit');
      if(!valid.length)return {ok:false,error:'حدد قواتك لإصدار أمر دورية'};
      const pending=valid.map(e=>{
        const domain=UNIT[e.kind]?.air?'air':UNIT[e.kind]?.naval?'naval':'ground';
        const end=domain==='air'?{x:action.x,y:action.y}:nearestOpen(state,{x:action.x,y:action.y},e.size*.45,domain);
        return {e,end,domain};
      });
      if(pending.some(({end,e,domain})=>domain!=='air'&&blocked(state,end.x,end.y,e.size*.45,domain)))
        return {ok:false,error:'لا يوجد مسار مناسب للدورية على هذا النوع من التضاريس'};
      for(const {e,end} of pending){
        e.patrol={a:{x:e.x,y:e.y},b:end,next:'b'};
        e.dest={...end};e.route=null;e.routeGoal=null;e.routeTimer=0;e.targetId=null;e.stance='patrol';
      }
      log(state,'بدأت '+valid.length+' وحدة دورية حراسة',team);
      return {ok:true,count:valid.length};
    }
    if(action.type==='command') {
      const formation=action.formation===undefined?'grid':String(action.formation);
      if(!FORMATIONS.includes(formation))return {ok:false,error:'تشكيل عسكري غير معروف'};
      // Formation density is an enumerated tactical choice, validated on the server.
      const spacingMode=action.spacing===undefined?'standard':String(action.spacing);
      if(!FORMATION_SPACING.includes(spacingMode))return {ok:false,error:'كثافة التشكيل غير معروفة'};
      if(!Number.isFinite(Number(action.x))||!Number.isFinite(Number(action.y)))return {ok:false,error:'إحداثيات غير صحيحة'};
      const ids=Array.isArray(action.ids)?action.ids.slice(0,45):[];
      const dest={x:clamp(Number(action.x),14,mapWidth(state)-14),y:clamp(Number(action.y),14,mapHeight(state)-14)};
      const enemy=action.targetId ? find(state,Number(action.targetId)) : null;
      if(enemy&&enemy.team!==team&&!canSee(state,team,enemy))return {ok:false,error:'الهدف خارج نطاق الاستطلاع؛ اقترب لكشفه أولًا'};
      const valid=[...new Set(ids)].map(id=>find(state,Number(id))).filter(e=>e&&e.team===team&&e.category==='unit');
      if(!valid.length)return {ok:false,error:'حدد وحداتك أولًا'};
      const center={x:valid.reduce((n,e)=>n+e.x,0)/valid.length,y:valid.reduce((n,e)=>n+e.y,0)/valid.length};
      const heading=Math.atan2(dest.y-center.y,dest.x-center.x);
      const baseSpace=Math.max(34,Math.min(66,Math.max(...valid.map(e=>e.size))*2+9));
      const space=clamp(Math.round(baseSpace*SPACING_FACTOR[spacingMode]),28,80);
      const offsets=formationOffsets(valid.length,formation,heading,space);
      for(let i=0;i<valid.length;i++) {
        const e=valid[i], spread=valid.length>1?offsets[i]:{x:0,y:0};
        const goal={x:clamp(dest.x+spread.x,12,mapWidth(state)-12),y:clamp(dest.y+spread.y,12,mapHeight(state)-12)};
        e.dest=UNIT[e.kind]?.air?goal:nearestOpen(state,goal,e.size*.45,UNIT[e.kind]?.naval?'naval':'ground');
        e.route=null;e.routeGoal=null;e.routeTimer=0;e.patrol=null;e.stance='advance';
        e.targetId=enemy&&enemy.team!==team&&(!UNIT[e.kind]?.airOnly||UNIT[enemy.kind]?.air)?enemy.id:null;
      }
      return {ok:true,count:valid.length,formation,spacing:spacingMode};
    }
    return {ok:false,error:'أمر غير معروف'};
  }
  // Tactical formations: offsets expressed relative to the direction of travel.
  // The server derives the offsets from units and the commanded destination;
  // no client-supplied individual positions are trusted.
  const FORMATIONS = Object.freeze(['grid','line','column','wedge']);
  const FORMATION_SPACING=Object.freeze(['tight','standard','wide']);
  const SPACING_FACTOR=Object.freeze({tight:.72,standard:1,wide:1.33});
  function formationOffsets(count,kind='grid',direction=0,spacing=47){
    if(!FORMATIONS.includes(kind))throw new Error('Unknown formation');
    count=Math.max(0,Math.min(45,Math.floor(Number(count)||0)));
    spacing=clamp(Number(spacing)||47,28,80);
    const dx=Math.cos(direction),dy=Math.sin(direction),px=-dy,py=dx;
    const offsets=[];
    for(let i=0;i<count;i++){
      let side=0,back=0;
      if(kind==='line')side=(i-(count-1)/2)*spacing;
      else if(kind==='column')back=(i-(count-1)/2)*spacing;
      else if(kind==='wedge'&&i){const rank=Math.ceil(i/2),sign=i%2?-1:1;side=sign*rank*spacing*.68;back=rank*spacing*.74;}
      else if(kind==='grid'){const cols=Math.min(5,Math.ceil(Math.sqrt(count)));side=((i%cols)-(Math.min(cols,count)-1)/2)*spacing;back=(Math.floor(i/cols)-(Math.ceil(count/cols)-1)/2)*spacing;}
      offsets.push({x:side*px-back*dx,y:side*py-back*dy});
    }
    return offsets;
  }
  function nextTarget(state,e,range) {
    let best=null, bestDistance=Infinity;
    for(const other of state.entities){
      if(other.team===e.team||other.hp<=0||!canSee(state,e.team,other)||(UNIT[e.kind]?.airOnly||BUILDING[e.kind]?.airOnly)&&!UNIT[other.kind]?.air)continue;
      const d=distance(e,other)-other.size;
      if(d<range+30&&d<bestDistance){best=other;bestDistance=d;}
    }
    return best;
  }
  function attack(state,e,target,spec) {
    if(e.cooldown>0 || !target || target.hp<=0)return;
    const p=state.players[e.team],bonus=1+(.18*(p.tech?.weapons||0));
    const damage=Math.round(spec.damage*bonus*(spec.airOnly?1.35:1));
    const cover=UNIT[target.kind]?.air?0:terrainAt(state,target.x,target.y).cover;
    const actualDamage=Math.max(1,Math.round(damage*(1-cover)));
    target.hp-=actualDamage;
    if(spec.splash){for(const other of state.entities)if(other!==target&&other.team!==e.team&&other.hp>0&&distance(other,target)<spec.splash){other.hp-=Math.round(damage*.38);}}
    
    e.cooldown=spec.reload;
    state.effects.push({id:++state.seq, x:e.x, y:e.y, tx:target.x, ty:target.y, ttl:0.2, kind:['artillery','mortar','heavyTank'].includes(e.kind)?'heavy':e.kind==='rocket'?'missile':'shot',team:e.team});
    if(target.hp<=0){
      state.effects.push({id:++state.seq, x:target.x, y:target.y, ttl:0.65, kind:'blast',team:target.team});
      e.kills++;
      teamRes(state,e.team).killed++;
      if(target.kind==='hq') {state.finished=true;state.winner=e.team;log(state,'تم إسقاط مركز القيادة! النصر للفريق '+e.team,e.team);}
      else if(target.category==='building')log(state,'دُمّر '+BUILDING[target.kind].label, e.team);
    }
  }
  function tick(state,dt) {
    if(state.finished)return state;
    dt=clamp(Number(dt)||0,0,0.15); if(!dt)return state;
    state.time+=dt;
    for(const team of [1,2]) {
      const p=state.players[team];
      const refs=state.entities.filter(e=>e.hp>0&&e.team===team&&e.kind==='refinery').reduce((sum,e)=>sum+(e.level||1),0);
      const caps=state.points.filter(pt=>pt.owner===team).length;
      p.credits=clamp(p.credits+(7+refs*6+caps*4)*dt,0,9999);
      p.energy=clamp(p.energy+(1.0+refs*0.68)*dt,0,999);
    }
    for(const e of state.entities){
      if(e.hp<=0)continue;
      e.cooldown=Math.max(0,e.cooldown-dt);
      const spec=e.category==='building'?BUILDING[e.kind]:UNIT[e.kind];
      if(e.category==='unit') {
        if(spec.repair){
          const damaged=state.entities.filter(a=>a.team===e.team&&a.id!==e.id&&a.hp>0&&a.hp<a.maxHp&&distance(a,e)<=spec.range);
          damaged.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp);
          if(damaged[0])damaged[0].hp=Math.min(damaged[0].maxHp,damaged[0].hp+spec.repair*dt);
        }
        let target=e.targetId?find(state,e.targetId):null;
        if(!target||target.team===e.team||!canSee(state,e.team,target)){target=null;e.targetId=null;}
        if(!target)target=nextTarget(state,e,spec.range);
        const go=e.stance==='hold'?null:(target ? (spec.naval?nearestOpen(state,target,e.size*.45,'naval'):{x:target.x,y:target.y}) : e.dest);
        if(go){
          let waypoint=go,stop=target?spec.range+target.size-10:9;
          if(!spec.air){
            const domain=spec.naval?'naval':'ground';
            e.routeTimer=Math.max(0,(e.routeTimer||0)-dt);
            const needsRoute=!lineOpen(state,e,go,e.size*.42,domain);
            if(needsRoute && (!e.route?.length||!e.routeGoal||distance(e.routeGoal,go)>75||!e.routeTimer)){
              e.route=findPath(state,e,go,e.size*.42,domain);e.routeGoal={...go};e.routeTimer=3;
            }else if(!needsRoute){e.route=null;e.routeGoal=null;}
            if(e.route?.length){
              if(distance(e,e.route[0])<Math.max(11,e.size*.6))e.route.shift();
              if(e.route?.length){waypoint=e.route[0];stop=10;}
            }
          }
          const d=distance(e,waypoint);
          if(d>stop){
            const travel=Math.min(d-stop,spec.speed*(1+.12*(state.players[e.team].tech?.mobility||0))*terrainAt(state,e.x,e.y).speed*dt),angle=Math.atan2(waypoint.y-e.y,waypoint.x-e.x);
            let nx=clamp(e.x+Math.cos(angle)*travel,12,mapWidth(state)-12),ny=clamp(e.y+Math.sin(angle)*travel,12,mapHeight(state)-12);
            if(spec.air||!blocked(state,nx,ny,e.size*.42,spec.naval?'naval':'ground')){e.x=nx;e.y=ny;}
            e.angle=angle;
          }else if(!target&&!e.route?.length){
            if(e.stance==='patrol'&&e.patrol){
              e.patrol.next=e.patrol.next==='b'?'a':'b';
              e.dest={...e.patrol[e.patrol.next]};e.route=null;e.routeGoal=null;e.routeTimer=0;
            }else e.dest=null;
          }
        }
      }
      // Units and towers fire when enemies enter range.
      if(spec.range&&!spec.repair){
        let target=e.targetId?find(state,e.targetId):null;
        if(!target || target.team===e.team || !canSee(state,e.team,target) || distance(e,target)>spec.range+target.size+4) target=nextTarget(state,e,spec.range);
        if(target && distance(e,target)<=spec.range+target.size && !(spec.airOnly&&!UNIT[target.kind]?.air) && (['artillery','rocket','jet','patrol','destroyer'].includes(e.kind)||lineOpen(state,e,target,3)))attack(state,e,target,spec);
      }
    }
    // Capture control points progressively; the side with the greatest local presence captures.
    for(const pt of state.points){
      const close=[0,0,0];
      for(const e of state.entities)if(e.hp>0&&e.category==='unit'&&distance(e,pt)<82)close[e.team]++;
      const capturer=close[1]&&!close[2]?1:close[2]&&!close[1]?2:0;
      if(capturer){
        if(pt.capturedBy!==capturer){pt.progress=Math.max(0,pt.progress-dt*35);if(pt.progress===0)pt.capturedBy=capturer;}
        else {pt.progress=Math.min(100,pt.progress+dt*(18+Math.min(close[capturer],4)*6));
          if(pt.progress===100&&pt.owner!==capturer){pt.owner=capturer;teamRes(state,capturer).captured++;log(state,'تمت السيطرة على النقطة '+pt.label,capturer);}
        }
      }
    }
    const cnt1=state.points.filter(pt=>pt.owner===1).length, cnt2=state.points.filter(pt=>pt.owner===2).length;
    const winning=cnt1>=2&&cnt1>cnt2?1:cnt2>=2&&cnt2>cnt1?2:0;
    if(state.dominance.team!==winning){state.dominance.team=winning;state.dominance.seconds=0;}
    else if(winning)state.dominance.seconds+=dt;
    if(state.dominance.seconds>=65){state.finished=true;state.winner=winning;log(state,'انتصار بالسيطرة على نقاط الخريطة!',winning);}
    state.entities=state.entities.filter(e=>e.hp>0);
    state.effects=state.effects.filter(e=>{e.ttl-=dt;return e.ttl>0;});
    if(!state.vsHuman)updateAI(state,dt);
    state.fogTimer=(state.fogTimer||0)+dt;
    if(state.fogTimer>=.25){state.fogTimer=0;updateIntel(state);}
    return state;
  }
  function canResearch(state,team,kind){const cost=techCost(kind,state.players[team].tech[kind]);return cost&&state.players[team].credits>=cost.credits&&state.players[team].energy>=cost.energy;}
  function updateAI(state,dt){
    const p=state.players[2], level=state.stage;
    p.aiTimer-=dt;
    if(p.aiTimer>0)return;
    p.aiTimer=level<3?5.5:Math.max(2.7,5.4-Math.min(level,13)*.26);
    const allies=state.entities.filter(e=>e.team===2&&e.category==='unit'), houses=state.entities.filter(e=>e.team===2&&e.category==='building');
    const factory=houses.find(e=>e.kind==='factory');
    const airbase=houses.find(e=>e.kind==='airbase');
    if(level>=2 && !factory && canAfford(state,2,'factory'))act(state,2,{type:'build',kind:'factory',x:Math.round(1050*state.width/WIDTH),y:Math.round(540*state.height/HEIGHT)});
    if(level>=16 && state.features.some(f=>f.kind==='water') && !houses.some(e=>e.kind==='dock') && canAfford(state,2,'dock'))act(state,2,{type:'build',kind:'dock',x:Math.round(870*state.width/WIDTH),y:Math.round(245*state.height/HEIGHT)});
    if(level>=6 && !airbase && canAfford(state,2,'airbase'))act(state,2,{type:'build',kind:'airbase',x:Math.round(1080*state.width/WIDTH),y:Math.round(580*state.height/HEIGHT)});
    const choices=factory&&level>=2 ? ['infantry','infantry','tank',...(level>=4?['scout','artillery']:[]),...(level>=9?['rocket','antiair','engineer','heavyTank','mortar','jammer']:[]),...(airbase&&level>=6?['helicopter',...(level>=8?['jet','drone']:[])]:[]),...(houses.some(e=>e.kind==='dock')?['patrol',...(level>=17?['destroyer']:[])]:[])] : ['infantry','scout'];
    const kind=choices[Math.floor(Math.random()*choices.length)];
    if(allies.length<Math.min(12+level*2,34))act(state,2,{type:'train',kind});
    if(level>=7&&p.tech.armor<Math.min(3,Math.floor(level/4))&&canResearch(state,2,'armor'))act(state,2,{type:'upgrade',scope:'tech',kind:'armor'});
    if(level>=9&&p.tech.weapons<Math.min(3,Math.floor(level/5))&&canResearch(state,2,'weapons'))act(state,2,{type:'upgrade',scope:'tech',kind:'weapons'});
    if(level>6&&houses.filter(e=>e.kind==='tower').length<3 && canAfford(state,2,'tower'))act(state,2,{type:'build',kind:'tower',x:Math.round(1000*state.width/WIDTH),y:Math.round((380+(Math.random()-.5)*200)*state.height/HEIGHT)});
    if(allies.length){
      const hq=houses.find(e=>e.kind==='hq');
      const threats=hq?state.entities.filter(e=>e.team===1&&e.hp>0&&e.category==='unit'&&distance(e,hq)<310&&canSee(state,2,e)):[];
      if(threats.length){
        threats.sort((a,b)=>distance(a,hq)-distance(b,hq));
        const response=allies.filter(e=>!UNIT[e.kind].naval&&(!UNIT[e.kind].airOnly||UNIT[threats[0].kind]?.air))
          .sort((a,b)=>distance(a,threats[0])-distance(b,threats[0])).slice(0,Math.max(2,Math.min(8,Math.ceil(allies.length*.5))));
        if(response.length)act(state,2,{type:'command',ids:response.map(e=>e.id),x:threats[0].x,y:threats[0].y,targetId:threats[0].id,formation:'line'});
        return;
      }
      const open=state.points.filter(p=>p.owner!==2), target=open.sort((a,b)=>{
        const score=pt=>allies.filter(e=>!UNIT[e.kind].naval).reduce((best,e)=>Math.min(best,distance(e,pt)),Infinity)+(pt.owner===1?-55:0);
        return score(a)-score(b);
      })[0];
      const to=target?{x:target.x,y:target.y}: {x:Math.round(125*state.width/WIDTH),y:Math.round(365*state.height/HEIGHT)};
      const active=allies.filter(e=>!e.dest&&!e.targetId || Math.random()<0.08);
      if(active.length)act(state,2,{type:'command',ids:active.map(e=>e.id),x:to.x,y:to.y});
      if(level>=4&&allies.length>=5&&Math.random()<0.25){const subset=allies.slice(0,Math.floor(allies.length*.55));act(state,2,{type:'command',ids:subset.map(e=>e.id),x:Math.round(160*state.width/WIDTH),y:Math.round(360*state.height/HEIGHT)});}
    }
  }
  function snapshot(state) { return JSON.parse(JSON.stringify(state)); }
  return { WIDTH,HEIGHT,mapWidth,mapHeight,UNIT,BUILDING,TECH,MISSIONS,MAPS,FORMATIONS,FORMATION_SPACING,formationOffsets,costs,techCost,buildingCost,terrainAt,blocked,lineOpen,findPath,createState,act,tick,snapshot,FOG_COLS,FOG_ROWS,FOG_CELL,SIGHT,sightRange,pointVisible,canSee,updateIntel,viewForTeam };
});
