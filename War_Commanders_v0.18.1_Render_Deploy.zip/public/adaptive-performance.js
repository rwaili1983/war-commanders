/* Adaptive rendering quality: never changes simulation speed or network tick rate. */
(function(root){'use strict';
  function create(){
    let observedMs=0,frames=0,renderTotal=0,renderSamples=0,bad=0,good=0,economy=false,fps=0,averageRender=0;
    function sample(deltaMs,renderMs){
      if(!Number.isFinite(deltaMs)||deltaMs<4||deltaMs>250)return {economy,changed:false,fps,averageRender};
      observedMs+=deltaMs;frames++;
      if(Number.isFinite(renderMs)&&renderMs>=0&&renderMs<=250){renderTotal+=renderMs;renderSamples++;}
      if(observedMs<1800)return {economy,changed:false,fps,averageRender};
      fps=Math.round(frames*1000/observedMs);averageRender=renderSamples?renderTotal/renderSamples:0;
      const slow=fps<39||(renderSamples>10&&averageRender>23);
      const fast=fps>=52&&(!renderSamples||averageRender<13);
      bad=slow?bad+1:0;good=fast?good+1:0;
      let changed=false;
      if(!economy&&bad>=2){economy=true;changed=true;bad=0;good=0;}
      else if(economy&&good>=5){economy=false;changed=true;good=0;bad=0;}
      observedMs=0;frames=0;renderTotal=0;renderSamples=0;
      return {economy,changed,fps,averageRender};
    }
    function reset(){observedMs=frames=renderTotal=renderSamples=bad=good=0;economy=false;fps=0;averageRender=0;}
    function status(){return {economy,fps,averageRender};}
    return {sample,reset,status};
  }
  const API={create};if(typeof module!=='undefined'&&module.exports)module.exports=API;root.WarAdaptivePerformance=API;
})(typeof window!=='undefined'?window:globalThis);
