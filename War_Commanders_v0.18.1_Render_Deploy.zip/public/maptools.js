/* Map data is strictly local: import/export never executes scripts or uploads data. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.WarMapTools=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const KINDS=['rock','ridge','forest','ruins','road','dunes','water','bridge','ice','mud','trench','marsh'];
const THEMES=['desert','dust','forest','night','snow','coast','canyon'];
const MAX_FEATURES=55;
const clone=m=>JSON.parse(JSON.stringify(m));
function normalize(raw){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('بنية الخريطة غير صحيحة');
 const f=raw.features;
 if(!Array.isArray(f)||f.length>MAX_FEATURES)throw Error('تجاوز الحد الأقصى (55 تضريسًا)');
 if(!Array.isArray(raw.points)||raw.points.length!==3)throw Error('يجب وجود ثلاث نقاط سيطرة');
 const points=raw.points.map(p=>{if(!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite)||p[0]<320||p[0]>880||p[1]<110||p[1]>610)throw Error('إحداثيات نقاط السيطرة غير صالحة');return p.map(Math.round)});
 const features=f.map((t,i)=>{
  if(!t||!KINDS.includes(t.kind)||!['circle','rect'].includes(t.shape))throw Error('تضريس غير معروف في العنصر '+(i+1));
  const o={kind:t.kind,shape:t.shape,x:Number(t.x),y:Number(t.y)};
  if(!Number.isFinite(o.x)||!Number.isFinite(o.y)||o.x<25||o.x>1175||o.y<25||o.y>695)throw Error('موقع تضريس خارج الحدود');
  if(o.shape==='circle'){o.r=Number(t.r);if(!Number.isFinite(o.r)||o.r<15||o.r>190)throw Error('حجم الدائرة غير صالح')}
  else{o.w=Number(t.w);o.h=Number(t.h);if(!Number.isFinite(o.w)||!Number.isFinite(o.h)||o.w<30||o.h<25||o.w>1050||o.h>390)throw Error('حجم المستطيل غير صالح')}
  // Preserve safe distance around both headquarters and prevent inevitable overlapped spawns.
  if(['water','ridge','rock','ruins'].includes(o.kind))for(const px of [120,1080]){
    const overlaps=o.shape==='rect'?Math.abs(o.x-px)<o.w/2+55&&Math.abs(o.y-360)<o.h/2+70:Math.hypot(o.x-px,o.y-360)<o.r+75;
    if(overlaps)throw Error('عوائق الخريطة لا يجوز أن تغطي مقري القيادة');
  }
  return o;
 });
 const label=String(raw.label||'ساحة مخصصة').trim().slice(0,40)||'ساحة مخصصة';
 const map={format:'war-commanders-map',version:1,id:'local-design',label,theme:THEMES.includes(raw.theme)?raw.theme:'coast',features,points};
 const blocked=(x,y)=>features.some(o=>['rock','ridge','ruins','water'].includes(o.kind)&&(o.shape==='circle'?Math.hypot(o.x-x,o.y-y)<o.r+8:Math.abs(o.x-x)<o.w/2+8&&Math.abs(o.y-y)<o.h/2+8)&&!features.some(b=>b.kind==='bridge'&&b.shape==='rect'&&Math.abs(b.x-x)<b.w/2-8&&Math.abs(b.y-y)<b.h/2-8));
 if(points.some(p=>blocked(...p)))throw Error('إحدى نقاط السيطرة تقع داخل عائق');
 return map;
}
function preset(m,theme){return normalize({label:m.label,theme,points:clone(m.points),features:clone(m.features)});}
function feature(kind,x,y){x=Math.max(30,Math.min(1170,Math.round(x/20)*20));y=Math.max(30,Math.min(690,Math.round(y/20)*20));
 if(kind==='water')return {kind,shape:'rect',x,y,w:560,h:145};
 if(kind==='bridge')return {kind,shape:'rect',x,y,w:95,h:210};
 if(kind==='road')return {kind,shape:'rect',x,y,w:330,h:60};
 if(kind==='trench')return {kind,shape:'rect',x,y,w:190,h:55};
 if(kind==='ridge'||kind==='ruins')return {kind,shape:'rect',x,y,w:120,h:125};
 return {kind,shape:'circle',x,y,r:kind==='forest'?82:kind==='rock'?48:kind==='mud'||kind==='marsh'?65:62};
}
return {normalize,preset,feature,clone,KINDS,THEMES,MAX_FEATURES};
});
