(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const panel=$('gameView');
  const hud=$('mobileBattleHud');
  if(!panel||!hud)return;
  const dock=$('hudCommandDock');
  const radar=$('battleHudRadar');
  const mini=$('minimap');
  const trainPanels=[...document.querySelectorAll('#gameView .right-panel .command-section')];
  const movable=[['train',trainPanels[0]],['build',trainPanels[1]],['research',trainPanels[2]],['orders',$('squadOrders')],['squads',document.querySelector('#gameView .control-groups')],['radar',mini]];
  const placeholders=new Map();
  movable.forEach(([name,node])=>{
    if(!node)return;
    const placeholder=document.createComment('original battle control '+name);
    node.parentNode.insertBefore(placeholder,node);
    placeholders.set(node,placeholder);
    if(name!=='radar'){node.dataset.hudPane=name;node.classList.add('hud-pane');}
  });
  let mounted=false;
  let currentTab='train';
  let viewActive=false;
  let allowPortraitPlay=false;
  const coarse=()=>window.matchMedia('(pointer: coarse)').matches || /iphone|android|mobile/i.test(navigator.userAgent);
  function mobileLandscape(){return coarse()&&window.innerWidth>window.innerHeight&&window.innerHeight<=700&&window.innerWidth<=1200}
  function mobilePortrait(){return coarse()&&window.innerHeight>=window.innerWidth&&window.innerWidth<=1100}
  function setTab(name){
    currentTab=name;
    document.querySelectorAll('#gameView [data-hud-tab]').forEach(b=>{const selected=b.dataset.hudTab===name;b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected));});
    for(const [type,node] of movable){if(type==='radar'||!node)continue;node.classList.toggle('active',type===name);}
  }
  function mount(){if(mounted)return;
    for(const [name,node] of movable){if(!node)continue;
      if(name==='radar')radar.appendChild(node);else dock.appendChild(node);
    }
    mounted=true;setTab(currentTab);
  }
  function restore(){if(!mounted)return;
    for(const [,node] of movable){if(!node)continue;const marker=placeholders.get(node);marker?.parentNode?.insertBefore(node,marker.nextSibling);}
    mounted=false;
  }
  function fit(){
    const landscape=viewActive&&mobileLandscape();
    if(mobileLandscape())allowPortraitPlay=false;
    const portrait=viewActive&&mobilePortrait()&&!allowPortraitPlay;
    const changed=document.body.classList.contains('battle-landscape')!==landscape||document.body.classList.contains('battle-portrait')!==portrait;
    document.body.classList.toggle('battle-landscape',landscape);
    document.body.classList.toggle('battle-portrait',portrait);
    hud.hidden=!landscape;
    $('battleRotateGate').hidden=!portrait;
    if(landscape)mount();else restore();
    if(changed)requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')));
  }
  async function requestLandscape(){
    // Landscape orientation lock is only available in some fullscreen browsers.
    if(!viewActive)return;
    if(document.fullscreenElement!==panel && panel.requestFullscreen){try{await panel.requestFullscreen({navigationUI:'hide'})}catch{}}
    if(screen.orientation?.lock){try{await screen.orientation.lock('landscape')}catch{}}
    fit();
  }
  async function exitImmersive(){
    try{screen.orientation?.unlock?.()}catch{}
    if(document.fullscreenElement && document.exitFullscreen){try{await document.exitFullscreen()}catch{}}
  }
  $('hudFullscreen').addEventListener('click',requestLandscape);
  $('battleFullscreenBtn').addEventListener('click',requestLandscape);
  $('rotateTryBtn').addEventListener('click',requestLandscape);
  $('rotateContinueBtn')?.addEventListener('click',()=>{allowPortraitPlay=true;fit();});
  $('hudSound')?.addEventListener('click',()=>{ $('soundBtn')?.click(); $('hudSound').textContent=$('soundBtn').textContent; });
  $('hudPause').addEventListener('click',()=>{
    $('pauseBtn').click();$('hudPause').textContent=$('pauseBtn').textContent.includes('استئناف')?'▶':'⏸';
  });
  document.querySelectorAll('#gameView [data-hud-tab]').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.hudTab)));
  window.addEventListener('war:view',e=>{viewActive=e.detail?.view==='game';fit();if(!viewActive)exitImmersive();});
  window.addEventListener('orientationchange',fit);
  window.addEventListener('resize',fit);
  document.addEventListener('fullscreenchange',fit);
  // Avoid forcibly rotating phones on browsers where orientation is under OS control.
  // The blocking portrait gate explains how to disable OS rotation lock.
  viewActive=$('gameView').classList.contains('active');
  fit();
})();
