/* v0.15 — local tactical control groups. No client-side group changes server authority. */
(function(root){'use strict';
  const MAX_GROUPS=4, MAX_UNITS=45;
  function create(options={}){
    const storage=options.storage||null;
    let scope='solo',team=1,slots=Array.from({length:MAX_GROUPS},()=>[]);
    const validSlot=n=>Number.isInteger(Number(n))&&Number(n)>=1&&Number(n)<=MAX_GROUPS;
    const validIds=(ids,state,owner)=>{
      if(!state||!Array.isArray(state.entities))return [];
      const owned=new Set(state.entities.filter(e=>e.team===owner&&e.category==='unit'&&e.hp>0).map(e=>e.id));
      return [...new Set(Array.isArray(ids)?ids:[])].filter(id=>Number.isSafeInteger(id)&&owned.has(id)).slice(0,MAX_UNITS);
    };
    const storageKey=()=>scope.startsWith('room:')?'wc-v15-groups:'+scope+':'+team:null;
    function persist(){const key=storageKey();if(!key||!storage)return;try{storage.setItem(key,JSON.stringify(slots))}catch{}}
    function reset(nextScope='solo',nextTeam=1,restore=false){
      scope=String(nextScope).slice(0,80);team=nextTeam===2?2:1;slots=Array.from({length:MAX_GROUPS},()=>[]);
      if(restore&&storageKey()&&storage){try{const data=JSON.parse(storage.getItem(storageKey()));if(Array.isArray(data))slots=data.slice(0,MAX_GROUPS).map(x=>Array.isArray(x)?x.slice(0,MAX_UNITS).filter(Number.isSafeInteger):[]);while(slots.length<MAX_GROUPS)slots.push([]);}catch{}}
      return snapshot();
    }
    function assign(slot,ids,state,owner=team){
      if(!validSlot(slot))return {ok:false,error:'رقم مجموعة غير صالح'};
      const live=validIds(ids,state,team);
      if(owner!==team||!live.length)return {ok:false,error:'حدد وحداتك أولًا لحفظ المجموعة'};
      slots[Number(slot)-1]=live;persist();return {ok:true,ids:[...live],count:live.length};
    }
    function recall(slot,state,owner=team){
      if(!validSlot(slot))return {ok:false,ids:[],error:'رقم مجموعة غير صالح'};
      if(owner!==team)return {ok:false,ids:[],error:'لا يمكن الوصول لقوات فريق آخر'};
      const idx=Number(slot)-1,old=slots[idx],live=validIds(old,state,team);
      if(live.length!==old.length){slots[idx]=live;persist();}
      return live.length?{ok:true,ids:live,count:live.length}:{ok:false,ids:[],error:old.length?'لم تعد قوات المجموعة متاحة':'المجموعة فارغة'};
    }
    function snapshot(state){return slots.map((ids,i)=>({slot:i+1,ids:state?validIds(ids,state,team):[...ids],count:state?validIds(ids,state,team).length:ids.length}));}
    function forget(){const key=storageKey();if(key&&storage)try{storage.removeItem(key)}catch{};slots=Array.from({length:MAX_GROUPS},()=>[]);}
    return {assign,recall,snapshot,reset,forget};
  }
  const API={create,MAX_GROUPS};
  if(typeof module!=='undefined'&&module.exports)module.exports=API;
  root.WarControlGroups=API;
})(typeof window!=='undefined'?window:globalThis);
