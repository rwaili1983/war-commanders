/* Explicit, opt-in game server navigation; no LAN device scanning. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.WarServerLink=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function privateAddress(host){
   if(host==='localhost'||host==='127.0.0.1')return true;
   if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host))return false;
   const a=host.split('.').map(Number);if(a.some(x=>x>255))return false;
   return a[0]===10 || (a[0]===172&&a[1]>=16&&a[1]<=31) || (a[0]===192&&a[1]===168) || a[0]===127;
 }
 function normalize(input){
   const src=String(input||'').trim();
   if(!src||src.length>240||/[\\\s@#?]/.test(src))throw Error('أدخل عنوان الخادم الصحيح دون مسافات أو بيانات دخول');
   const value=/^https?:\/\//i.test(src)?src:'http://'+src;
   let u;try{u=new URL(value)}catch{throw Error('عنوان الخادم غير صالح')}
   if(u.username||u.password||u.hash||u.search||u.pathname!=='/'|| !['http:','https:'].includes(u.protocol))throw Error('استخدم عنوان الخادم فقط دون مسار أو معاملات');
   if(u.protocol==='http:'&&!privateAddress(u.hostname))throw Error('خادم الإنترنت يتطلب HTTPS. اتصالات HTTP مسموحة للشبكات الخاصة فقط');
   if(u.protocol==='https:'&& !/^[a-zA-Z0-9._-]+$/.test(u.hostname))throw Error('اسم الخادم غير صالح');
   if(!u.port&&u.protocol==='http:')u.port='8787';
   return u.origin+'/';
 }
 return {normalize,privateAddress};
});
