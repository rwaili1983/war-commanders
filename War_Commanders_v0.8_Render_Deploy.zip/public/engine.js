/* WAR COMMANDERS - deterministic-enough simulation shared by browser + Node.js */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.WarEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const WIDTH = 1200, HEIGHT = 720;
  const UNIT = {
    infantry: { label: 'مشاة', hp: 95, speed: 66, range: 86, damage: 18, reload: 0.82, cost: 85, energy: 5, size: 12 },
    scout: { label: 'استطلاع', hp: 140, speed: 85, range: 105, damage: 16, reload: 0.53, cost: 120, energy: 8, size: 15 },
    tank: { label: 'دبابة', hp: 290, speed: 44, range: 138, damage: 42, reload: 1.35, cost: 205, energy: 13, size: 21 },
    artillery: { label: 'مدفعية', hp: 175, speed: 32, range: 245, damage: 69, reload: 2.5, cost: 295, energy: 21, size: 19 },
    helicopter: { label: 'مروحية', hp: 205, speed: 104, range: 150, damage: 26, reload: .92, cost: 315, energy: 26, size: 19, air: true },
    jet: { label: 'مقاتلة', hp: 165, speed: 150, range: 205, damage: 46, reload: 1.85, cost: 465, energy: 40, size: 18, air: true },
    rocket: { label: 'راجمة صواريخ', hp: 160, speed: 37, range: 275, damage: 62, reload: 2.85, cost: 360, energy: 28, size: 19, splash: 38 },
    antiair: { label: 'دفاع جوي', hp: 220, speed: 48, range: 220, damage: 53, reload: 1.38, cost: 275, energy: 22, size: 19, airOnly: true },
    engineer: { label: 'مهندس صيانة', hp: 120, speed: 70, range: 88, damage: 0, reload: 1, cost: 155, energy: 13, size: 12, repair: 24 }
  };
  const BUILDING = {
    hq: { label: 'مركز القيادة', hp: 1150, size: 54, cost: 0, energy: 0 },
    barracks: { label: 'الثكنات', hp: 410, size: 36, cost: 180, energy: 20 },
    factory: { label: 'مصنع المدرعات', hp: 490, size: 41, cost: 330, energy: 35 },
    refinery: { label: 'منشأة الموارد', hp: 320, size: 35, cost: 230, energy: 25 },
    tower: { label: 'برج دفاعي', hp: 310, size: 27, cost: 165, energy: 18, range: 195, damage: 27, reload: 0.8 },
    airbase: { label: 'قاعدة جوية', hp: 550, size: 43, cost: 395, energy: 34 },
    radar: { label: 'رادار دفاعي', hp: 340, size: 31, cost: 290, energy: 28, range: 245, damage: 32, reload: .95, airOnly: true }
  };
  const MISSIONS = [
    { title: 'شرارة البداية', region: 'سهول النصر', theme: 'desert', difficulty: 1, caption: 'أمّن الموارد واستولِ على نقاط السيطرة.' },
    { title: 'وادي الحديد', region: 'الوادي الأحمر', theme: 'desert', difficulty: 2, caption: 'ابنِ مصنع المدرعات قبل الهجوم.' },
    { title: 'حصار القلعة', region: 'الحدود الشرقية', theme: 'dust', difficulty: 3, caption: 'عطّل دفاعات الخصم وحاصر مقره.' },
    { title: 'عاصفة الصحراء', region: 'الكثبان الكبرى', theme: 'desert', difficulty: 4, caption: 'تحرك بسرعة نحو مناطق السيطرة.' },
    { title: 'الجبهة الشمالية', region: 'المرتفعات', theme: 'forest', difficulty: 5, caption: 'استخدم الفرق المختلفة لفتح الجبهة.' },
    { title: 'عملية الصقر', region: 'السهل الأخضر', theme: 'forest', difficulty: 6, caption: 'أبقِ مراكز الإنتاج تحت الحماية.' },
    { title: 'ليلة الحصار', region: 'مدينة الأطراف', theme: 'night', difficulty: 7, caption: 'اصمد أمام هجوم الخصم المتواصل.' },
    { title: 'الدرع الفولاذي', region: 'وادي التحصينات', theme: 'dust', difficulty: 8, caption: 'استثمر في الأبراج والمدفعية.' },
    { title: 'خط الدفاع الأخير', region: 'الأرض المحروقة', theme: 'night', difficulty: 9, caption: 'لا تسمح للخصم بالسيطرة على مركزك.' },
    { title: 'القائد الأعلى', region: 'ساحة المجد', theme: 'desert', difficulty: 10, caption: 'معركة الحسم للسيطرة على الخريطة.' },
    { title: 'أرض الجليد', region: 'الممر المتجمد', theme: 'snow', difficulty: 11, caption: 'احم وحداتك عند الممرات الباردة ووسّع انتشارك.' },
    { title: 'ميناء الصقور', region: 'الخليج الشرقي', theme: 'coast', difficulty: 12, caption: 'أمن الشريط الساحلي واستثمر في الرادار والدفاع الجوي.' },
    { title: 'مضيق الرعد', region: 'الأخدود الصخري', theme: 'canyon', difficulty: 13, caption: 'استخدم المدفعية والراجمات لدفع الجبهة للأمام.' },
    { title: 'القمة البيضاء', region: 'جبال الثلج', theme: 'snow', difficulty: 14, caption: 'رقّ قواتك ومصانعك قبل مواجهة القوات الثقيلة.' },
    { title: 'معركة الحسم', region: 'ساحل النصر', theme: 'coast', difficulty: 15, caption: 'التحكم في الموارد والترقيات مفتاح الفوز النهائي.' }
  ];
  const TECH = {
    armor: {label:'تدريع القوات',baseCost:240,baseEnergy:24,maxLevel:3},
    weapons: {label:'تطوير الأسلحة',baseCost:285,baseEnergy:29,maxLevel:3},
    mobility: {label:'تطوير الحركة',baseCost:220,baseEnergy:21,maxLevel:3}
  };
  function techCost(kind, level){const t=TECH[kind];if(!t||level>=t.maxLevel)return null;return {credits:Math.round(t.baseCost*(level+1)*1.12),energy:Math.round(t.baseEnergy*(level+1))};}
  function buildingCost(e){if(!e||e.category!=='building'||e.level>=3)return null;const spec=BUILDING[e.kind];return {credits:Math.round(Math.max(260,spec.cost)*(.85+e.level*.65)),energy:Math.round(Math.max(22,spec.energy)*(.8+e.level*.5))};}
  const costs = { ...Object.fromEntries(Object.entries(UNIT).map(([k,v]) => [k,{ credits:v.cost,energy:v.energy }])),
                  ...Object.fromEntries(Object.entries(BUILDING).map(([k,v]) => [k,{ credits:v.cost,energy:v.energy }])) };
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const distance = (a,b) => Math.hypot(a.x - b.x, a.y - b.y);
  const teamRes = (state,team) => state.players[team];
  function log(state,msg,team=0) {
    state.events.push({id: ++state.seq, time: Math.floor(state.time), text:msg, team});
    if(state.events.length > 25) state.events.shift();
  }
  function entity(state, team, kind, x, y, isBuilding) {
    const spec = isBuilding ? BUILDING[kind] : UNIT[kind];
    const obj = { id: ++state.seq, team, kind, category: isBuilding ? 'building' : 'unit', x, y,
      level:1, hp: spec.hp, maxHp: spec.hp, size:spec.size, cooldown:0, dest:null, targetId:null, angle: team === 1 ? 0 : Math.PI, kills:0 };
    state.entities.push(obj);
    return obj;
  }
  function createState(options={}) {
    const mission = clamp(Number(options.stage)||1,1,MISSIONS.length);
    const difficulty = MISSIONS[mission-1].difficulty;
    const state = { version:1, width:WIDTH, height:HEIGHT, stage:mission, theme:MISSIONS[mission-1].theme,
      name:MISSIONS[mission-1].title, time:0, seq:0, finished:false, winner:null, vsHuman:!!options.vsHuman,
      entities:[], effects:[], events:[], points:[
        { id:1,x:470,y:220, owner:0, progress:0, capturedBy:0, label:'ألفا' },
        { id:2,x:610,y:450, owner:0, progress:0, capturedBy:0, label:'بيتا' },
        { id:3,x:770,y:205, owner:0, progress:0, capturedBy:0, label:'جاما' }
      ],
      players:{ 1:{ credits:540, energy:115, wins:0, killed:0, captured:0, aiTimer:4, momentum:0, tech:{armor:0,weapons:0,mobility:0} },
                2:{ credits:410 + difficulty*48, energy:115, wins:0, killed:0, captured:0, aiTimer:5.5, momentum:0, tech:{armor:0,weapons:0,mobility:0} } },
      dominance:{team:0, seconds:0}
    };
    entity(state,1,'hq',120,365,true);
    entity(state,1,'barracks',220,470,true);
    entity(state,1,'refinery',220,260,true);
    entity(state,1,'infantry',270,420,false);
    entity(state,1,'infantry',285,340,false);
    entity(state,1,'scout',255,385,false);
    entity(state,2,'hq',1080,355,true);
    entity(state,2,'barracks',980,230,true);
    entity(state,2,'refinery',982,460,true);
    entity(state,2,'infantry',925,280,false);
    entity(state,2,'infantry',922,378,false);
    if(difficulty >= 3) entity(state,2,'tower',978,330,true);
    if(difficulty >= 5) entity(state,2,'tank',900,410,false);
    if(difficulty >= 7) entity(state,2,'factory',1060,495,true);
    if(difficulty >= 6) entity(state,2,'airbase',1110,630,true);
    if(mission>=11){
      const presets=[[[430,150],[640,535],[790,265]],[[360,370],[610,170],[840,520]],[[470,535],[655,275],[820,120]],[[410,200],[610,440],[840,320]],[[450,500],[625,170],[830,420]]];
      presets[mission-11].forEach((pt,i)=>{state.points[i].x=pt[0];state.points[i].y=pt[1];});
      entity(state,2,'radar',1032,155,true);
      entity(state,2,'antiair',880,210,false);
      if(mission>=13)entity(state,2,'rocket',903,500,false);
    }
    log(state,'بدأت عملية '+state.name+'. سيطر على النقاط أو دمر مركز القيادة المعادي.');
    return state;
  }
  function find(state,id){return state.entities.find(e=>e.id===id && e.hp>0);}
  function canAfford(state,team,kind) {
    const cost=costs[kind], p=teamRes(state,team);
    return !!cost && p.credits >= cost.credits && p.energy >= cost.energy;
  }
  function spend(state,team,kind) {const c=costs[kind], p=teamRes(state,team);p.credits-=c.credits;p.energy-=c.energy;}
  function applyArmor(state,team){
    const level=state.players[team].tech.armor;
    for(const u of state.entities.filter(e=>e.team===team&&e.category==='unit')){
      const intended=Math.round(UNIT[u.kind].hp*(1+level*.16));
      if(u.maxHp!==intended){const old=u.maxHp;u.maxHp=intended;u.hp=Math.min(intended,u.hp+Math.max(0,intended-old));}
    }
  }
  function act(state,team,action) {
    team=Number(team);
    if (state.finished || ![1,2].includes(team) || !action || typeof action!=='object') return {ok:false,error:'تعذر تنفيذ الأمر'};
    const p=teamRes(state,team);
    if(action.type==='upgrade') {
      if(action.scope==='tech'){
        const kind=String(action.kind||'');const t=TECH[kind];
        if(!t)return {ok:false,error:'ترقية غير معروفة'};
        const level=p.tech[kind]||0,cost=techCost(kind,level);
        if(!cost)return {ok:false,error:'وصل البحث إلى أعلى مستوى'};
        if(p.credits<cost.credits||p.energy<cost.energy)return {ok:false,error:'الموارد غير كافية للبحث'};
        p.credits-=cost.credits;p.energy-=cost.energy;p.tech[kind]=level+1;
        if(kind==='armor')applyArmor(state,team);
        log(state,'اكتملت ترقية '+t.label+' إلى المستوى '+p.tech[kind],team);
        return {ok:true,level:p.tech[kind]};
      }
      if(action.scope==='building'){
        const b=find(state,Number(action.id));
        if(!b||b.team!==team||b.category!=='building')return {ok:false,error:'اختر أحد مبانيك أولًا'};
        const cost=buildingCost(b);
        if(!cost)return {ok:false,error:'المبنى في أعلى مستوى'};
        if(p.credits<cost.credits||p.energy<cost.energy)return {ok:false,error:'الموارد غير كافية للترقية'};
        p.credits-=cost.credits;p.energy-=cost.energy;b.level++;
        const delta=Math.round(BUILDING[b.kind].hp*.34);b.maxHp+=delta;b.hp=Math.min(b.maxHp,b.hp+delta);
        log(state,'ترقية '+BUILDING[b.kind].label+' إلى المستوى '+b.level,team);
        return {ok:true,level:b.level,id:b.id};
      }
      return {ok:false,error:'نوع ترقية غير معروف'};
    }
    if(action.type==='train') {
      const spec=UNIT[action.kind];
      if(!spec) return {ok:false,error:'وحدة غير معروفة'};
      const required=['infantry','scout','engineer'].includes(action.kind) ? 'barracks' : (spec.air ? 'airbase' : 'factory');
      const producer=state.entities.find(e=>e.team===team && e.kind===required && e.hp>0);
      if(!producer) return {ok:false,error:required==='factory' ? 'ابنِ مصنع المدرعات أولًا' : required==='airbase' ? 'ابنِ قاعدة جوية أولًا' : 'تحتاج إلى ثكنات'};
      if(!canAfford(state,team,action.kind)) return {ok:false,error:'الموارد غير كافية'};
      if(state.entities.filter(e=>e.team===team && e.category==='unit').length>=45) return {ok:false,error:'بلغت الحد الأقصى للقوات'};
      const x=clamp(producer.x + (team===1?65:-65)+(Math.random()-.5)*30,20,WIDTH-20);
      const y=clamp(producer.y+(Math.random()-.5)*80,25,HEIGHT-25);
      spend(state,team,action.kind);
      const newUnit=entity(state,team,action.kind,x,y,false);
      const armor=p.tech.armor||0;
      if(armor){newUnit.maxHp=Math.round(spec.hp*(1+.16*armor));newUnit.hp=newUnit.maxHp;}
      log(state,'تم إنتاج '+spec.label,team);
      return {ok:true,id:newUnit.id};
    }
    if(action.type==='build') {
      const kind=action.kind;
      if(!BUILDING[kind]||kind==='hq')return {ok:false,error:'المبنى غير متاح'};
      const x=Math.round(Number(action.x)), y=Math.round(Number(action.y));
      if(!Number.isFinite(x)||!Number.isFinite(y)||x<65||x>WIDTH-65||y<65||y>HEIGHT-65)return {ok:false,error:'موقع البناء خارج الخريطة'};
      if(!state.entities.some(e=>e.team===team&&e.category==='building'&&distance(e,{x,y})<300))return {ok:false,error:'ابنِ بالقرب من قاعدتك'};
      if(state.entities.some(e=>distance(e,{x,y})<e.size+BUILDING[kind].size+12))return {ok:false,error:'الموقع مشغول'};
      if(state.points.some(pt=>distance(pt,{x,y})<80))return {ok:false,error:'لا يمكن البناء على نقطة سيطرة'};
      if(!canAfford(state,team,kind))return {ok:false,error:'الموارد غير كافية'};
      spend(state,team,kind);
      const b=entity(state,team,kind,x,y,true);
      log(state,'اكتمل بناء '+BUILDING[kind].label,team);
      return {ok:true,id:b.id};
    }
    if(action.type==='command') {
      const ids=Array.isArray(action.ids)?action.ids.slice(0,45):[];
      const dest={x:clamp(Number(action.x)||0,14,WIDTH-14), y:clamp(Number(action.y)||0,14,HEIGHT-14)};
      const enemy=action.targetId ? find(state,Number(action.targetId)) : null;
      const valid=ids.map(id=>find(state,Number(id))).filter(e=>e&&e.team===team&&e.category==='unit');
      for(let i=0;i<valid.length;i++) {
        const e=valid[i], spread=valid.length>1 ? {x:((i%5)-2)*24,y:(Math.floor(i/5)-2)*24} : {x:0,y:0};
        e.dest={x:clamp(dest.x+spread.x,10,WIDTH-10),y:clamp(dest.y+spread.y,10,HEIGHT-10)};
        e.targetId=enemy&&enemy.team!==team&&(!UNIT[e.kind]?.airOnly||UNIT[enemy.kind]?.air)?enemy.id:null;
      }
      if(!valid.length)return {ok:false,error:'حدد وحداتك أولًا'};
      return {ok:true,count:valid.length};
    }
    return {ok:false,error:'أمر غير معروف'};
  }
  function nextTarget(state,e,range) {
    let best=null, bestDistance=Infinity;
    for(const other of state.entities){
      if(other.team===e.team||other.hp<=0||(UNIT[e.kind]?.airOnly||BUILDING[e.kind]?.airOnly)&&!UNIT[other.kind]?.air)continue;
      const d=distance(e,other)-other.size;
      if(d<range+30&&d<bestDistance){best=other;bestDistance=d;}
    }
    return best;
  }
  function attack(state,e,target,spec) {
    if(e.cooldown>0 || !target || target.hp<=0)return;
    const p=state.players[e.team],bonus=1+(.18*(p.tech?.weapons||0));
    const damage=Math.round(spec.damage*bonus*(spec.airOnly?1.35:1));
    target.hp-=damage;
    if(spec.splash){for(const other of state.entities)if(other!==target&&other.team!==e.team&&other.hp>0&&distance(other,target)<spec.splash){other.hp-=Math.round(damage*.38);}}
    
    e.cooldown=spec.reload;
    state.effects.push({id:++state.seq, x:e.x, y:e.y, tx:target.x, ty:target.y, ttl:0.2, kind:e.kind==='artillery'?'heavy':'shot',team:e.team});
    if(target.hp<=0){
      state.effects.push({id:++state.seq, x:target.x, y:target.y, ttl:0.65, kind:'blast',team:target.team});
      e.kills++;
      teamRes(state,e.team).killed++;
      if(target.kind==='hq') {state.finished=true;state.winner=e.team;log(state,'تم إسقاط مركز القيادة! النصر للفريق '+e.team,e.team);}
      else if(target.category==='building')log(state,'دُمّر '+BUILDING[target.kind].label, e.team);
    }
  }
  function tick(state,dt) {
    if(state.finished)return state;
    dt=clamp(Number(dt)||0,0,0.15); if(!dt)return state;
    state.time+=dt;
    for(const team of [1,2]) {
      const p=state.players[team];
      const refs=state.entities.filter(e=>e.hp>0&&e.team===team&&e.kind==='refinery').reduce((sum,e)=>sum+(e.level||1),0);
      const caps=state.points.filter(pt=>pt.owner===team).length;
      p.credits=clamp(p.credits+(7+refs*6+caps*4)*dt,0,9999);
      p.energy=clamp(p.energy+(1.0+refs*0.68)*dt,0,999);
    }
    for(const e of state.entities){
      if(e.hp<=0)continue;
      e.cooldown=Math.max(0,e.cooldown-dt);
      const spec=e.category==='building'?BUILDING[e.kind]:UNIT[e.kind];
      if(e.category==='unit') {
        if(spec.repair){
          const damaged=state.entities.filter(a=>a.team===e.team&&a.id!==e.id&&a.hp>0&&a.hp<a.maxHp&&distance(a,e)<=spec.range);
          damaged.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp);
          if(damaged[0])damaged[0].hp=Math.min(damaged[0].maxHp,damaged[0].hp+spec.repair*dt);
        }
        let target=e.targetId?find(state,e.targetId):null;
        if(!target||target.team===e.team){target=null;e.targetId=null;}
        if(!target)target=nextTarget(state,e,spec.range);
        const go=target ? {x:target.x,y:target.y} : e.dest;
        if(go){
          const d=distance(e,go), stop=target?spec.range+target.size-10:9;
          if(d>stop){
            const travel=Math.min(d-stop,spec.speed*(1+.12*(state.players[e.team].tech?.mobility||0))*dt), angle=Math.atan2(go.y-e.y,go.x-e.x);
            e.x=clamp(e.x+Math.cos(angle)*travel,12,WIDTH-12);
            e.y=clamp(e.y+Math.sin(angle)*travel,12,HEIGHT-12);
            e.angle=angle;
          } else if(!target)e.dest=null;
        }
      }
      // Units and towers fire when enemies enter range.
      if(spec.range&&!spec.repair){
        let target=e.targetId?find(state,e.targetId):null;
        if(!target || target.team===e.team || distance(e,target)>spec.range+target.size+4) target=nextTarget(state,e,spec.range);
        if(target && distance(e,target)<=spec.range+target.size && !(spec.airOnly&&!UNIT[target.kind]?.air))attack(state,e,target,spec);
      }
    }
    // Capture control points progressively; the side with the greatest local presence captures.
    for(const pt of state.points){
      const close=[0,0,0];
      for(const e of state.entities)if(e.hp>0&&e.category==='unit'&&distance(e,pt)<82)close[e.team]++;
      const capturer=close[1]&&!close[2]?1:close[2]&&!close[1]?2:0;
      if(capturer){
        if(pt.capturedBy!==capturer){pt.progress=Math.max(0,pt.progress-dt*35);if(pt.progress===0)pt.capturedBy=capturer;}
        else {pt.progress=Math.min(100,pt.progress+dt*(18+Math.min(close[capturer],4)*6));
          if(pt.progress===100&&pt.owner!==capturer){pt.owner=capturer;teamRes(state,capturer).captured++;log(state,'تمت السيطرة على النقطة '+pt.label,capturer);}
        }
      }
    }
    const cnt1=state.points.filter(pt=>pt.owner===1).length, cnt2=state.points.filter(pt=>pt.owner===2).length;
    const winning=cnt1>=2&&cnt1>cnt2?1:cnt2>=2&&cnt2>cnt1?2:0;
    if(state.dominance.team!==winning){state.dominance.team=winning;state.dominance.seconds=0;}
    else if(winning)state.dominance.seconds+=dt;
    if(state.dominance.seconds>=65){state.finished=true;state.winner=winning;log(state,'انتصار بالسيطرة على نقاط الخريطة!',winning);}
    state.entities=state.entities.filter(e=>e.hp>0);
    state.effects=state.effects.filter(e=>{e.ttl-=dt;return e.ttl>0;});
    if(!state.vsHuman)updateAI(state,dt);
    return state;
  }
  function canResearch(state,team,kind){const cost=techCost(kind,state.players[team].tech[kind]);return cost&&state.players[team].credits>=cost.credits&&state.players[team].energy>=cost.energy;}
  function updateAI(state,dt){
    const p=state.players[2], level=state.stage;
    p.aiTimer-=dt;
    if(p.aiTimer>0)return;
    p.aiTimer=level<3?5.5:Math.max(2.1,5.4-level*.26);
    const allies=state.entities.filter(e=>e.team===2&&e.category==='unit'), houses=state.entities.filter(e=>e.team===2&&e.category==='building');
    const factory=houses.find(e=>e.kind==='factory');
    const airbase=houses.find(e=>e.kind==='airbase');
    if(level>=2 && !factory && canAfford(state,2,'factory'))act(state,2,{type:'build',kind:'factory',x:1050,y:540});
    if(level>=6 && !airbase && canAfford(state,2,'airbase'))act(state,2,{type:'build',kind:'airbase',x:1080,y:580});
    const choices=factory&&level>=2 ? ['infantry','infantry','tank',...(level>=4?['scout','artillery']:[]),...(level>=9?['rocket','antiair','engineer']:[]),...(airbase&&level>=6?['helicopter',...(level>=8?['jet']:[])]:[])] : ['infantry','scout'];
    const kind=choices[Math.floor(Math.random()*choices.length)];
    if(allies.length<Math.min(12+level*2,34))act(state,2,{type:'train',kind});
    if(level>=7&&p.tech.armor<Math.min(3,Math.floor(level/4))&&canResearch(state,2,'armor'))act(state,2,{type:'upgrade',scope:'tech',kind:'armor'});
    if(level>=9&&p.tech.weapons<Math.min(3,Math.floor(level/5))&&canResearch(state,2,'weapons'))act(state,2,{type:'upgrade',scope:'tech',kind:'weapons'});
    if(level>6&&houses.filter(e=>e.kind==='tower').length<3 && canAfford(state,2,'tower'))act(state,2,{type:'build',kind:'tower',x:1000,y:380+(Math.random()-.5)*200});
    if(allies.length){
      const open=state.points.filter(p=>p.owner!==2), target=open.sort((a,b)=>Math.abs(a.x-980)-Math.abs(b.x-980))[0];
      const to=target?{x:target.x,y:target.y}: {x:125,y:365};
      const active=allies.filter(e=>!e.dest&&!e.targetId || Math.random()<0.08);
      if(active.length)act(state,2,{type:'command',ids:active.map(e=>e.id),x:to.x,y:to.y});
      if(level>=4&&allies.length>=5&&Math.random()<0.25){const subset=allies.slice(0,Math.floor(allies.length*.55));act(state,2,{type:'command',ids:subset.map(e=>e.id),x:160,y:360});}
    }
  }
  function snapshot(state) { return JSON.parse(JSON.stringify(state)); }
  return { WIDTH,HEIGHT,UNIT,BUILDING,TECH,MISSIONS,costs,techCost,buildingCost,createState,act,tick,snapshot };
});
